"""Builds the validation kit's input files (patients_*.csv, cbc_kit.csv) from the EHRSHOT (OMOP) extracts.
Case date = first MDS code (ICD-10 D46*, ICD-9 238.72-238.75). Runs on the local computer only."""
import pandas as pd, numpy as np
c = pd.read_csv('conditions.csv', dtype=str); c['d'] = pd.to_datetime(c.d, errors='coerce')
code = c.code.str.upper()
mds = c[code.str.match(r'^(D46|238\.7[2-5])')].groupby('person_id').d.min()
# kit definition: leukaemia, myeloproliferative neoplasm or aplastic anaemia
kit = code.str.match(r'^(C9[1-5]|D45|D47\.1|D47\.3|D47\.4|D61|20[4-8]|238\.4|238\.71|238\.76|284)')
# strict: any haematological malignancy (lymphoma, myeloma, leukaemia, MPN) or aplastic anaemia
strict = kit | code.str.match(r'^(C8[1-9]|C90|C96|D47|20[0-3]|238\.7[6-9])')
def first(mask): return c[mask].groupby('person_id').d.min()
p = pd.read_csv('person.csv', dtype={'person_id': str}, usecols=['person_id', 'gender_concept_id', 'year_of_birth'])
p['sex'] = p.gender_concept_id.map({8507: 'M', 8532: 'F'})
p = p.dropna(subset=['sex']).rename(columns={'person_id': 'patient_id', 'year_of_birth': 'birth_year'})
p['mds_date'] = p.patient_id.map(mds)
for name, m in [('kit', kit), ('strict', strict)]:
    f = p.patient_id.map(first(m))
    ex = np.where(p.mds_date.notna(), (f < p.mds_date), f.notna()).astype(int)
    out = p.assign(exclude=ex)[['patient_id', 'sex', 'birth_year', 'mds_date', 'exclude']].copy()
    out['mds_date'] = out.mds_date.dt.date.astype(str).replace('NaT', '')
    out.to_csv(f'patients_{name}.csv', index=False)
    print(name, 'MDS', int(p.mds_date.notna().sum()), 'MDS excluded', int(ex[p.mds_date.notna().values].sum()), 'non-MDS excluded', int(ex[p.mds_date.isna().values].sum()))
b = pd.read_csv('cbc.csv', dtype={'person_id': str}); b['date'] = pd.to_datetime(b.d, format='%m/%d/%Y')
names = {3000963: 'hb', 3020416: 'rbc', 3023599: 'mcv', 3019897: 'rdw', 3024929: 'plt', 3000905: 'wbc'}
b['v'] = b.test.map(names)
print(b.groupby('v').value.describe()[['count', '25%', '50%', '75%']])
w = b.pivot_table(index=['person_id', 'date'], columns='v', values='value', aggfunc='median').reset_index()
w = w.rename(columns={'person_id': 'patient_id'}); w['date'] = w.date.dt.date.astype(str)
for v in names.values():
    if v not in w: w[v] = np.nan
w[['patient_id', 'date', 'hb', 'rbc', 'mcv', 'rdw', 'plt', 'wbc']].to_csv('cbc_kit.csv', index=False)
print('cbc rows (patient-days)', len(w))
