import docx, copy, pandas as pd
E='external_validation/ehrshot/'
W={k:pd.read_csv(E+f'results_{k}/2_window_differences.csv') for k in ['kit','strict']}
O=pd.read_csv(E+'results_kit/3_offset_model.csv')
def f(x): return f'{x:+.2f}'.replace('+-','−').replace('-','−') if x<0 else f'+{x:.2f}'
def ci(r): return f"{f(r['diff'])} ({f(r['lo'])} to {f(r['hi'])})".replace('+','') if False else f"{f(r['diff'])} ({f(r['lo'])} to {f(r['hi'])})"
IDX=['Red-cell count','MCV','RDW','Haemoglobin']
rows=[]
for k,lab in [('kit','Primary'),('strict','Strict exclusion')]:
    w=W[k]
    for win in ['0-1 y','1-3 y','3-5 y','5-10 y']:
        s=w[w.window==win].set_index('index'); n=s.loc['Red-cell count']
        rows.append([f'{lab}: {win.replace("-","–")} before diagnosis', f"{n.n_cases} / {n.n_controls}"]+[ci(s.loc[i]) for i in IDX])
    if k=='kit':
        o=O.set_index('index')
        rows.append(['Primary: long-standing offset a (0–4 y)', '28 / 280']+[f"{f(o.loc[i,'offset'])} ({f(o.loc[i,'offset_lo'])} to {f(o.loc[i,'offset_hi'])})" for i in IDX])
d=docx.Document('paper/MDS_Supplementary_material.docx')
ps=d.paragraphs
cap=[p for p in ps if p.text.startswith('Table S23.')][0]
fig=[p for p in ps if p.text.startswith('Figure S1.')][0]
t23=d.tables[-1]._tbl
note23=t23.getnext()
def settext(el,text):
    W_='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
    ps_=[el] if el.tag==W_+'p' else el.findall('.//'+W_+'p')
    for p in ps_[1:]: p.getparent().remove(p)
    p=ps_[0]; runs=p.findall(W_+'r')
    for r in runs[1:]: p.remove(r)
    ts=runs[0].findall(W_+'t')
    for x in ts[1:]: runs[0].remove(x)
    ts[0].text=text; ts[0].set('{http://www.w3.org/XML/1998/namespace}space','preserve')
newcap=copy.deepcopy(cap._p); settext(newcap,'Table S24. External validation of the prodrome in EHRSHOT (Stanford Medicine), using the validation kit written before the data were seen (post hoc R26). Case-minus-control differences in age- and sex-standardised units (95% CI from patient-level bootstraps).')
tbl=copy.deepcopy(t23)
W_='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
trs=tbl.findall(W_+'tr'); hdr,tmpl=trs[0],trs[1]
for tr in trs[1:]: tbl.remove(tr)
for c,txt in zip(hdr.findall(W_+'tc'),['Analysis and window','Cases / controls','Red-cell count','MCV','RDW','Haemoglobin']): settext(c,txt)
for r in rows:
    tr=copy.deepcopy(tmpl)
    for c,txt in zip(tr.findall(W_+'tc'),r): settext(c,str(txt))
    tbl.append(tr)
note=copy.deepcopy(note23); settext(note,'EHRSHOT v3.2: 6,731 patients, OMOP common data model, accessed through Redivis. Cases: first ICD-10 D46 or ICD-9 238.72–238.75 code (81 patients, of whom 46 had an ICD-10 code). Primary: patients with leukaemia, myeloproliferative neoplasm or aplastic anaemia before MDS (33 cases) or at any time (non-MDS patients) excluded; 28 cases had a CBC before diagnosis (20 at least 1 year and 13 at least 5 years before). Strict: any earlier haematological malignancy also excluded (19 cases; too few for the offset model). Controls matched up to 1:10 on sex and 5-year age band, anchored at a random CBC with an earlier CBC. Simple rules, cases flagged at least 1 year before diagnosis vs controls ever flagged: red-cell signature (red-cell count z < −1 and MCV z > +1) 42.9% vs 14.6%; macrocytic anaemia 28.6% vs 11.1%; MCV > 100 fL and RDW > 15% 25.0% vs 7.5%. Only aggregate results left the analysis computer. MIMIC-IV comparison (Table S16): offsets −0.70 (red-cell count), +0.72 (MCV), +0.47 (RDW).')
fig._p.addprevious(newcap); fig._p.addprevious(tbl); fig._p.addprevious(note)
d.save('paper/MDS_Supplementary_material.docx')
for r in rows: print(r)
