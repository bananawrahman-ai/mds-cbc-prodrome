"""Writes example_patients.csv and example_cbc.csv: SYNTHETIC data (no real patients) in the kit's input format,
for testing run_validation.py before real data are used. MDS patients are simulated with a lower red-cell count and a
higher MCV and RDW in the years before diagnosis, so the kit should recover a negative red-cell offset."""
import numpy as np, pandas as pd
rng = np.random.RandomState(1); P, C = [], []
for i in range(4000):
    mds = i < 120; sex = rng.choice(['M', 'F']); by = int(rng.randint(1925, 1975))
    dx = pd.Timestamp('2016-01-01') + pd.Timedelta(days=int(rng.randint(0, 2500))) if mds else pd.NaT
    P.append(dict(patient_id=f'P{i:05d}', sex=sex, birth_year=by, mds_date='' if pd.isna(dx) else dx.date().isoformat(), exclude=int(rng.rand() < 0.02 and not mds), confirmed=int(mds and rng.rand() < 0.7) if mds else ''))
    n = rng.randint(2, 25); start = pd.Timestamp('2008-01-01'); end = dx if mds else pd.Timestamp('2023-12-31')
    days = np.sort(rng.randint(0, max((end - start).days, 10), n)); base = rng.normal(0, 1, 4)
    for d in days:
        t = start + pd.Timedelta(days=int(d)); yb = (end - t).days / 365.25 if mds else 99
        eff = (0.6 + 0.5 * max(0, 4 - yb)) if mds else 0
        hb = 13.5 - (1 if sex == 'F' else 0) + 0.8 * base[0] - 0.6 * eff + rng.normal(0, .5)
        rbc = 4.6 - (0.4 if sex == 'F' else 0) + 0.3 * base[1] - 0.25 * eff + rng.normal(0, .15)
        mcv = 90 + 3 * base[2] + 3 * eff + rng.normal(0, 1.5); rdw = 13.5 + 0.6 * base[3] + 0.6 * eff + rng.normal(0, .4)
        C.append(dict(patient_id=f'P{i:05d}', date=t.date().isoformat(), hb=round(hb, 1), rbc=round(rbc, 2), mcv=round(mcv, 1), rdw=round(rdw, 1),
                      plt=int(max(20, rng.normal(240 - 30 * eff, 50))), wbc=round(max(1, rng.normal(7, 1.5)), 1), anc=round(max(0.3, rng.normal(4.2, 1.1)), 2),
                      setting=rng.choice(['outpatient', 'inpatient'], p=[.8, .2])))
pd.DataFrame(P).to_csv('example_patients.csv', index=False); pd.DataFrame(C).to_csv('example_cbc.csv', index=False)
print('wrote example_patients.csv and example_cbc.csv (synthetic)')
