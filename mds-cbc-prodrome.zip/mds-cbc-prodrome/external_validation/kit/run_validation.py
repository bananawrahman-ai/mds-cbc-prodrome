"""
External validation kit: blood-count changes years before myelodysplastic syndrome (MDS)
=========================================================================================
Runs entirely inside the partner hospital. It reads two de-identified files and writes ONLY aggregate results
(group means, confidence intervals, counts of at least 5). No patient-level data leave the hospital.

Inputs (CSV, UTF-8, one header row; see data_template.xlsx and README.txt)
  patients.csv : patient_id, sex (M/F), birth_year, mds_date (YYYY-MM-DD, blank for non-MDS patients),
                 exclude (1 = leukaemia, myeloproliferative neoplasm or aplastic anaemia diagnosed before mds_date,
                 or ever for non-MDS patients; else 0), confirmed (optional: 1 = MDS confirmed by bone-marrow pathology)
  cbc.csv      : patient_id, date (YYYY-MM-DD), hb (g/dL), rbc (x10^12/L), mcv (fL), rdw (%), plt (x10^9/L),
                 wbc (x10^9/L), anc (optional, x10^9/L), setting (optional: inpatient/outpatient)

Usage:  python run_validation.py --patients patients.csv --cbc cbc.csv --out results
Needs:  Python 3.8+, numpy, pandas (openpyxl optional, for one Excel workbook of the results)

Analyses (same definitions as the MIMIC-IV study, protocol v2.0 and amendments):
  1. Cohort description.
  2. Every CBC is converted to a z-score against one random CBC per non-MDS patient (median and IQR/1.349 within
     sex x age band). Each MDS patient is matched to up to 10 non-MDS patients of the same sex and 5-year age band,
     each anchored at a random CBC that has at least one earlier CBC (pseudo-diagnosis date).
  3. Case-minus-control difference in patient-mean z-scores in windows 0-1, 1-3, 3-5 and 5-10 years before diagnosis
     (patient-level bootstrap, 1,000 resamples).
  4. Offset-plus-acceleration model d(t) = a + b*max(tau - t, 0) over 10 years in 1-year bins with at least 10 cases;
     the long-standing offset a with bootstrap CI (300 resamples).
  5. Simple CBC rules as silent alerts: share of MDS patients with an alerting CBC >= 30 days and >= 1 year before
     diagnosis, and share of matched non-MDS patients ever alerted before their anchor.
Cells with fewer than 5 patients are suppressed.
"""
import argparse, json, sys
from pathlib import Path
import numpy as np, pandas as pd

VERSION = '1.0 (16 October 2026)'
IDX = ['hb', 'rbc', 'mcv', 'rdw', 'plt', 'wbc', 'anc']
NAMES = {'hb': 'Haemoglobin', 'rbc': 'Red-cell count', 'mcv': 'MCV', 'rdw': 'RDW', 'plt': 'Platelets', 'wbc': 'White-cell count', 'anc': 'Neutrophil count'}
RANGE = {'hb': (2, 25), 'rbc': (0.5, 9), 'mcv': (40, 150), 'rdw': (8, 40), 'plt': (1, 3000), 'wbc': (0.1, 500), 'anc': (0, 300)}
MIN_CELL = 5; SEED = 20261016

def band(age):
    return pd.cut(age, [-1, 49.99, 59.99, 69.99, 79.99, 200], labels=['<50', '50-59', '60-69', '70-79', '>=80']).astype(str)

def load(pfile, cfile):
    p = pd.read_csv(pfile, dtype={'patient_id': str}); c = pd.read_csv(cfile, dtype={'patient_id': str})
    p.columns = [x.strip().lower() for x in p.columns]; c.columns = [x.strip().lower() for x in c.columns]
    need_p = ['patient_id', 'sex', 'birth_year', 'mds_date', 'exclude']; need_c = ['patient_id', 'date', 'hb', 'rbc', 'mcv', 'rdw', 'plt', 'wbc']
    miss = [x for x in need_p if x not in p] + [x for x in need_c if x not in c]
    if miss: sys.exit(f'Missing columns: {miss}. See README.txt.')
    p['sex'] = p.sex.astype(str).str.upper().str[0]; p = p[p.sex.isin(['M', 'F'])]
    p['mds_date'] = pd.to_datetime(p.mds_date, errors='coerce'); p['exclude'] = pd.to_numeric(p.exclude, errors='coerce').fillna(0).astype(int)
    p['confirmed'] = pd.to_numeric(p['confirmed'], errors='coerce') if 'confirmed' in p else np.nan
    p = p.drop_duplicates('patient_id').set_index('patient_id')
    c['date'] = pd.to_datetime(c.date, errors='coerce'); c = c.dropna(subset=['date'])
    if 'anc' not in c: c['anc'] = np.nan
    if 'setting' not in c: c['setting'] = 'unknown'
    for v in IDX:
        c[v] = pd.to_numeric(c[v], errors='coerce'); lo, hi = RANGE[v]; c.loc[~c[v].between(lo, hi), v] = np.nan
    c = c[c.patient_id.isin(p.index)].dropna(subset=['hb', 'plt', 'wbc'], how='all')
    c = c.groupby(['patient_id', 'date'], as_index=False).agg({**{v: 'median' for v in IDX}, 'setting': 'first'})
    c['sex'] = p.sex.reindex(c.patient_id).values; c['age'] = c.date.dt.year - p.birth_year.reindex(c.patient_id).values
    return p, c[c.age >= 18]

def zscores(c, ref):
    ref = ref.assign(k=ref.sex + '|' + band(ref.age)); med = ref.groupby('k')[IDX].median()
    sd = ((ref.groupby('k')[IDX].quantile(.75) - ref.groupby('k')[IDX].quantile(.25)) / 1.349).where(lambda x: x > 0)
    n = ref.groupby('k').size(); small = n[n < 30].index
    sexmed = ref.groupby('sex')[IDX].median(); sexsd = ((ref.groupby('sex')[IDX].quantile(.75) - ref.groupby('sex')[IDX].quantile(.25)) / 1.349)
    for k in small:
        s = k.split('|')[0]; med.loc[k] = sexmed.loc[s]; sd.loc[k] = sexsd.loc[s]
    k = c.sex + '|' + band(c.age); z = c.copy()
    for v in IDX:
        m_ = med[v].reindex(k).values; s_ = sd[v].reindex(k).values; z[v] = (c[v].values - m_) / s_
    return z

def build(p, c, rng):
    cases = p[p.mds_date.notna() & (p.exclude == 0)].copy()
    first = c.groupby('patient_id').date.min(); cases = cases[first.reindex(cases.index) < cases.mds_date]
    cases['age_dx'] = cases.mds_date.dt.year - cases.birth_year; cases['stratum'] = cases.sex + '|' + (np.floor(cases.age_dx / 5) * 5).astype(int).astype(str)
    ctrl_ids = p.index[p.mds_date.isna() & (p.exclude == 0)]
    cc = c[c.patient_id.isin(ctrl_ids)].sort_values(['patient_id', 'date'])
    cc = cc[cc.groupby('patient_id').cumcount() >= 1]           # anchor must have an earlier CBC
    anc = cc.assign(r=rng.rand(len(cc))).sort_values('r').drop_duplicates('patient_id')[['patient_id', 'date', 'sex', 'age']]
    anc['stratum'] = anc.sex + '|' + (np.floor(anc.age / 5) * 5).astype(int).astype(str)
    parts, short = [], 0
    for s, k in (cases.stratum.value_counts() * 10).items():
        pool = anc[anc.stratum == s]; n = min(k, len(pool)); short += k - n
        if n: parts.append(pool.sample(n, random_state=rng.randint(1e9)))
    ctrl = pd.concat(parts) if parts else anc.iloc[:0]
    ctrl = ctrl.rename(columns={'date': 'anchor'}).set_index('patient_id')
    hc = c[c.patient_id.isin(cases.index)].copy(); hc['anchor'] = cases.mds_date.reindex(hc.patient_id).values; hc['case'] = 1
    hm = c[c.patient_id.isin(ctrl.index)].copy(); hm['anchor'] = ctrl.anchor.reindex(hm.patient_id).values; hm['case'] = 0
    h = pd.concat([hc, hm]); h = h[h.date < h.anchor].copy(); h['years_before'] = (h.anchor - h.date).dt.days / 365.25
    ref = c[c.patient_id.isin(ctrl_ids)].assign(r=rng.rand((c.patient_id.isin(ctrl_ids)).sum())).sort_values('r').drop_duplicates('patient_id')
    return cases, ctrl, h, ref, short

def boot_diff(d, v, B, rng):
    pm = d.groupby(['patient_id', 'case'])[v].mean().dropna().reset_index(); a = pm[pm.case == 1][v].values; b = pm[pm.case == 0][v].values
    if len(a) < MIN_CELL or len(b) < MIN_CELL: return dict(n_cases=len(a), n_controls=len(b), diff=np.nan, lo=np.nan, hi=np.nan)
    bs = [rng.choice(a, len(a)).mean() - rng.choice(b, len(b)).mean() for _ in range(B)]
    return dict(n_cases=len(a), n_controls=len(b), diff=a.mean() - b.mean(), lo=np.percentile(bs, 2.5), hi=np.percentile(bs, 97.5))

def offset_model(h, v, B, rng, min_cases=10):
    d = h[h.years_before <= 10].copy(); d['bin'] = np.minimum(np.floor(d.years_before), 9).astype(int)
    pm = d.groupby(['patient_id', 'case', 'bin'])[v].mean().dropna().reset_index()
    ids = {k: pm[pm.case == k].patient_id.unique() for k in (0, 1)}
    mid = np.arange(10) + 0.5
    def curve(sel1, sel0):
        x1 = pm[pm.patient_id.isin(sel1) & (pm.case == 1)]; x0 = pm[pm.patient_id.isin(sel0) & (pm.case == 0)]
        w1 = pd.Series(sel1).value_counts(); w0 = pd.Series(sel0).value_counts()
        m1 = (x1.assign(w=w1.reindex(x1.patient_id).values).pipe(lambda q: (q[v] * q.w).groupby(q.bin).sum() / q.w.groupby(q.bin).sum())).reindex(range(10))
        m0 = (x0.assign(w=w0.reindex(x0.patient_id).values).pipe(lambda q: (q[v] * q.w).groupby(q.bin).sum() / q.w.groupby(q.bin).sum())).reindex(range(10))
        return (m1 - m0).values
    n1 = pm[pm.case == 1].groupby('bin').patient_id.nunique().reindex(range(10)).fillna(0).values
    mask = n1 >= min_cases
    if mask.sum() < 3: return None
    def fit(dv):
        best = (np.inf, np.nan, np.nan)
        for tau in np.arange(0.5, 9.51, 0.25):
            x = np.maximum(tau - mid, 0)[mask]; y = dv[mask]; ok = ~np.isnan(y)
            if (x[ok] > 0).sum() < 2 or (x[ok] == 0).sum() < 1: continue
            A = np.c_[np.ones(ok.sum()), x[ok]]; coef = np.linalg.lstsq(A, y[ok], rcond=None)[0]; sse = ((y[ok] - A @ coef) ** 2).sum()
            if sse < best[0]: best = (sse, tau, coef[0])
        return best[1], best[2]
    tau, a = fit(curve(ids[1], ids[0]))
    bt = np.array([fit(curve(rng.choice(ids[1], len(ids[1])), rng.choice(ids[0], len(ids[0])))) for _ in range(B)], float)
    return dict(offset=a, offset_lo=np.nanpercentile(bt[:, 1], 2.5), offset_hi=np.nanpercentile(bt[:, 1], 97.5), tau=tau,
                bins_used=int(mask.sum()), years_covered=float(mid[mask].max() + 0.5))

def rules(h, cases, ctrl):
    male = h.sex == 'M'; anaemia = h.hb < np.where(male, 13, 12)
    R = {'Macrocytic anaemia (MCV > 100 fL and anaemia)': (h.mcv > 100) & anaemia,
         'MCV > 100 fL and RDW > 15%': (h.mcv > 100) & (h.rdw > 15),
         'Red-cell signature (red-cell count z < -1 and MCV z > +1)': (h.z_rbc < -1) & (h.z_mcv > 1),
         'Two or more cytopenias': (anaemia.astype(int) + (h.plt < 150).astype(int) + (h.anc < 1.8).astype(int)) >= 2}
    out = []
    for name, flag in R.items():
        a = h[flag]
        c30 = a[(a.case == 1) & (a.years_before >= 30 / 365.25)].patient_id.nunique(); c1y = a[(a.case == 1) & (a.years_before >= 1)].patient_id.nunique()
        k = a[a.case == 0].patient_id.nunique()
        out.append(dict(rule=name, cases=len(cases), cases_alerted_ge30d=c30, pct_ge30d=100 * c30 / len(cases), cases_alerted_ge1y=c1y,
                        pct_ge1y=100 * c1y / len(cases), controls=len(ctrl), controls_ever_alerted=k, pct_controls=100 * k / max(len(ctrl), 1)))
    return pd.DataFrame(out)

def suppress(df, cols_n):
    df = df.copy()
    for c in cols_n:
        if c in df: df[c] = df[c].astype(object).where(~(pd.to_numeric(df[c], errors='coerce') < MIN_CELL), f'<{MIN_CELL}')
    return df

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('--patients', required=True); ap.add_argument('--cbc', required=True)
    ap.add_argument('--out', default='results'); ap.add_argument('--quick', action='store_true'); a = ap.parse_args()
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True); rng = np.random.RandomState(SEED); B1, B2 = (200, 60) if a.quick else (1000, 300)
    p, c = load(a.patients, a.cbc)
    cases, ctrl, h, ref, short = build(p, c, rng)
    z = zscores(h, ref)
    for v in IDX: h['z_' + v] = z[v].values
    log = {'kit_version': VERSION, 'patients_in_file': int(len(p)), 'cbcs_used': int(len(c)), 'mds_patients_in_file': int(p.mds_date.notna().sum()),
           'mds_excluded_other_haem_before_dx': int((p.mds_date.notna() & (p.exclude == 1)).sum()),
           'mds_cases_with_cbc_before_dx': int(len(cases)), 'matched_controls': int(len(ctrl)), 'control_shortfall': int(short),
           'cases_with_cbc_1y_before': int(h[(h.case == 1) & (h.years_before >= 1)].patient_id.nunique()),
           'cases_with_cbc_5y_before': int(h[(h.case == 1) & (h.years_before >= 5)].patient_id.nunique()),
           'cases_marrow_confirmed': int((cases.confirmed == 1).sum()) if 'confirmed' in cases else None}
    # 1 description
    def desc(ids, anchor_age, grp):
        hh = h[h.patient_id.isin(ids)]; n = len(ids); cnt = hh.groupby('patient_id').size().reindex(ids).fillna(0)
        yrs = hh.groupby('patient_id').years_before.max().reindex(ids)
        return dict(group=grp, patients=n, age_median=float(np.median(anchor_age)) if n else np.nan, male_pct=100 * float((p.sex.reindex(ids) == 'M').mean()) if n else np.nan,
                    cbcs_before_median=float(cnt.median()) if n else np.nan, years_history_median=float(yrs.median()) if n else np.nan)
    D = pd.DataFrame([desc(cases.index, cases.age_dx, 'MDS'), desc(ctrl.index, ctrl.age, 'Matched non-MDS')])
    # 2 windows
    W = []
    for lo, hi in [(0, 1), (1, 3), (3, 5), (5, 10)]:
        d = h[(h.years_before > lo) & (h.years_before <= hi)]
        for v in IDX:
            r = boot_diff(d.rename(columns={'z_' + v: 'zz'}), 'zz', B1, rng); W.append(dict(window=f'{lo}-{hi} y', index=NAMES[v], **r))
    W = pd.DataFrame(W)
    # 3 offset model
    O = []
    for v in ['rbc', 'mcv', 'rdw', 'hb', 'plt']:
        r = offset_model(h.rename(columns={'z_' + v: 'zz'}), 'zz', B2, rng)
        O.append(dict(index=NAMES[v], **(r or dict(offset=np.nan, offset_lo=np.nan, offset_hi=np.nan, tau=np.nan, bins_used=0, years_covered=np.nan))))
    O = pd.DataFrame(O)
    # 3b confirmed cases only
    if (cases.confirmed == 1).sum() >= 20:
        hc = h[(h.case == 0) | h.patient_id.isin(cases.index[cases.confirmed == 1])]
        for v in ['rbc', 'mcv', 'rdw']:
            r = boot_diff(hc[(hc.years_before > 1) & (hc.years_before <= 10)].rename(columns={'z_' + v: 'zz'}), 'zz', B1, rng)
            W = pd.concat([W, pd.DataFrame([dict(window='1-10 y, marrow-confirmed cases', index=NAMES[v], **r)])])
    # 4 rules
    Rl = rules(h, cases, ctrl)
    # write (aggregates only, small cells suppressed)
    D = suppress(D, ['patients']); W = suppress(W, ['n_cases', 'n_controls']); Rl = suppress(Rl, ['cases_alerted_ge30d', 'cases_alerted_ge1y', 'controls_ever_alerted'])
    W.loc[W.n_cases.astype(str).str.startswith('<'), ['diff', 'lo', 'hi']] = np.nan
    for cnt, pct in [('cases_alerted_ge30d', 'pct_ge30d'), ('cases_alerted_ge1y', 'pct_ge1y'), ('controls_ever_alerted', 'pct_controls')]:
        Rl.loc[Rl[cnt].astype(str).str.startswith('<'), pct] = np.nan
    D.round(2).to_csv(out / '1_description.csv', index=False); W.round(3).to_csv(out / '2_window_differences.csv', index=False)
    O.round(3).to_csv(out / '3_offset_model.csv', index=False); Rl.round(1).to_csv(out / '4_simple_rules.csv', index=False)
    json.dump(log, open(out / '0_counts.json', 'w'), indent=1)
    try:
        with pd.ExcelWriter(out / 'external_validation_results.xlsx') as xw:
            pd.DataFrame(list(log.items()), columns=['item', 'value']).to_excel(xw, sheet_name='0_counts', index=False)
            D.round(2).to_excel(xw, sheet_name='1_description', index=False); W.round(3).to_excel(xw, sheet_name='2_windows', index=False)
            O.round(3).to_excel(xw, sheet_name='3_offset_model', index=False); Rl.round(1).to_excel(xw, sheet_name='4_rules', index=False)
    except Exception as ex:
        print('Excel file not written (install openpyxl); CSV files are complete.', ex)
    print(json.dumps(log, indent=1)); print(O.round(2).to_string(index=False)); print('DONE. Send the files in', out.resolve(), '(aggregate results only).')

if __name__ == '__main__':
    main()
