EXTERNAL VALIDATION KIT - blood-count changes before myelodysplastic syndrome (MDS)
Version 1.0, 16 October 2026

What it does
  Repeats the main analysis of the MIMIC-IV study in your hospital's data: are the red-cell count lower and the MCV and
  RDW higher years before MDS is diagnosed, compared with matched patients without MDS? It also tests four simple CBC
  alert rules. Everything runs on your own computer. Only aggregate tables (means, confidence intervals, counts of 5 or
  more) are written; no patient-level data leave the hospital.

Steps
  1. Install Python 3.8 or newer with numpy and pandas (openpyxl optional):  pip install numpy pandas openpyxl
  2. Test the kit with synthetic data:
        python make_example_data.py
        python run_validation.py --patients example_patients.csv --cbc example_cbc.csv --out example_results
     The example data are invented; the red-cell count offset should come out negative.
  3. Prepare patients.csv and cbc.csv from your data, following data_template.xlsx (de-identified IDs, birth year only).
  4. Run:  python run_validation.py --patients patients.csv --cbc cbc.csv --out results
  5. Check the files in the results folder, then send them (and nothing else) to the study team:
        0_counts.json, 1_description.csv, 2_window_differences.csv, 3_offset_model.csv, 4_simple_rules.csv
        (and external_validation_results.xlsx if written).

Who should be included
  All adult patients with at least two CBCs during the study period. MDS patients: mds_date = date of diagnosis.
  Patients with leukaemia, myeloproliferative neoplasm or aplastic anaemia before MDS (or ever, if no MDS): exclude = 1.

Minimum useful size
  About 30 MDS patients with a CBC at least one year before diagnosis.

Contact: study team (see the cover letter).
