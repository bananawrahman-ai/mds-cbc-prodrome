-- MIMIC-IV-Note: discharge summaries of the MDS cases (R25).
-- Run in Google BigQuery with credentialed PhysioNet access, then save the result as CSV
-- to data/raw/note/mds_case_discharge_notes.csv on your own computer.
-- Replace <CASE_SUBJECT_IDS> with the comma-separated subject_id list of the cases in
-- data/processed/mds_case_info.csv.gz (built by src/33_mds_history.py). The list itself is
-- derived from credentialed data and is therefore not included in this repository.
SELECT note_id, subject_id, hadm_id, note_type, note_seq, charttime, storetime, text
FROM `physionet-data.mimiciv_note.discharge`
WHERE subject_id IN (<CASE_SUBJECT_IDS>)
ORDER BY subject_id, charttime;
