"""Models, comparators and clinical-utility analysis for the pre-diagnostic
early-detection study (protocol: docs/prediagnostic_protocol.md v1.0).

Requires: numpy, pandas, scikit-learn (>=1.3). Optional: xgboost, lightgbm
(added as extra candidates if importable), matplotlib (figures), shap.

Usage:
    python src/13_prediag_models.py            # full protocol run
    python src/13_prediag_models.py --quick    # fast smoke test (small grids, 1 repeat)

Outputs go to results/prediag/models/ (tables, report.md, figures).
Nothing in this script looks at the test split or the temporal holdout before
the corresponding model and threshold are fixed on development data.
"""
import argparse, json, sys, time, warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.impute import SimpleImputer
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, brier_score_loss, roc_auc_score
from sklearn.model_selection import GridSearchCV, RepeatedStratifiedKFold, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings('ignore', category=FutureWarning)
warnings.filterwarnings('ignore', category=UserWarning)

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
try:
    import config as cfg
    DEF_COHORT = cfg.PROC / 'prediag_cohort.csv.gz'
    DEF_OUT = cfg.RESULTS / 'prediag' / 'models'
except Exception:  # standalone use
    DEF_COHORT = ROOT / 'data' / 'processed' / 'prediag_cohort.csv.gz'
    DEF_OUT = ROOT / 'results' / 'prediag' / 'models'

CORE = ['hemoglobin', 'hematocrit', 'rbc', 'wbc', 'platelet', 'mcv', 'mch', 'mchc', 'rdw']
DIFF = ['neutrophils_pct', 'lymphocytes_pct', 'monocytes_pct', 'eosinophils_pct', 'basophils_pct']
FEATURES = CORE + ['age_approx', 'gender_bin'] + DIFF
SEED = 20260927

ap = argparse.ArgumentParser()
ap.add_argument('--cohort', default=str(DEF_COHORT))
ap.add_argument('--outdir', default=str(DEF_OUT))
ap.add_argument('--quick', action='store_true')
ap.add_argument('--n-boot', type=int, default=1000)
ap.add_argument('--jobs', type=int, default=-1)
args = ap.parse_args()
OUT = Path(args.outdir); OUT.mkdir(parents=True, exist_ok=True)
N_BOOT = 100 if args.quick else args.n_boot
REPEATS = 1 if args.quick else 5
t0 = time.time()
LOG = open(OUT / 'run.log', 'w')


def log(msg):
    line = f'[{time.time()-t0:7.1f}s] {msg}'
    print(line, flush=True); LOG.write(line + '\n'); LOG.flush()


# ------------------------------------------------------------------ candidates
def candidates(quick):
    lin = lambda **kw: make_pipeline(SimpleImputer(strategy='median', add_indicator=True), StandardScaler(),
                                     LogisticRegression(max_iter=5000, **kw))
    c = {
        'logistic_l2': (lin(), {'logisticregression__C': [0.1] if quick else [0.01, 0.1, 1.0]}),
        'logistic_elasticnet': (lin(solver='saga', penalty='elasticnet', l1_ratio=0.5),
                                {'logisticregression__C': [0.1] if quick else [0.05, 0.5],
                                 'logisticregression__l1_ratio': [0.5] if quick else [0.2, 0.8]}),
        'hist_gradient_boosting': (HistGradientBoostingClassifier(learning_rate=0.05, max_iter=100 if quick else 200,
                                                                  l2_regularization=1.0, random_state=SEED),
                                   {'max_leaf_nodes': [15] if quick else [15, 31],
                                    'min_samples_leaf': [100] if quick else [50, 200]}),
    }
    try:
        from xgboost import XGBClassifier
        c['xgboost'] = (XGBClassifier(n_estimators=100 if quick else 300, learning_rate=0.05, subsample=0.8,
                                      colsample_bytree=0.8, eval_metric='aucpr', tree_method='hist', random_state=SEED,
                                      n_jobs=1),
                        {'max_depth': [3] if quick else [3, 5], 'min_child_weight': [5] if quick else [1, 10]})
    except Exception:
        log('xgboost not installed -> skipped (sklearn HistGradientBoosting covers gradient boosting)')
    try:
        from lightgbm import LGBMClassifier
        c['lightgbm'] = (LGBMClassifier(n_estimators=100 if quick else 300, learning_rate=0.05, subsample=0.8,
                                        subsample_freq=1, colsample_bytree=0.8, random_state=SEED, verbose=-1, n_jobs=1),
                         {'num_leaves': [15] if quick else [15, 31], 'min_child_samples': [50] if quick else [20, 100]})
    except Exception:
        log('lightgbm not installed -> skipped')
    return c


def tuned(est, grid, X, y):
    gs = GridSearchCV(est, grid, scoring='average_precision', cv=StratifiedKFold(3, shuffle=True, random_state=SEED),
                      n_jobs=args.jobs, refit=True, error_score='raise')
    gs.fit(X, y)
    return gs


# ------------------------------------------------------------------ metrics
def boot_ci(y, s, fn, n=N_BOOT, seed=SEED):
    rng = np.random.RandomState(seed); pos = np.where(y == 1)[0]; neg = np.where(y == 0)[0]; v = []
    for _ in range(n):
        idx = np.concatenate([rng.choice(pos, len(pos)), rng.choice(neg, len(neg))])
        v.append(fn(y[idx], s[idx]))
    return np.percentile(v, [2.5, 97.5])


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n; d = 1 + z * z / n; c = p + z * z / (2 * n); h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - h) / d, (c + h) / d)


def calib(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6); lp = np.log(p / (1 - p)).reshape(-1, 1)
    slope = LogisticRegression(C=1e6, max_iter=5000).fit(lp, y).coef_[0][0]
    # calibration-in-the-large: intercept with logit(p) as offset (one-parameter Newton solve)
    a = 0.0
    for _ in range(50):
        q = 1 / (1 + np.exp(-(a + lp.ravel()))); g = (y - q).sum(); h = (q * (1 - q)).sum(); a += g / h
    return a, slope


def summarize(name, y, s):
    auc = roc_auc_score(y, s); ap_ = average_precision_score(y, s)
    a_lo, a_hi = boot_ci(y, s, roc_auc_score); p_lo, p_hi = boot_ci(y, s, average_precision_score)
    return dict(model=name, n=len(y), events=int(y.sum()), auroc=auc, auroc_lo=a_lo, auroc_hi=a_hi,
                ap=ap_, ap_lo=p_lo, ap_hi=p_hi)


def operating_point(y, s, thr, label):
    pred = s >= thr; tp = int((pred & (y == 1)).sum()); fp = int((pred & (y == 0)).sum())
    fn = int((~pred & (y == 1)).sum()); tn = int((~pred & (y == 0)).sum())
    se = tp / max(tp + fn, 1); sp = tn / max(tn + fp, 1); ppv = tp / max(tp + fp, 1)
    return dict(rule=label, threshold=thr, tp=tp, fp=fp, fn=fn, tn=tn, sensitivity=se,
                sens_lo=wilson(tp, tp + fn)[0], sens_hi=wilson(tp, tp + fn)[1], specificity=sp, ppv=ppv,
                ppv_lo=wilson(tp, tp + fp)[0], ppv_hi=wilson(tp, tp + fp)[1],
                flagged_per_case_detected=(tp + fp) / tp if tp else np.inf)


def thr_at_spec(y, s, spec):
    return np.quantile(s[y == 0], spec)


def net_benefit(y, pred, pt):
    n = len(y); tp = (pred & (y == 1)).sum(); fp = (pred & (y == 0)).sum()
    return tp / n - fp / n * pt / (1 - pt)


# ------------------------------------------------------------------ data
coh = pd.read_csv(args.cohort, low_memory=False)
prim = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
assert prim.subject_id.is_unique, 'primary data must have one row per patient'
X = prim[FEATURES].astype(float); y = prim.label.values.astype(int)
has_flags = 'n_flag_core' in prim and prim.n_flag_core.notna().mean() > 0.5
log(f'primary cohort: {len(prim):,} patients, {y.sum()} cases (lead 30-365 d), prevalence {y.mean():.4%}; '
    f'lab flags available: {has_flags}')
json.dump({'features': FEATURES, 'seed': SEED, 'repeats': REPEATS, 'quick': args.quick,
           'n_patients': int(len(prim)), 'n_cases': int(y.sum())}, open(OUT / 'protocol_snapshot.json', 'w'), indent=2)

C = candidates(args.quick)

# ------------------------------------------------------------------ 1. nested repeated CV (primary validation)
outer = RepeatedStratifiedKFold(n_splits=5, n_repeats=REPEATS, random_state=SEED)
oof = {k: np.zeros((REPEATS, len(y))) for k in C}
chosen_params = {k: [] for k in C}
for f, (tr, te) in enumerate(outer.split(X, y)):
    r = f // 5
    for k, (est, grid) in C.items():
        gs = tuned(est, grid, X.iloc[tr], y[tr])
        oof[k][r, te] = gs.predict_proba(X.iloc[te])[:, 1]
        chosen_params[k].append(gs.best_params_)
    log(f'outer fold {f+1}/{5*REPEATS} done')
oof_mean = {k: v.mean(axis=0) for k, v in oof.items()}
rows = [summarize(k, y, s) for k, s in oof_mean.items()]
for k, s in oof_mean.items():
    rows[[r['model'] for r in rows].index(k)]['brier'] = brier_score_loss(y, s)
    ci, cs = calib(y, s); rows[[r['model'] for r in rows].index(k)].update(calib_intercept=ci, calib_slope=cs)
if has_flags:
    fl = prim.n_flag_core.fillna(0).values
    r = summarize('lab_flag_count (comparator)', y, fl); rows.append(r)
cv = pd.DataFrame(rows).sort_values('ap', ascending=False)
cv.to_csv(OUT / 'nested_cv_discrimination.csv', index=False)
pd.DataFrame({k: [json.dumps(p) for p in v] for k, v in chosen_params.items()}).to_csv(OUT / 'nested_cv_chosen_params.csv', index=False)
model_rows = cv[~cv.model.str.contains('comparator')]
best = model_rows.iloc[0].model
log('nested CV results:\n' + cv.round(4).to_string(index=False))
log(f'PRIMARY MODEL (highest outer-CV average precision): {best}')
s_best = oof_mean[best]
pd.DataFrame({'subject_id': prim.subject_id, 'label': y, **{f'oof_{k}': v for k, v in oof_mean.items()}}).to_csv(
    OUT / 'oof_predictions.csv.gz', index=False, compression='gzip')

# ------------------------------------------------------------------ 2. clinical utility vs laboratory flags (OOF)
ops = []
for spec in (0.90, 0.95, 0.99):
    ops.append(operating_point(y, s_best, thr_at_spec(y, s_best, spec), f'{best} @ specificity {spec:.0%}'))
    ops.append(operating_point(y, oof_mean['logistic_l2'], thr_at_spec(y, oof_mean['logistic_l2'], spec),
                               f'logistic_l2 @ specificity {spec:.0%}'))
if has_flags:
    for k in range(1, 6):
        ops.append(operating_point(y, fl, k, f'lab flags: >= {k} core parameter(s) flagged abnormal'))
    # model at the specificity of the commonest flag rules
    for k in (1, 2, 3):
        sp = ((fl < k) & (y == 0)).sum() / (y == 0).sum()
        if sp < 1:
            ops.append(operating_point(y, s_best, thr_at_spec(y, s_best, sp),
                                       f'{best} @ matched specificity of ">= {k} flag(s)" ({sp:.1%})'))
ops = pd.DataFrame(ops); ops.to_csv(OUT / 'operating_points_oof.csv', index=False)
log('operating points:\n' + ops[['rule', 'sensitivity', 'specificity', 'ppv', 'flagged_per_case_detected']].round(4).to_string(index=False))

pts = np.array([0.0005, 0.001, 0.002, 0.005, 0.01, 0.02, 0.05])
dca = pd.DataFrame({'threshold': pts, 'treat_all': [net_benefit(y, np.ones_like(y, bool), p) for p in pts], 'treat_none': 0.0,
                    best: [net_benefit(y, s_best >= p, p) for p in pts],
                    'logistic_l2': [net_benefit(y, oof_mean['logistic_l2'] >= p, p) for p in pts]})
if has_flags:
    for k in (1, 3):
        dca[f'lab_flags_>={k}'] = [net_benefit(y, fl >= k, p) for p in pts]
dca.to_csv(OUT / 'decision_curve_oof.csv', index=False)

cal = pd.DataFrame({'p': s_best, 'y': y}); cal['bin'] = pd.qcut(cal.p.rank(method='first'), 10, labels=False)
cal.groupby('bin').agg(mean_predicted=('p', 'mean'), observed=('y', 'mean'), n=('y', 'size')).to_csv(OUT / 'calibration_bins_oof.csv')

# ------------------------------------------------------------------ 3. subgroups (OOF, primary model)
thr95 = thr_at_spec(y, s_best, 0.95); sg = []
age_band = pd.cut(prim.age_approx, [0, 50, 70, 200], right=False, labels=['<50', '50-69', '>=70'])
for col, ser in [('sex', prim.gender), ('age_band', age_band), ('race_group', prim.race_group), ('setting', prim.setting)]:
    for lev, idx in prim.groupby(ser, observed=True).groups.items():
        yy = y[idx]; ss = s_best[idx]
        if yy.sum() >= 5 and (yy == 0).sum() >= 5:
            sg.append(dict(variable=col, level=lev, n=len(idx), events=int(yy.sum()), auroc=roc_auc_score(yy, ss),
                           sens_at_spec95=((ss >= thr95) & (yy == 1)).sum() / yy.sum()))
for lev, idx in prim[prim.label == 1].groupby('subtype').groups.items():
    ss = s_best[idx]
    sg.append(dict(variable='subtype (cases only)', level=lev, n=len(idx), events=len(idx), auroc=np.nan,
                   sens_at_spec95=(ss >= thr95).mean()))
pd.DataFrame(sg).to_csv(OUT / 'subgroups_oof.csv', index=False)

# ------------------------------------------------------------------ 4. single pre-assigned holdout + lead-time windows
est, grid = C[best]
dev = prim[prim.split == 'dev']; test_ctrl = coh[(coh.split == 'test') & (coh.window == 'control')]
gs = tuned(est, grid, dev[FEATURES].astype(float), dev.label.values)
dev_oof = np.zeros(len(dev))
for tr, te in StratifiedKFold(5, shuffle=True, random_state=SEED).split(dev, dev.label):
    m = clone(gs.best_estimator_).fit(dev[FEATURES].iloc[tr].astype(float), dev.label.values[tr])
    dev_oof[te] = m.predict_proba(dev[FEATURES].iloc[te].astype(float))[:, 1]
thr_dev95 = thr_at_spec(dev.label.values, dev_oof, 0.95)   # threshold frozen on development data
final = gs.best_estimator_
hold = []
for w in ['lead_0_29', 'lead_30_365', 'lead_366_730']:
    te = pd.concat([test_ctrl, coh[(coh.split == 'test') & (coh.window == w)]])
    yt = te.label.values; st_ = final.predict_proba(te[FEATURES].astype(float))[:, 1]
    r = summarize(f'{best} holdout, cases {w}', yt, st_) if yt.sum() >= 3 else dict(model=f'{best} holdout, cases {w}', events=int(yt.sum()))
    r.update({k: v for k, v in operating_point(yt, st_, thr_dev95, 'dev-frozen spec95 threshold').items()
              if k in ('sensitivity', 'sens_lo', 'sens_hi', 'specificity', 'ppv', 'tp', 'fn')})
    hold.append(r)
hold = pd.DataFrame(hold); hold.to_csv(OUT / 'holdout_by_lead_time.csv', index=False)
log('single holdout by lead-time window:\n' + hold.round(4).to_string(index=False))

# ------------------------------------------------------------------ 5. temporal validation
early = ['2008 - 2010', '2011 - 2013', '2014 - 2016']
tr_t = prim[prim.anchor_year_group.isin(early)]; te_t = prim[~prim.anchor_year_group.isin(early)]
temporal = []
if te_t.label.sum() >= 5:
    for k in dict.fromkeys([best, 'logistic_l2']):
        e_, g_ = C[k]
        gt = tuned(e_, g_, tr_t[FEATURES].astype(float), tr_t.label.values)
        s_t = gt.predict_proba(te_t[FEATURES].astype(float))[:, 1]
        temporal.append(summarize(f'{k} temporal (train 2008-2016, test 2017-2022)', te_t.label.values, s_t))
    if has_flags:
        temporal.append(summarize('lab_flag_count temporal test', te_t.label.values, te_t.n_flag_core.fillna(0).values))
pd.DataFrame(temporal).to_csv(OUT / 'temporal_validation.csv', index=False)
log('temporal validation:\n' + pd.DataFrame(temporal).round(4).to_string(index=False))

# ------------------------------------------------------------------ 6. explanation (permutation importance on holdout)
te_all = pd.concat([test_ctrl, coh[(coh.split == 'test') & (coh.window == 'lead_30_365')]])
pi = permutation_importance(final, te_all[FEATURES].astype(float), te_all.label.values, scoring='average_precision',
                            n_repeats=5 if args.quick else 20, random_state=SEED, n_jobs=args.jobs)
pd.DataFrame({'feature': FEATURES, 'ap_drop_mean': pi.importances_mean, 'ap_drop_sd': pi.importances_std}).sort_values(
    'ap_drop_mean', ascending=False).to_csv(OUT / 'permutation_importance_holdout.csv', index=False)

# ------------------------------------------------------------------ 7. figures (optional)
try:
    import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
    from sklearn.metrics import roc_curve, precision_recall_curve
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.5))
    for k in dict.fromkeys([best, 'logistic_l2']):
        fpr, tpr, _ = roc_curve(y, oof_mean[k]); ax[0].plot(fpr, tpr, label=k)
        pr, rc, _ = precision_recall_curve(y, oof_mean[k]); ax[1].plot(rc, pr, label=k)
    if has_flags:
        fpr, tpr, _ = roc_curve(y, fl); ax[0].plot(fpr, tpr, 'o--', label='lab flag count')
    ax[0].plot([0, 1], [0, 1], ':', c='grey'); ax[0].set(xlabel='1 - specificity', ylabel='sensitivity', title='ROC (nested CV)')
    ax[1].set(xlabel='recall', ylabel='precision', title='Precision-recall (nested CV)')
    for c_ in [c for c in dca.columns if c != 'threshold']:
        ax[2].plot(dca.threshold, dca[c_], marker='.', label=c_)
    ax[2].set(xscale='log', xlabel='threshold probability', ylabel='net benefit', title='Decision curve')
    ax[2].set_ylim(min(-0.0005, dca.drop(columns='threshold').min().min()), dca.drop(columns='threshold').max().max() * 1.2 + 1e-5)
    for a in ax: a.legend(fontsize=7)
    fig.tight_layout(); fig.savefig(OUT / 'figures_roc_pr_dca.png', dpi=200)
except Exception as e:
    log(f'figures skipped: {e}')

# ------------------------------------------------------------------ report
with open(OUT / 'report.md', 'w') as f:
    f.write('# Pre-diagnostic early-detection models\n\n')
    f.write(f'Primary cohort {len(prim):,} patients, {y.sum()} cases (first recorded leukaemia 30-365 d after index CBC).\n\n')
    f.write(f'Primary model (highest nested-CV average precision): **{best}**.\n\n')
    for title, fn in [('Nested CV discrimination', 'nested_cv_discrimination.csv'), ('Operating points (OOF)', 'operating_points_oof.csv'),
                      ('Holdout by lead time', 'holdout_by_lead_time.csv'), ('Temporal validation', 'temporal_validation.csv'),
                      ('Subgroups', 'subgroups_oof.csv'), ('Permutation importance', 'permutation_importance_holdout.csv')]:
        d = pd.read_csv(OUT / fn)
        try:
            tbl = d.round(4).to_markdown(index=False)
        except ImportError:
            tbl = '```\n' + d.round(4).to_string(index=False) + '\n```'
        f.write(f'## {title}\n\n' + tbl + '\n\n')
log('ALL_DONE')
