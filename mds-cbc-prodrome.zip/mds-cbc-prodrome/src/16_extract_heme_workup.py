"""Earliest haematology/oncology work-up test per patient (for amendment A3).

Scans labevents for tests that indicate a patient was already under haematological
evaluation: blood/marrow flow cytometry (CD5, CD19, CD52, immunophenotyping,
kappa/lambda), bone-marrow haematology tests, haematology/oncology smear review,
and circulating blasts reported > 0.
Output: data/processed/heme_workup_events.csv.gz (subject_id, category, first_time)
"""
import sys, time
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg

FLOW_BLOOD = [51164, 51165, 51166, 51184, 51185, 51186, 51234, 51238, 51239, 52070, 52091]
MARROW = [51313, 51326, 51327, 51328, 51329, 51330, 51338, 51340, 51341, 52322]
HO_SMEAR = [51219, 51236]
BLASTS = [51148]
cat = {**{i: 'flow_cytometry' for i in FLOW_BLOOD}, **{i: 'bone_marrow' for i in MARROW},
       **{i: 'heme_onc_smear' for i in HO_SMEAR}, **{i: 'blasts_seen' for i in BLASTS}}
d = pd.read_csv(cfg.MIMIC_FILES['d_labitems'])
print(d[d.itemid.isin(cat)][['itemid', 'label', 'fluid']].to_string(index=False), flush=True)
t0 = time.time(); parts = []
for i, ch in enumerate(pd.read_csv(cfg.MIMIC_FILES['labevents'], usecols=['subject_id', 'itemid', 'charttime', 'valuenum'],
                                   chunksize=4_000_000)):
    ch = ch[ch.itemid.isin(cat.keys())]
    ch = ch[(ch.itemid != 51148) | (ch.valuenum > 0)]
    if len(ch):
        ch = ch.assign(category=ch.itemid.map(cat), charttime=pd.to_datetime(ch.charttime, errors='coerce'))
        parts.append(ch.groupby(['subject_id', 'category']).charttime.min().reset_index())
    if i % 5 == 0:
        print(f'chunk {i} ({time.time()-t0:.0f}s)', flush=True)
res = pd.concat(parts).groupby(['subject_id', 'category']).charttime.min().reset_index().rename(columns={'charttime': 'first_time'})
res.to_csv(cfg.PROC / 'heme_workup_events.csv.gz', index=False, compression='gzip')
print(res.groupby('category').subject_id.nunique())
print('ALL_DONE')
