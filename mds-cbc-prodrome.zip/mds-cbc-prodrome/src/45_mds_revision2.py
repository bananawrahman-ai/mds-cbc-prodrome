"""MDS revision analyses, round 3 (after an independent high-impact-journal review, 10 Oct 2026). All post hoc; amendment R16-R24.
R16 confirmed-case subset (MDS-directed drug ever, marrow test up to t1 + 90 d, >= 2 MDS-coded admissions or MDS as principal
    diagnosis), t1 - t0 distribution, MDS as principal diagnosis at t1.
R17 Aim 1 re-matched: (a) sex x age; (b) + race group; (c) + race, prior CBC count and comorbidity count; (d) harmonised
    control exclusions (haematological codes only before pseudo-t1); (e) haemoglobinopathy and iron deficiency excluded.
R18 comparison outcomes with formal MDS-minus-comparator contrasts: non-malignant (B12/folate deficiency, iron-deficiency
    anaemia, CKD stage 3-5, alcoholic liver disease/cirrhosis, unexplained cytopenia) and malignant (colorectal cancer, myeloma,
    CLL, MPN, AML).
R19 Aim 1 longitudinal estimands: visit-weighted (1/n per patient) model, period-restricted means, random slopes if statsmodels.
R20 Aim 2 with penalised logistic regression: nested SNAP vs FULL, likelihood-ratio test, cross-validated log-loss/Brier/AUROC
    differences against an equivalence margin of 0.01 AUROC; P3 decomposition with bootstrap CIs (baselines >= 1 and >= 4 y).
R21 alert: 20 random seeds; thresholds chosen inside training folds; persistence (>= 2 CBCs >= 14 d apart) and
    outpatient-only rules; confirmed-case yield.
R22 decision curve (net benefit) of the index-CBC model and simple rules; calibration-in-the-large.
R23 age- and sex-adjusted 1-year mortality and AML by alert status.
R24 era check: control CBC indices by anchor-year group; differential availability by case status.
Outputs: results/mds/v2/rev2_*.csv; prints REVISION2_DONE."""
import sys, time, json, traceback
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import roc_auc_score, log_loss, brier_score_loss
from sklearn.model_selection import StratifiedKFold, RepeatedStratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv; BP = 60 if QUICK else 300; NB = 200 if QUICK else 1000; NSEED = 3 if QUICK else 20; BOOT = 40 if QUICK else 200
OUT = cfg.RESULTS / 'mds' / 'v2'; SEED = 20261010; RAW = Path(cfg.MIMIC_FILES['admissions']).parent
t0_ = time.time(); log = lambda m: print(f'[{time.time()-t0_:7.1f}s] {m}', flush=True)
try:
    from xgboost import XGBClassifier
    def model(seed=20260927): return XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=3, min_child_weight=10, subsample=0.8,
                                                  colsample_bytree=0.8, tree_method='hist', random_state=seed, n_jobs=-1, eval_metric='aucpr')
except Exception:
    from sklearn.ensemble import HistGradientBoostingClassifier
    def model(seed=20260927): return HistGradientBoostingClassifier(learning_rate=0.05, max_iter=200, max_leaf_nodes=15, min_samples_leaf=50, random_state=seed)
CORE, DIFF = list(cfg.CORE_CBC), list(cfg.DIFF_CBC); IDX = CORE + DIFF; DEM = ['age_approx', 'gender_bin']
VARS = CORE + ['neutrophils_pct', 'anc', 'n_flag_core']; KV = ['rbc', 'mcv', 'rdw', 'hemoglobin', 'platelet']
FAILED = []
ONLY = next((a.split('=', 1)[1].split(',') for a in sys.argv if a.startswith('--only=')), None)
def section(fn):
    if ONLY and fn.__name__ not in ONLY: return fn
    try: fn()
    except Exception:
        FAILED.append(fn.__name__); log(f'SECTION FAILED {fn.__name__}\n' + traceback.format_exc())
    return fn
def ageband(a): return pd.cut(a, [-1, 49.99, 59.99, 69.99, 79.99, 200], labels=['<50', '50-59', '60-69', '70-79', '>=80']).astype(str)
def wilson(k, n):
    if n == 0: return (np.nan, np.nan)
    p = k / n; z = 1.96; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d; return c - h, c + h

# ---------------- raw tables
adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], parse_dates=['admittime'])
dx = pd.read_csv(cfg.MIMIC_FILES['diagnoses_icd'], dtype={'icd_code': str})
if 'seq_num' not in dx: dx['seq_num'] = np.nan
c9, c10 = dx.icd_version == 9, dx.icd_version == 10; code = dx.icd_code.str.upper().str.replace('.', '', regex=False)
def has(p10, p9): return (c10 & code.str.startswith(tuple(p10))) | (c9 & code.str.startswith(tuple(p9)))
dx['admittime'] = dx.hadm_id.map(adm.set_index('hadm_id').admittime)
def race_group(r):
    r = str(r).upper()
    if r.startswith('WHITE'): return 'White'
    if r.startswith('BLACK'): return 'Black'
    if r.startswith('HISPANIC') or 'LATINO' in r: return 'Hispanic'
    if r.startswith('ASIAN'): return 'Asian'
    if r in ('UNKNOWN', 'UNABLE TO OBTAIN', 'PATIENT DECLINED TO ANSWER', 'NAN'): return 'Unknown'
    return 'Other'
race = adm.dropna(subset=['race']).groupby('subject_id').race.agg(lambda s: s.mode().iloc[0]).map(race_group) if 'race' in adm else pd.Series(dtype=str)
is_mds = has(['D46'], ['23872', '23873', '23874', '23875'])
is_heme = has(['C90', 'C91', 'C92', 'C93', 'C94', 'C95', 'D45', 'D46', 'D47', 'D61', 'Z856'], ['203', '204', '205', '206', '207', '208', '284', '2384', '2387', 'V106', '28983'])
is_hbpathy = has(['D56', 'D57', 'D58'], ['2820', '2821', '2822', '2823', '2824', '2825', '2826', '2827'])
is_ida = has(['D50'], ['280'])
mds_subj = set(dx.loc[is_mds, 'subject_id']); heme_first = dx[is_heme].groupby('subject_id').admittime.min()
hb_subj = set(dx.loc[is_hbpathy, 'subject_id']); ida_first = dx[is_ida].groupby('subject_id').admittime.min()
coded_hadm = set(dx.hadm_id)
cov = pd.read_csv(cfg.PROC / 'mds_covariates_drugs.csv.gz')
for c_ in cov.columns:
    if c_.startswith('first_'): cov[c_] = pd.to_datetime(cov[c_])
cov = cov.set_index('subject_id'); CG = [c_ for c_ in cov.columns if c_.startswith('first_') and c_ not in ('first_any_confounder', 'first_any_confounder_codes', 'first_marrow', 'first_heme_other', 'first_drug_macrocytic', 'first_drug_cytotoxic')]
KEEP = ['subject_id', 'setting', 't'] + CORE + DIFF + ['n_flag_core', 'age_approx', 'gender', 'anchor_age', 'anchor_year']
inp = pd.read_csv(cfg.PROC / 'admission_cbc_all.csv.gz', parse_dates=['admittime'])
inp = inp[inp.hadm_id.isin(coded_hadm)].assign(setting='inpatient', t=lambda d: d.admittime)
outp = pd.read_csv(cfg.PROC / 'outpatient_cbc_all.csv.gz', parse_dates=['charttime']).assign(setting='outpatient', t=lambda d: d.charttime)
enc_all = pd.concat([inp[KEEP + ['hadm_id']], outp[KEEP].assign(hadm_id=np.nan)], ignore_index=True); del inp, outp
anchor = enc_all.drop_duplicates('subject_id').set_index('subject_id')[['anchor_age', 'anchor_year', 'gender']]
age_at = lambda sid, t: (anchor.reindex(sid).anchor_age.values + (pd.DatetimeIndex(t).year.values - anchor.reindex(sid).anchor_year.values)).astype(float)
first_cbc = enc_all.groupby('subject_id').t.min()
enc_sorted = enc_all[['subject_id', 't']].sort_values(['subject_id', 't'])
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False, parse_dates=['index_time'])
p = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
ref = p[p.label == 0].copy(); ref['anc'] = ref.wbc * ref.neutrophils_pct / 100; ref['k'] = ref.gender + '|' + ageband(ref.age_approx)
med = ref.groupby('k')[VARS].median(); rsd = ((ref.groupby('k')[VARS].quantile(.75) - ref.groupby('k')[VARS].quantile(.25)) / 1.349).where(lambda x: x > 0)
ci_mds = pd.read_csv(cfg.PROC / 'mds_case_info.csv.gz', parse_dates=['t1'])
wk = pd.read_csv(cfg.PROC / 'heme_workup_events.csv.gz', parse_dates=['first_time'])
dd = pd.read_csv(cfg.PROC / 'mds_directed_drugs.csv.gz', parse_dates=['t'])
first_hma = dd[dd.group == 'hma_or_lenalidomide'].groupby('subject_id').t.min(); first_esa = dd[dd.group == 'esa'].groupby('subject_id').t.min()
log('inputs loaded')

EDGES = np.arange(0, 3653 + 1, 182.625); EDGES[-1] = 3653; NBIN = len(EDGES) - 1; MID = (EDGES[:-1] + EDGES[1:]) / 2 / 365.25
def zrows(h):
    h = h.copy(); h['anc'] = h.wbc * h.neutrophils_pct / 100; k = h.gender + '|' + ageband(h.age_approx)
    for v in VARS: h[v] = (h[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    h['bin'] = np.digitize(h.days_before, EDGES) - 1; return h[(h.bin >= 0) & (h.bin < NBIN)]
def pmat(h):
    g = h.groupby(['subject_id', 'bin'])[VARS].mean(); ids = g.index.get_level_values(0).unique(); pos = pd.Series(np.arange(len(ids)), index=ids)
    X = np.full((len(ids), NBIN, len(VARS)), np.nan); X[pos.reindex(g.index.get_level_values(0)).values, g.index.get_level_values(1).values] = g.values; return X
def wmean(X, w):
    ok = ~np.isnan(X); den = np.einsum('n,nbv->bv', w, ok.astype(float)); return np.einsum('n,nbv->bv', w, np.where(ok, X, 0)) / np.where(den > 0, den, np.nan)
def fit(d, wt, mask):
    best = (np.inf, np.nan, np.nan, np.nan)
    for tau in np.arange(0.5, MID.max() + 1e-9, 0.25):
        x = np.maximum(tau - MID, 0)[mask]; yv = d[mask]; ww = wt[mask]
        if (x > 0).sum() < 2 or (x == 0).sum() < 2: continue
        A = np.c_[np.ones_like(x), x]; W = np.sqrt(ww); coef = np.linalg.lstsq(A * W[:, None], yv * W, rcond=None)[0]; sse = (ww * (yv - A @ coef) ** 2).sum()
        if sse < best[0]: best = (sse, tau, coef[0], coef[1])
    return best[1:]
band5 = lambda a: (np.floor(np.asarray(a, float) / 5) * 5).astype(int).astype(str)
def n_cbc_bucket(sids, anchors):
    """number of CBCs in the 10 years before each anchor, bucketed"""
    df = pd.DataFrame({'subject_id': sids, 'a': anchors}).reset_index(drop=True); df['_i'] = np.arange(len(df))
    m = enc_sorted.merge(df, on='subject_id'); m = m[(m.t < m.a) & (m.t >= m.a - pd.Timedelta(days=3653))]
    n = m.groupby('_i').size().reindex(df._i).fillna(0).values
    return pd.cut(n, [-1, 1, 3, 9, 1e9], labels=['1', '2-3', '4-9', '10+']).astype(str)
def comorb_bucket(sids, anchors):
    a = pd.Series(pd.to_datetime(anchors), index=range(len(sids))); n = np.zeros(len(sids))
    for g in CG:
        d = cov[g].reindex(sids).values; n += (pd.to_datetime(d) < a.values).astype(int)
    return np.where(n >= 2, '2+', n.astype(int).astype(str))
def candidates(rng, excl_any, heme_before_only=False, extra_excl=None):
    pool = adm[adm.hadm_id.isin(coded_hadm) & adm.subject_id.isin(anchor.index)]
    if heme_before_only: pool = pool[~pool.subject_id.isin(mds_subj)]
    else: pool = pool[~pool.subject_id.isin(excl_any)]
    if extra_excl is not None: pool = pool[~pool.subject_id.isin(extra_excl)]
    c = pool.assign(_r=rng.rand(len(pool))).sort_values(['subject_id', '_r']).drop_duplicates('subject_id')[['subject_id', 'admittime']].rename(columns={'admittime': 'pseudo_t1'})
    c = c[c.pseudo_t1.values > first_cbc.reindex(c.subject_id).values]
    if heme_before_only: hf = heme_first.reindex(c.subject_id).values; c = c[~(pd.to_datetime(hf) < c.pseudo_t1.values)]
    c['age_t1'] = age_at(c.subject_id.values, c.pseudo_t1.values); c['gender'] = anchor.reindex(c.subject_id).gender.values
    return c.reset_index(drop=True)
def run_aim1(label, cases, cand, strata=('sex', 'age'), seed=SEED, keep_rows=False):
    """cases: DataFrame subject_id, t1. Returns dict with offsets, boot draws and (optionally) z rows."""
    cases = cases.copy(); cases['age_t1'] = age_at(cases.subject_id.values, cases.t1.values); cases['gender'] = anchor.reindex(cases.subject_id).gender.values
    def strat(df, anchors):
        s = df.gender.astype(str) + '_' + band5(df.age_t1)
        if 'race' in strata: s = s + '_' + race.reindex(df.subject_id).fillna('Unknown').values
        if 'use' in strata: s = s + '_' + n_cbc_bucket(df.subject_id.values, anchors) + '_' + comorb_bucket(df.subject_id.values, anchors)
        return s.values
    cases['stratum'] = strat(cases, cases.t1.values)
    cand = cand.copy(); cand['stratum'] = strat(cand, cand.pseudo_t1.values)
    vc = cases.stratum.value_counts() * 10; parts = []; short = 0
    for s, k in vc.items():
        pool = cand[cand.stratum == s]; n = min(k, len(pool)); short += k - n
        if n: parts.append(pool.sample(n, random_state=seed))
    if len(cases) < 20 or not parts:
        log(f'Aim 1 {label}: skipped ({len(cases)} cases, {len(parts)} matched strata)'); return None
    mi = pd.concat(parts, ignore_index=True)
    hc = enc_all[enc_all.subject_id.isin(set(cases.subject_id))].merge(cases[['subject_id', 't1']], on='subject_id')
    hc = hc[(hc.t < hc.t1) & ~((hc.setting == 'inpatient') & hc.hadm_id.isin(mds_hadm))].copy(); hc['days_before'] = (hc.t1 - hc.t).dt.total_seconds() / 86400
    hm = enc_all[enc_all.subject_id.isin(set(mi.subject_id))].merge(mi[['subject_id', 'pseudo_t1']], on='subject_id'); hm = hm[hm.t < hm.pseudo_t1].copy()
    hm['days_before'] = (hm.pseudo_t1 - hm.t).dt.total_seconds() / 86400
    zc, zm = zrows(hc), zrows(hm); CX, MX = pmat(zc), pmat(zm); diff = wmean(CX, np.ones(len(CX))) - wmean(MX, np.ones(len(MX)))
    rng = np.random.RandomState(7); boots = np.stack([wmean(CX, rng.poisson(1, len(CX)).astype(float)) - wmean(MX, rng.poisson(1, len(MX)).astype(float)) for _ in range(BP)])
    sd = np.nanstd(boots, 0); ncase = (~np.isnan(CX)).sum(0); res = dict(label=label, n_cases=len(CX), n_controls=len(MX), shortfall=int(short), rows=[], draws={})
    for j, v in enumerate(VARS):
        mask = (ncase[:, j] >= 30) & ~np.isnan(diff[:, j]) & (sd[:, j] > 0); wt = np.where(mask, 1 / np.where(sd[:, j] > 0, sd[:, j], 1) ** 2, 0)
        tau, a0, b0 = fit(diff[:, j], wt, mask); bt = np.array([fit(boots[b, :, j], wt, mask & ~np.isnan(boots[b, :, j])) for b in range(BP)], float)
        far = (MID >= 5) & (ncase[:, j] >= 10)
        res['rows'].append(dict(analysis=label, var=v, n_cases=len(CX), n_controls=len(MX), control_shortfall=int(short), bins_used=int(mask.sum()), diff_0_6m=diff[0, j],
                                mean_diff_5_10y=np.nanmean(diff[far, j]) if far.any() else np.nan, offset=a0, offset_lo=np.nanpercentile(bt[:, 1], 2.5), offset_hi=np.nanpercentile(bt[:, 1], 97.5),
                                tau=tau, tau_lo=np.nanpercentile(bt[:, 0], 2.5), tau_hi=np.nanpercentile(bt[:, 0], 97.5)))
        res['draws'][v] = bt[:, 1]
    if keep_rows: res['zc'], res['zm'] = zc.assign(case=1.0), zm.assign(case=0.0)
    log(f'Aim 1 {label}: {len(CX)} cases, {len(MX)} controls (shortfall {short})'); return res
mds_hadm = set(dx.loc[is_mds, 'hadm_id'])
heme_subj = set(dx.loc[is_heme, 'subject_id'])
MDS_CASES = ci_mds[['subject_id', 't1']]
RES = {}

@section
def r16_confirmed():
    mdx = dx[is_mds]; nadm = mdx.groupby('subject_id').hadm_id.nunique()
    t1map = ci_mds.set_index('subject_id').t1
    prin = mdx[mdx.seq_num == 1].groupby('subject_id').admittime.min()
    prin_t1 = mdx[(mdx.seq_num == 1)].merge(ci_mds[['subject_id', 't1']], on='subject_id'); prin_t1 = set(prin_t1[prin_t1.admittime == prin_t1.t1].subject_id)
    fm = wk[wk.category == 'bone_marrow'].groupby('subject_id').first_time.min()
    c = ci_mds.copy().set_index('subject_id')
    c['drug_ever'] = c.index.isin(first_hma.index); c['marrow_by_t1_90'] = (fm.reindex(c.index) <= c.t1 + pd.Timedelta(days=90)).values
    c['two_adm'] = (nadm.reindex(c.index).fillna(0) >= 2).values; c['principal_any'] = c.index.isin(prin.index); c['principal_t1'] = c.index.isin(prin_t1)
    c['confirmed'] = c.drug_ever | c.marrow_by_t1_90 | c.two_adm | c.principal_any
    fw = wk.groupby('subject_id').first_time.min(); t0 = pd.concat([c.t1, fw.reindex(c.index), first_hma.reindex(c.index)], axis=1).min(axis=1)
    fw_nosmear = wk[wk.category != 'heme_onc_smear'].groupby('subject_id').first_time.min(); t0b = pd.concat([c.t1, fw_nosmear.reindex(c.index), first_hma.reindex(c.index)], axis=1).min(axis=1)
    gap = (c.t1 - t0).dt.days; gapb = (c.t1 - t0b).dt.days
    out = {'cases': len(c), 'mds_principal_diagnosis_at_t1': int(c.principal_t1.sum()), 'mds_principal_diagnosis_any_admission': int(c.principal_any.sum()),
           'mds_directed_drug_ever': int(c.drug_ever.sum()), 'marrow_test_by_t1_plus_90d': int(c.marrow_by_t1_90.sum()), 'two_or_more_mds_admissions': int(c.two_adm.sum()),
           'confirmed_any': int(c.confirmed.sum()), 't0_before_t1': int((gap > 0).sum()),
           't1_minus_t0_days_q25_q50_q75_when_earlier': [float(x) for x in gap[gap > 0].quantile([.25, .5, .75])],
           't0_without_smear_before_t1': int((gapb > 0).sum()), 't1_minus_t0_without_smear_q50': float(gapb[gapb > 0].median()) if (gapb > 0).any() else None}
    json.dump(out, open(OUT / 'rev2_r16_confirmed_counts.json', 'w'), indent=1); log('R16 ' + json.dumps(out))
    RES['confirmed'] = set(c.index[c.confirmed]); RES['t0b'] = t0b

@section
def r17_rematched():
    rng = np.random.RandomState(SEED); cand_std = candidates(rng, heme_subj); rows = []
    RES['mds_ref'] = r = run_aim1('R17a sex x age (re-matched reference)', MDS_CASES, cand_std, keep_rows=True); rows += r['rows']
    r = run_aim1('R17b sex x age x race', MDS_CASES, cand_std, strata=('sex', 'age', 'race')); rows += (r['rows'] if r else [])
    r = run_aim1('R17c sex x age x race x prior CBCs x comorbidity', MDS_CASES, cand_std, strata=('sex', 'age', 'race', 'use')); rows += (r['rows'] if r else [])
    cand_h = candidates(np.random.RandomState(SEED + 1), heme_subj, heme_before_only=True)
    r = run_aim1('R17d harmonised control exclusions', MDS_CASES, cand_h); rows += (r['rows'] if r else [])
    ida_any = set(ida_first.index); excl = hb_subj | ida_any
    cand_x = candidates(np.random.RandomState(SEED + 2), heme_subj, extra_excl=excl)
    r = run_aim1('R17e no haemoglobinopathy or iron deficiency', MDS_CASES[~MDS_CASES.subject_id.isin(excl)], cand_x); rows += (r['rows'] if r else [])
    if RES.get('confirmed'):
        r = run_aim1('R16 confirmed cases', MDS_CASES[MDS_CASES.subject_id.isin(RES['confirmed'])], cand_std); rows += (r['rows'] if r else [])
    pd.DataFrame(rows).to_csv(OUT / 'rev2_r17_rematched_onset.csv', index=False)
    R = pd.DataFrame(rows); log('R17\n' + R[R['var'].isin(['rbc', 'mcv', 'rdw'])][['analysis', 'var', 'n_cases', 'n_controls', 'control_shortfall', 'mean_diff_5_10y', 'offset', 'offset_lo', 'offset_hi']].round(2).to_string(index=False))
    rc = pd.DataFrame({'race_cases': race.reindex(MDS_CASES.subject_id).fillna('Unknown').value_counts(normalize=True)}).round(3)
    rc.to_csv(OUT / 'rev2_r17_case_race.csv')

@section
def r18_comparators():
    ref = RES['mds_ref']; rng = np.random.RandomState(SEED + 3); cand_std = candidates(rng, heme_subj)
    OUTC = {'B12 or folate deficiency': has(['D51', 'D52'], ['2810', '2811', '2812']), 'Iron-deficiency anaemia': is_ida,
            'Chronic kidney disease stage 3-5': has(['N183', 'N184', 'N185', 'N186'], ['5853', '5854', '5855', '5856']),
            'Alcoholic liver disease or cirrhosis': has(['K70', 'K746'], ['5710', '5711', '5712', '5713', '5715']),
            'Unexplained cytopenia (anaemia, thrombocytopenia or neutropenia NOS)': has(['D649', 'D696', 'D709'], ['2859', '2875', '28800']),
            'Colorectal cancer': has(['C18', 'C19', 'C20'], ['153', '154']), 'Multiple myeloma': has(['C900'], ['2030']),
            'Chronic lymphocytic leukaemia': has(['C911'], ['2041']), 'Myeloproliferative neoplasm': has(['D45', 'D471', 'D473', 'D474'], ['2384', '23871', '23876', '28983']),
            'Acute myeloid leukaemia': has(['C920', 'C924', 'C925', 'C926', 'C930', 'C940', 'C942'], ['2050', '2060', '2070', '2072'])}
    rows, con = [], []
    for name, mask in OUTC.items():
        t1 = dx[mask].groupby('subject_id').admittime.min().rename('t1')
        malignant_heme = name in ('Multiple myeloma', 'Chronic lymphocytic leukaemia', 'Myeloproliferative neoplasm', 'Acute myeloid leukaemia')
        if malignant_heme:
            other = dx[is_heme & ~mask].groupby('subject_id').admittime.min()
            ok = t1.index[~t1.index.isin(mds_subj)]; ok = [s for s in ok if not (s in other.index and other[s] < t1[s])]
        else: ok = t1.index[~t1.index.isin(heme_subj)]
        cases = t1.reindex(ok).reset_index(); cases = cases[cases.subject_id.isin(first_cbc.index) & (cases.t1.values > first_cbc.reindex(cases.subject_id).values)]
        cand = cand_std[~cand_std.subject_id.isin(set(t1.index))]
        try: r = run_aim1(name, cases, cand)
        except Exception as ex: log(f'R18 {name} failed: {ex!r}'); r = None
        if r is None: continue
        rows += r['rows']
        for v in ['rbc', 'mcv', 'rdw', 'hemoglobin', 'platelet']:
            a = ref['draws'][v]; b = r['draws'][v]; n = min(len(a), len(b)); dlt = a[:n] - b[:n]
            ra = [x for x in ref['rows'] if x['var'] == v][0]; rb = [x for x in r['rows'] if x['var'] == v][0]
            con.append(dict(comparator=name, var=v, mds_offset=ra['offset'], comparator_offset=rb['offset'], difference=ra['offset'] - rb['offset'],
                            diff_lo=np.nanpercentile(dlt, 2.5), diff_hi=np.nanpercentile(dlt, 97.5), comparator_cases=rb['n_cases'], comparator_bins=rb['bins_used']))
    pd.DataFrame(rows).to_csv(OUT / 'rev2_r18_comparators_onset.csv', index=False); pd.DataFrame(con).to_csv(OUT / 'rev2_r18_contrasts.csv', index=False)
    log('R18 contrasts\n' + pd.DataFrame(con)[lambda d: d['var'].isin(['rbc', 'mcv', 'rdw'])].round(2).to_string(index=False))

# ---------------- R19 longitudinal estimands
KN = [1.0, 2.0, 4.0, 6.0]
def basis(x): return np.column_stack([x] + [np.maximum(x - k, 0) for k in KN])
@section
def r19_estimands():
    ref = RES['mds_ref']; D = pd.concat([ref['zc'], ref['zm']], ignore_index=True); D = D[(D.days_before > 0) & (D.days_before <= 3653)]
    D['x'] = D.days_before / 365.25; D['inp'] = (D.setting == 'inpatient').astype(float); D = D.sort_values('subject_id').reset_index(drop=True)
    ids = D.subject_id.values; uid, g = np.unique(ids, return_inverse=True); G = len(uid); start = np.searchsorted(ids, uid); end = np.r_[start[1:], len(ids)]
    is_case = D.groupby('subject_id').case.first().reindex(uid).values == 1
    B = basis(D.x.values); X = np.c_[np.ones(len(D)), D.case.values, B, B * D.case.values[:, None], D.inp.values]; nb = B.shape[1]; b8 = basis(np.array([8.0]))[0]
    w_all = 1.0 / np.bincount(g)[g]
    def wfit(rows, v):
        y = D[v].values[rows]; m = ~np.isnan(y); Xr = X[rows][m]; w = w_all[rows][m]; sw = np.sqrt(w)
        beta = np.linalg.lstsq(Xr * sw[:, None], y[m] * sw, rcond=None)[0]; return beta[1] + b8 @ beta[2 + nb:2 + 2 * nb]
    out = []; rng = np.random.RandomState(13); pc = np.where(is_case)[0]; pk = np.where(~is_case)[0]
    est = {v: wfit(np.arange(len(D)), v) for v in KV}; bs = {v: [] for v in KV}
    for _ in range(BOOT):
        ch = np.r_[rng.choice(pc, len(pc)), rng.choice(pk, len(pk))]; idx = np.concatenate([np.arange(start[u], end[u]) for u in ch])
        # weights per resampled patient copy: 1/n within copy
        lens = end[ch] - start[ch]; wb = np.repeat(1.0 / lens, lens); saved = w_all;
        for v in KV:
            y = D[v].values[idx]; m = ~np.isnan(y); sw = np.sqrt(wb[m]); Xr = X[idx][m]
            beta = np.linalg.lstsq(Xr * sw[:, None], y[m] * sw, rcond=None)[0]; bs[v].append(beta[1] + b8 @ beta[2 + nb:2 + 2 * nb])
    for v in KV: out.append(dict(estimand='visit-weighted model (each patient weight 1), difference at 8 y', var=v, estimate=est[v], lo=np.percentile(bs[v], 2.5), hi=np.percentile(bs[v], 97.5)))
    # period-restricted: patient means in 6-10 y window
    W = D[D.x >= 6]; pm = W.groupby(['subject_id', 'case'])[KV].mean().reset_index()
    for v in KV:
        a = pm[pm.case == 1][v].dropna().values; b = pm[pm.case == 0][v].dropna().values
        bsv = [rng.choice(a, len(a)).mean() - rng.choice(b, len(b)).mean() for _ in range(1000)]
        out.append(dict(estimand='patients observed 6-10 y before: difference in patient means', var=v, estimate=a.mean() - b.mean(), lo=np.percentile(bsv, 2.5), hi=np.percentile(bsv, 97.5), n_cases=len(a), n_controls=len(b)))
    try:
        import statsmodels.formula.api as smf
        for v in ['rbc', 'mcv', 'rdw', 'hemoglobin']:
            dv = D[['subject_id', 'x', 'case', 'inp', v]].dropna().rename(columns={v: 'y'})
            for j, k in enumerate(KN): dv[f's{j}'] = np.maximum(dv.x - k, 0)
            f = 'y ~ case*(x + s0 + s1 + s2 + s3) + inp'
            mres = smf.mixedlm(f, dv, groups=dv.subject_id, re_formula='~x').fit(method='lbfgs', maxiter=200)
            names = ['case', 'case:x'] + [f'case:s{j}' for j in range(4)]; L = np.zeros(len(mres.fe_params)); fe = list(mres.fe_params.index)
            for nm, val in zip(names, [1, 8] + [max(8 - k, 0) for k in KN]): L[fe.index(nm)] = val
            e = float(L @ mres.fe_params.values); se = float(np.sqrt(L @ mres.cov_params().loc[fe, fe].values @ L))
            out.append(dict(estimand='random intercept and slope mixed model, difference at 8 y', var=v, estimate=e, lo=e - 1.96 * se, hi=e + 1.96 * se))
            log(f'R19 random slopes {v}: {e:.2f}')
    except Exception as ex:
        out.append(dict(estimand=f'random-slope model not run ({type(ex).__name__}: {str(ex)[:80]})', var='', estimate=np.nan))
    pd.DataFrame(out).to_csv(OUT / 'rev2_r19_estimands.csv', index=False); log('R19\n' + pd.DataFrame(out).round(2).to_string(index=False))

# ---------------- Aim 2 helpers
hc = pd.read_csv(cfg.PROC / 'mds_hist_cases.csv.gz', parse_dates=['t', 't1']); hcc = pd.read_csv(cfg.PROC / 'mds_hist_cohort_ctrl.csv.gz', parse_dates=['t', 'index_time'])
HIST = pd.concat([hc[['subject_id', 't'] + IDX], hcc[['subject_id', 't'] + IDX]], ignore_index=True)
ICOLS = ['subject_id', 'index_time', 'label', 'gender', 'n_flag_core'] + IDX + DEM
def build(idx, min_gap=1.0):
    Hh = HIST.merge(idx[['subject_id', 'index_time']], on='subject_id'); Hh['gap'] = (Hh.index_time - Hh.t).dt.total_seconds() / 86400 / 365.25
    base = Hh[(Hh.gap >= min_gap) & (Hh.gap <= 10)]; nb = base.groupby('subject_id').size(); keep = nb[nb >= 2].index
    d = idx[idx.subject_id.isin(keep)].copy().set_index('subject_id'); base = base[base.subject_id.isin(keep)]
    sp = base.groupby('subject_id')[IDX].median(); cnt = base.groupby('subject_id')[IDX].count(); var = base.groupby('subject_id')[IDX].var(ddof=1)
    wsd = np.sqrt(var.where(cnt >= 3).mean())
    for v in IDX:
        d[f'set_{v}'] = sp[v]; d[f'drift_{v}'] = (d[v] - sp[v]) / wsd[v]
        b = base[['subject_id', 'gap', v]].dropna(); b = pd.concat([b, d[[v]].dropna().reset_index().assign(gap=0.0)], ignore_index=True); b['x'] = -b.gap; gg = b.groupby('subject_id')
        n = gg.size(); sx = gg.x.sum(); sy = gg[v].sum(); sxx = (b.x * b.x).groupby(b.subject_id).sum(); sxy = (b.x * b[v]).groupby(b.subject_id).sum(); den = n * sxx - sx * sx
        d[f'slope_{v}'] = ((n * sxy - sx * sy) / den.where(den > 1e-9)).where(n >= 3)
    return d.reset_index()
def prep_X(d, cols):
    X = d[cols].astype(float); miss = X.isna().astype(float).add_suffix('_missing'); miss = miss.loc[:, miss.sum() > 0]
    return pd.concat([X.fillna(X.median()), miss], axis=1)

@section
def r20_logistic():
    d = build(p[ICOLS]); y = d.label.values
    SNAP = IDX + DEM; FULL = SNAP + [f'drift_{v}' for v in IDX] + [f'slope_{v}' for v in CORE]
    Xs = prep_X(d, SNAP); Xf = prep_X(d, FULL)
    def oof(X, C=1.0):
        o = np.zeros((3, len(y)))
        for j, (tr, te) in enumerate(RepeatedStratifiedKFold(n_splits=5, n_repeats=3, random_state=SEED).split(X, y)):
            sc = StandardScaler().fit(X.iloc[tr]); m = LogisticRegression(C=C, max_iter=2000).fit(sc.transform(X.iloc[tr]), y[tr]); o[j // 5, te] = m.predict_proba(sc.transform(X.iloc[te]))[:, 1]
        return o.mean(0)
    ps, pf = oof(Xs), oof(Xf)
    def dev(X):
        sc = StandardScaler().fit(X); m = LogisticRegression(C=1e4, max_iter=5000).fit(sc.transform(X), y); pr = np.clip(m.predict_proba(sc.transform(X))[:, 1], 1e-12, 1 - 1e-12)
        return -2 * np.sum(y * np.log(pr) + (1 - y) * np.log(1 - pr))
    lr = dev(Xs) - dev(Xf); dfree = Xf.shape[1] - Xs.shape[1]
    try:
        from scipy.stats import chi2; pval = float(chi2.sf(lr, dfree))
    except Exception: pval = np.nan
    rng = np.random.RandomState(3); pos = np.where(y == 1)[0]; neg = np.where(y == 0)[0]; bs = []
    for _ in range(NB):
        i = np.r_[rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]
        bs.append([roc_auc_score(y[i], pf[i]) - roc_auc_score(y[i], ps[i]), log_loss(y[i], pf[i]) - log_loss(y[i], ps[i]), brier_score_loss(y[i], pf[i]) - brier_score_loss(y[i], ps[i])])
    bs = np.array(bs); lo, hi = np.percentile(bs, 2.5, 0), np.percentile(bs, 97.5, 0)
    out = dict(patients=len(y), cases=int(y.sum()), auroc_snap=roc_auc_score(y, ps), auroc_full=roc_auc_score(y, pf), auroc_diff=roc_auc_score(y, pf) - roc_auc_score(y, ps), auroc_diff_lo=lo[0], auroc_diff_hi=hi[0],
               equivalent_within_0_01=bool(lo[0] > -0.01 and hi[0] < 0.01), logloss_diff=log_loss(y, pf) - log_loss(y, ps), logloss_lo=lo[1], logloss_hi=hi[1],
               brier_diff=brier_score_loss(y, pf) - brier_score_loss(y, ps), brier_lo=lo[2], brier_hi=hi[2], lr_chi2=lr, lr_df=int(dfree), lr_p=pval,
               calib_in_large_snap=float(y.sum() / ps.sum()))
    pd.Series(out).to_csv(OUT / 'rev2_r20_logistic.csv'); log('R20 logistic ' + json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in out.items()}))
    # P3 decomposition with CIs
    rows = []
    for gap in [1.0, 4.0]:
        dd_ = d if gap == 1.0 else build(p[ICOLS], 4.0); yy = dd_.label.values; pos = np.where(yy == 1)[0]; neg = np.where(yy == 0)[0]
        for v in ['rbc', 'mcv', 'rdw', 'hemoglobin', 'platelet']:
            sv = dd_[f'set_{v}'].values; iv = dd_[v].values
            def dec(ii):
                c, k = ii[yy[ii] == 1], ii[yy[ii] == 0]; sdc = np.nanstd(sv[k])
                s_ = (np.nanmean(sv[c]) - np.nanmean(sv[k])) / sdc; tot = (np.nanmean(iv[c]) - np.nanmean(iv[k])) / sdc; return s_, tot - s_, s_ / tot
            e = dec(np.arange(len(yy))); bb = np.array([dec(np.r_[rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]) for _ in range(NB)])
            rows.append(dict(baseline=f'>= {gap:g} y', var=v, cases=len(pos), setpoint_part=e[0], setpoint_lo=np.percentile(bb[:, 0], 2.5), setpoint_hi=np.percentile(bb[:, 0], 97.5),
                             drift_part=e[1], drift_lo=np.percentile(bb[:, 1], 2.5), drift_hi=np.percentile(bb[:, 1], 97.5), share=e[2], share_lo=np.percentile(bb[:, 2], 2.5), share_hi=np.percentile(bb[:, 2], 97.5)))
    pd.DataFrame(rows).to_csv(OUT / 'rev2_r20_p3_decomposition.csv', index=False); log('R20 P3\n' + pd.DataFrame(rows).round(2).to_string(index=False))

# ---------------- alert helpers
F = IDX + DEM; yv = p.label.values
def fold_models(seed_split, seed_model, nested=False):
    fold = np.zeros(len(p), int); FM = []; oofs = np.zeros(len(p)); thr_in = []
    for k, (tr, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=seed_split).split(p, yv)):
        m = model(seed_model).fit(p.loc[tr, F].astype(float), yv[tr]); FM.append(m); fold[te] = k; oofs[te] = m.predict_proba(p.loc[te, F].astype(float))[:, 1]
        if nested:
            inner = np.zeros(len(tr)); ptr = p.loc[tr].reset_index(drop=True); ytr = yv[tr]
            for itr, ite in StratifiedKFold(5, shuffle=True, random_state=seed_split + 1).split(ptr, ytr):
                inner[ite] = model(seed_model).fit(ptr.loc[itr, F].astype(float), ytr[itr]).predict_proba(ptr.loc[ite, F].astype(float))[:, 1]
            thr_in.append(np.quantile(inner[ytr == 0], .99))
    return pd.Series(fold, index=p.subject_id), FM, oofs, thr_in
def score(h, fold_of, FM):
    X = h[F].astype(float); f = fold_of.reindex(h.subject_id).values; s = np.full(len(h), np.nan); known = ~np.isnan(f)
    for k, mdl in enumerate(FM):
        ix = known & (f == k)
        if ix.any(): s[ix] = mdl.predict_proba(X[ix])[:, 1]
    if (~known).any(): s[~known] = np.mean([mdl.predict_proba(X[~known])[:, 1] for mdl in FM], 0)
    return s
cases3 = ci_mds[ci_mds.subject_id.isin(set(p.subject_id[p.label == 1]))].set_index('subject_id')
hc3 = hc[hc.subject_id.isin(cases3.index) & (hc.days_before >= 30)].copy()
def yields(thr_vec_case, thr_vec_ctrl, sc_case, sc_ctrl, rule='any', subset=None):
    h = hc3.assign(s=sc_case, thr=thr_vec_case); k = hcc.assign(s=sc_ctrl, thr=thr_vec_ctrl)
    if rule == 'outpatient': h = h[h.setting == 'outpatient']; k = k[k.setting == 'outpatient']
    def first_alert(df, tcol):
        a = df[df.s > df.thr].sort_values(['subject_id', tcol])
        if rule == 'persist':
            a = a.assign(prev=a.groupby('subject_id')[tcol].shift(1)); fa = a[(a[tcol] - a.prev).dt.days >= 14].groupby('subject_id')[tcol].min()
            first = a.groupby('subject_id')[tcol].min()
            # require any earlier above-threshold CBC >= 14 days before
            a2 = a.merge(first.rename('first'), on='subject_id'); fa = a2[(a2[tcol] - a2['first']).dt.days >= 14].groupby('subject_id')[tcol].min()
            return fa
        return a.groupby('subject_id')[tcol].min()
    fa = first_alert(h, 't'); ids = cases3.index if subset is None else cases3.index.intersection(list(subset))
    lead = (cases3.t1.reindex(ids) - fa.reindex(ids)).dt.days
    ka = first_alert(k, 't'); nctrl = hcc.subject_id.nunique(); found = (lead >= 30).sum()
    return dict(cases=len(ids), alert_ge30d=float((lead >= 30).mean()), alert_ge365d=float((lead >= 365).mean()), controls_alerted=float(len(ka) / nctrl), per_case=float(len(ka) / max(found, 1)))

@section
def r21_alert():
    rows = []
    for s in range(NSEED):
        fo, FM, oofs, _ = fold_models(1000 + s, 2000 + s); thr = np.quantile(oofs[yv == 0], .99)
        sc_c, sc_k = score(hc3, fo, FM), score(hcc, fo, FM)
        r = yields(thr, thr, sc_c, sc_k); r.update(seed=s, auroc=roc_auc_score(yv, oofs)); rows.append(r)
        if s == 0:
            RES['alert0'] = (fo, FM, oofs, thr, sc_c, sc_k)
            for rule in ['persist', 'outpatient']:
                rr = yields(thr, thr, sc_c, sc_k, rule=rule); rr.update(rule=rule); RES.setdefault('rules', []).append(rr)
            if RES.get('confirmed'):
                rr = yields(thr, thr, sc_c, sc_k, subset=RES['confirmed']); rr.update(rule='confirmed cases'); RES['rules'].append(rr)
        log(f'R21 seed {s}: {r}')
    S = pd.DataFrame(rows); S.to_csv(OUT / 'rev2_r21_seeds.csv', index=False)
    summ = {c: [float(S[c].median()), float(S[c].quantile(.025)), float(S[c].quantile(.975))] for c in ['alert_ge30d', 'alert_ge365d', 'controls_alerted', 'per_case', 'auroc']}
    # nested thresholds
    fo, FM, oofs, thr_in = fold_models(20260927, 20260927, nested=True)
    sc_c, sc_k = score(hc3, fo, FM), score(hcc, fo, FM); tc = np.array(thr_in)[fo.reindex(hc3.subject_id).values.astype(int)]; tk = np.array(thr_in)[fo.reindex(hcc.subject_id).values.astype(int)]
    rn = yields(tc, tk, sc_c, sc_k); rn.update(rule='thresholds chosen inside training folds'); RES.setdefault('rules', []).append(rn)
    pd.DataFrame(RES['rules']).to_csv(OUT / 'rev2_r21_rules.csv', index=False)
    json.dump(summ, open(OUT / 'rev2_r21_seed_summary.json', 'w'), indent=1); log('R21 summary ' + json.dumps(summ)); log('R21 rules\n' + pd.DataFrame(RES['rules']).round(3).to_string(index=False))

@section
def r22_decision_curve():
    fo, FM, oofs, thr, sc_c, sc_k = RES['alert0']; y = yv; N = len(y); prev = y.mean(); rows = []
    male = p.gender_bin.values == 1; anemia = p.hemoglobin < np.where(male, 13, 12); macro = p.mcv > 100; rdwh = p.rdw > 15
    ruleA = (macro & anemia).values; ruleB = (macro & rdwh).values
    for pt in [0.001, 0.0025, 0.005, 0.01, 0.02, 0.05]:
        odds = pt / (1 - pt)
        def nb(sel): tp = (sel & (y == 1)).sum(); fp = (sel & (y == 0)).sum(); return tp / N - fp / N * odds
        rows.append(dict(threshold_probability=pt, model=nb(oofs >= pt), treat_all=prev - (1 - prev) * odds, rule_macrocytic_anaemia=nb(ruleA), rule_mcv_rdw=nb(ruleB), model_flagged_share=float((oofs >= pt).mean())))
    R = pd.DataFrame(rows); R.to_csv(OUT / 'rev2_r22_decision_curve.csv', index=False)
    lg = np.log(np.clip(oofs, 1e-6, 1 - 1e-6) / (1 - np.clip(oofs, 1e-6, 1 - 1e-6))).reshape(-1, 1)
    slope = LogisticRegression(C=1e6, max_iter=1000).fit(lg, y).coef_[0, 0]
    pd.Series(dict(observed_expected=float(y.sum() / oofs.sum()), calibration_slope=float(slope), auroc=float(roc_auc_score(y, oofs)))).to_csv(OUT / 'rev2_r22_calibration.csv')
    log('R22\n' + R.round(5).to_string(index=False))

@section
def r23_outcomes():
    fo, FM, oofs, thr, sc_c, sc_k = RES['alert0']
    pt = pd.read_csv(RAW / 'patients.csv.gz', usecols=['subject_id', 'dod'], parse_dates=['dod']).set_index('subject_id')
    last = adm.groupby('subject_id').dischtime.max() if 'dischtime' in adm else adm.groupby('subject_id').admittime.max()
    aml = has(['C920', 'C92A', 'C924', 'C925', 'C926', 'C930', 'C940', 'C942'], ['2050', '2060', '2070', '2072']); fa_aml = dx[aml].groupby('subject_id').admittime.min()
    h = hc3.assign(s=sc_c); fa = h[h.s > thr].groupby('subject_id').t.min()
    d = cases3.copy(); d['lead'] = (d.t1 - fa.reindex(d.index)).dt.days; d['grp'] = np.where(d.lead >= 365, 2, np.where(d.lead >= 30, 1, 0))
    d['dod'] = pt.dod.reindex(d.index); d['last'] = pd.to_datetime(last.reindex(d.index)); d['death'] = d.dod.notna() & ((d.dod - d.t1).dt.days <= 365)
    d['fu'] = d.death | ((d['last'] - d.t1).dt.days >= 365); d['aml'] = (fa_aml.reindex(d.index) - d.t1).dt.days.between(0, 730)
    d['male'] = (d.gender == 'M').astype(float); e = d[d.fu]
    X = np.c_[(e.grp == 1).astype(float), (e.grp == 2).astype(float), e.age_t1.values, e.male.values]
    rows = []; rng = np.random.RandomState(5)
    for outc in ['death', 'aml']:
        yy = e[outc].values.astype(int)
        if yy.sum() < 5 or (len(yy) - yy.sum()) < 5: log(f'R23 {outc}: too few events/non-events ({yy.sum()}/{len(yy)})'); continue
        fitc = lambda X_, y_: LogisticRegression(C=1e6, max_iter=2000).fit(X_, y_).coef_[0]
        c0 = fitc(X, yy); bb = []
        for _ in range(500):
            i = rng.randint(0, len(yy), len(yy))
            try: bb.append(fitc(X[i], yy[i]))
            except Exception: pass
        bb = np.array(bb)
        for j, nm in enumerate(['alert 30-364 d vs none', 'alert >= 1 y vs none']):
            rows.append(dict(outcome=outc, comparison=nm, n=len(yy), events=int(yy.sum()), adjusted_or=float(np.exp(c0[j])), lo=float(np.exp(np.percentile(bb[:, j], 2.5))), hi=float(np.exp(np.percentile(bb[:, j], 97.5)))))
    pd.DataFrame(rows).to_csv(OUT / 'rev2_r23_adjusted_outcomes.csv', index=False); log('R23\n' + pd.DataFrame(rows).round(2).to_string(index=False))

@section
def r24_era():
    c = p[p.label == 0].groupby('anchor_year_group')[['rdw', 'mcv', 'rbc', 'hemoglobin']].median()
    c['n_controls'] = p[p.label == 0].groupby('anchor_year_group').size(); c['cases'] = p[p.label == 1].groupby('anchor_year_group').size()
    c.to_csv(OUT / 'rev2_r24_era.csv')
    dif = p.groupby('label').apply(lambda d: (d.n_diff_present > 0).mean() if 'n_diff_present' in d else np.nan)
    dif.to_csv(OUT / 'rev2_r24_differential_by_label.csv'); log('R24\n' + c.round(2).to_string() + '\n' + dif.round(3).to_string())


@section
def r25_notes():
    """R25 (amendment R25, 15 Oct 2026): Aim 1 and Aim 3 in cases supported by MIMIC-IV-Note discharge summaries (46_mds_notes.py)."""
    f = cfg.PROC / 'mds_note_validation.csv.gz'
    if not f.exists(): log('R25 skipped: run src/46_mds_notes.py first'); return
    V = pd.read_csv(f, parse_dates=['first_any_mention', 'first_affirmative']).set_index('subject_id')
    sets = [('R25 note-confirmed (definite or probable)', set(V.index[V.note_confirmed])), ('R25 note-definite', set(V.index[V.status == 'definite'])),
            ('R25 not supported or possible only', set(V.index[V.status.isin(['not supported', 'possible'])]))]
    rng = np.random.RandomState(SEED); cand_std = candidates(rng, heme_subj); rows = []
    for lab, s in sets:
        r = run_aim1(lab, MDS_CASES[MDS_CASES.subject_id.isin(s)], cand_std); rows += (r['rows'] if r else [])
    pd.DataFrame(rows).to_csv(OUT / 'rev3_r25_onset.csv', index=False)
    if rows: log('R25 onset\n' + pd.DataFrame(rows)[lambda d: d['var'].isin(['rbc', 'mcv', 'rdw'])][['analysis', 'var', 'n_cases', 'offset', 'offset_lo', 'offset_hi']].round(2).to_string(index=False))
    fo, FM, oofs, _ = fold_models(1000, 2000); thr = np.quantile(oofs[yv == 0], .99); sc_c, sc_k = score(hc3, fo, FM), score(hcc, fo, FM)
    al = []
    for lab, s in [('all cohort cases (seed 0)', None)] + sets[:2]:
        r = yields(thr, thr, sc_c, sc_k, subset=s); r.update(rule=lab); al.append(r)
    fw = wk.groupby('subject_id').first_time.min()
    t0 = pd.concat([cases3.t1, fw.reindex(cases3.index), first_hma.reindex(cases3.index)], axis=1).min(axis=1)
    t0n = pd.concat([t0, V.first_any_mention.reindex(cases3.index)], axis=1).min(axis=1)
    h = hc3.assign(s=sc_c); fa = h[h.s > thr].groupby('subject_id').t.min().reindex(cases3.index)
    for lab, tt in [('lead before earliest suspicion t0 (seed 0)', t0), ('lead before t0 or first note mention of MDS (seed 0)', t0n)]:
        ld = (tt - fa).dt.days; al.append(dict(rule=lab, cases=len(cases3), alert_ge30d=float((ld >= 30).mean()), alert_ge365d=float((ld >= 365).mean()),
                                               t0_before_t1=int((tt < cases3.t1 - pd.Timedelta(days=1)).sum())))
    pd.DataFrame(al).to_csv(OUT / 'rev3_r25_alert.csv', index=False); log('R25 alert\n' + pd.DataFrame(al).round(3).to_string(index=False))

log('FAILED SECTIONS: ' + (', '.join(FAILED) if FAILED else 'none'))
log('REVISION2_DONE' if not FAILED else 'REVISION2_DONE_WITH_FAILURES')
