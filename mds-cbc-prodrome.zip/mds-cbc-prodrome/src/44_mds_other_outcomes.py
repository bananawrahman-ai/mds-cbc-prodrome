"""MDS revision analysis R15 (6 Oct 2026; post hoc): is the long-standing red-cell offset specific to MDS among blood cancers?
The Aim 1 pipeline of 41_mds_negative_control.py is repeated for first coded multiple myeloma, chronic lymphocytic leukaemia,
myeloproliferative neoplasm and acute myeloid leukaemia (patients with any MDS code, or with another haematological code before
the outcome, are excluded; controls have no haematological or myeloma code at any time), with the same eligible CBCs,
age/sex reference, 10:1 matching and 10-year offset-plus-acceleration model.
Outputs: results/mds/v2/other_outcomes_onset.csv, other_outcomes_bins.csv; prints OTHER_OUTCOMES_DONE."""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv; BP = 60 if QUICK else 300
OUT = cfg.RESULTS / 'mds' / 'v2'; SEED = 20261006
t0 = time.time(); log = lambda m: print(f'[{time.time()-t0:7.1f}s] {m}', flush=True)
CORE, DIFF = list(cfg.CORE_CBC), list(cfg.DIFF_CBC); VARS = CORE + ['neutrophils_pct', 'anc', 'n_flag_core']
KEEP = ['subject_id', 'setting', 't'] + CORE + DIFF + ['n_flag_core', 'age_approx', 'gender', 'anchor_age', 'anchor_year']

adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime'], parse_dates=['admittime'])
dx = pd.read_csv(cfg.MIMIC_FILES['diagnoses_icd'], dtype={'icd_code': str}, usecols=['subject_id', 'hadm_id', 'icd_code', 'icd_version'])
c9, c10 = dx.icd_version == 9, dx.icd_version == 10; code = dx.icd_code.str.upper().str.replace('.', '', regex=False)
def has(p10, p9): return (c10 & code.str.startswith(tuple(p10))) | (c9 & code.str.startswith(tuple(p9)))
OUTCOMES = {
    'multiple myeloma': has(['C900'], ['2030']),
    'chronic lymphocytic leukaemia': has(['C911'], ['2041']),
    'myeloproliferative neoplasm': has(['D45', 'D471', 'D473', 'D474'], ['2384', '23871', '23876', '28983']),
    'acute myeloid leukaemia': has(['C920', 'C924', 'C925', 'C926', 'C930', 'C940', 'C942'], ['2050', '2060', '2070', '2072']),
}
is_mds = has(['D46'], ['23872', '23873', '23874', '23875'])
is_heme = has(['C90', 'C91', 'C92', 'C93', 'C94', 'C95', 'D45', 'D46', 'D47', 'D61', 'Z856'], ['203', '204', '205', '206', '207', '208', '284', '2384', '2387', 'V106', '28983'])
mds_subj = set(dx.loc[is_mds, 'subject_id']); heme_subj = set(dx.loc[is_heme, 'subject_id']); coded_hadm = set(dx.hadm_id)
dxa = dx.assign(admittime=dx.hadm_id.map(adm.set_index('hadm_id').admittime))
first_heme_any = dxa[is_heme].groupby('subject_id').admittime.min()

inp = pd.read_csv(cfg.PROC / 'admission_cbc_all.csv.gz', parse_dates=['admittime'])
inp = inp[inp.hadm_id.isin(coded_hadm)].assign(setting='inpatient', t=lambda d: d.admittime)
outp = pd.read_csv(cfg.PROC / 'outpatient_cbc_all.csv.gz', parse_dates=['charttime']).assign(setting='outpatient', t=lambda d: d.charttime)
inp_hadm = inp[['subject_id', 'hadm_id']]
enc_all = pd.concat([inp[KEEP + ['hadm_id']], outp[KEEP].assign(hadm_id=np.nan)], ignore_index=True); del inp, outp
anchor = enc_all.drop_duplicates('subject_id').set_index('subject_id')[['anchor_age', 'anchor_year', 'gender']]
age_at = lambda sid, t: (anchor.reindex(sid).anchor_age.values + (pd.DatetimeIndex(t).year.values - anchor.reindex(sid).anchor_year.values)).astype(float)
first_cbc = enc_all.groupby('subject_id').t.min()
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False); ref = coh[coh.window == 'control'].copy()
def ageband(a): return pd.cut(a, [-1, 49.99, 59.99, 69.99, 79.99, 200], labels=['<50', '50-59', '60-69', '70-79', '>=80']).astype(str)
ref['anc'] = ref.wbc * ref.neutrophils_pct / 100; ref['k'] = ref.gender + '|' + ageband(ref.age_approx)
med = ref.groupby('k')[VARS].median(); rsd = ((ref.groupby('k')[VARS].quantile(.75) - ref.groupby('k')[VARS].quantile(.25)) / 1.349).where(lambda x: x > 0)
EDGES = np.arange(0, 3653 + 1, 182.625); EDGES[-1] = 3653; NBIN = len(EDGES) - 1; MID = (EDGES[:-1] + EDGES[1:]) / 2 / 365.25
def zscore(h):
    h = h.copy(); h['anc'] = h.wbc * h.neutrophils_pct / 100; k = h.gender + '|' + ageband(h.age_approx)
    for v in VARS: h[v] = (h[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    h['bin'] = np.digitize(h.days_before, EDGES) - 1; return h[(h.bin >= 0) & (h.bin < NBIN)]
def pmat(h):
    g = h.groupby(['subject_id', 'bin'])[VARS].mean(); ids = g.index.get_level_values(0).unique(); pos = pd.Series(np.arange(len(ids)), index=ids)
    X = np.full((len(ids), NBIN, len(VARS)), np.nan); X[pos.reindex(g.index.get_level_values(0)).values, g.index.get_level_values(1).values] = g.values; return X
def wmean(X, w):
    ok = ~np.isnan(X); den = np.einsum('n,nbv->bv', w, ok.astype(float)); return np.einsum('n,nbv->bv', w, np.where(ok, X, 0)) / np.where(den > 0, den, np.nan)
def fit(d, wt, mask):
    best = (np.inf, np.nan, np.nan, np.nan)
    for tau in np.arange(0.5, MID.max() + 1e-9, 0.25):
        x = np.maximum(tau - MID, 0)[mask]; yv = d[mask]; ww = wt[mask]
        if (x > 0).sum() < 2 or (x == 0).sum() < 2: continue
        A = np.c_[np.ones_like(x), x]; W = np.sqrt(ww); coef = np.linalg.lstsq(A * W[:, None], yv * W, rcond=None)[0]; sse = (ww * (yv - A @ coef) ** 2).sum()
        if sse < best[0]: best = (sse, tau, coef[0], coef[1])
    return best[1:]
band = lambda a: (np.floor(np.asarray(a, float) / 5) * 5).astype(int).astype(str)
cand_all = adm[adm.hadm_id.isin(coded_hadm) & ~adm.subject_id.isin(heme_subj) & adm.subject_id.isin(anchor.index)]
rng0 = np.random.RandomState(SEED)
cand_all = cand_all.assign(_r=rng0.rand(len(cand_all))).sort_values(['subject_id', '_r']).drop_duplicates('subject_id')[['subject_id', 'admittime']].rename(columns={'admittime': 'pseudo_t1'})
cand_all = cand_all[cand_all.pseudo_t1.values > first_cbc.reindex(cand_all.subject_id).values]
cand_all['age_t1'] = age_at(cand_all.subject_id.values, cand_all.pseudo_t1.values); cand_all['gender'] = anchor.reindex(cand_all.subject_id).gender.values
cand_all['stratum'] = cand_all.gender + '_' + band(cand_all.age_t1)
rows, bins = [], []
for name, mask in OUTCOMES.items():
    out_hadm = set(dx.loc[mask, 'hadm_id'])
    t1 = dxa[mask].groupby('subject_id').admittime.min().rename('t1')
    other_first = dxa[is_heme & ~mask].groupby('subject_id').admittime.min()
    ok = t1.index[~t1.index.isin(mds_subj)]
    ok = [s for s in ok if not (s in other_first.index and other_first[s] < t1[s])]
    t1 = t1.reindex(ok)
    enc = enc_all[~enc_all.hadm_id.isin(out_hadm)]
    hc = enc[enc.subject_id.isin(t1.index)].merge(t1.reset_index(), on='subject_id'); hc = hc[hc.t < hc.t1].copy()
    hc['days_before'] = (hc.t1 - hc.t).dt.total_seconds() / 86400
    ci = t1[t1.index.isin(set(hc.subject_id))].reset_index(); ci['age_t1'] = age_at(ci.subject_id.values, ci.t1.values); ci['gender'] = anchor.reindex(ci.subject_id).gender.values
    ci['stratum'] = ci.gender + '_' + band(ci.age_t1)
    if len(ci) < 30: log(f'{name}: only {len(ci)} cases with an earlier CBC; skipped'); continue
    mi = pd.concat([cand_all[cand_all.stratum == s].sample(min(k, int((cand_all.stratum == s).sum())), random_state=SEED) for s, k in (ci.stratum.value_counts() * 10).items()], ignore_index=True)
    hm = enc_all[enc_all.subject_id.isin(set(mi.subject_id))].merge(mi[['subject_id', 'pseudo_t1']], on='subject_id'); hm = hm[hm.t < hm.pseudo_t1].copy()
    hm['days_before'] = (hm.pseudo_t1 - hm.t).dt.total_seconds() / 86400
    CX, MX = pmat(zscore(hc)), pmat(zscore(hm)); diff = wmean(CX, np.ones(len(CX))) - wmean(MX, np.ones(len(MX)))
    r2 = np.random.RandomState(7); boots = np.stack([wmean(CX, r2.poisson(1, len(CX)).astype(float)) - wmean(MX, r2.poisson(1, len(MX)).astype(float)) for _ in range(BP)])
    lo, hi, sd = np.nanpercentile(boots, 2.5, 0), np.nanpercentile(boots, 97.5, 0), np.nanstd(boots, 0); ncase = (~np.isnan(CX)).sum(0)
    for j, v in enumerate(VARS):
        mk = (ncase[:, j] >= 30) & ~np.isnan(diff[:, j]) & (sd[:, j] > 0); wt = np.where(mk, 1 / np.where(sd[:, j] > 0, sd[:, j], 1) ** 2, 0)
        tau, a0, b0 = fit(diff[:, j], wt, mk); bt = np.array([fit(boots[b, :, j], wt, mk & ~np.isnan(boots[b, :, j])) for b in range(BP)], float)
        far = (MID >= 5) & (ncase[:, j] >= 10)
        rows.append(dict(outcome=name, var=v, n_cases=len(CX), n_controls=len(MX), bins_used=int(mk.sum()), diff_0_6m=diff[0, j], lo_0_6m=lo[0, j], hi_0_6m=hi[0, j],
                         mean_diff_5_10y=np.nanmean(diff[far, j]) if far.any() else np.nan, offset=a0, offset_lo=np.nanpercentile(bt[:, 1], 2.5),
                         offset_hi=np.nanpercentile(bt[:, 1], 97.5), tau=tau, tau_lo=np.nanpercentile(bt[:, 0], 2.5), tau_hi=np.nanpercentile(bt[:, 0], 97.5), slope=b0))
        for i in range(NBIN): bins.append(dict(outcome=name, var=v, years_before_mid=MID[i], n_cases=int(ncase[i, j]), diff=diff[i, j], lo=lo[i, j], hi=hi[i, j]))
    log(f'{name}: {len(CX)} cases, {len(MX)} matched controls')
R = pd.DataFrame(rows); R.to_csv(OUT / 'other_outcomes_onset.csv', index=False); pd.DataFrame(bins).to_csv(OUT / 'other_outcomes_bins.csv', index=False)
if len(R): log('\n' + R[R['var'].isin(['rbc', 'mcv', 'rdw', 'hemoglobin', 'platelet'])][['outcome', 'var', 'n_cases', 'diff_0_6m', 'mean_diff_5_10y', 'offset', 'offset_lo', 'offset_hi', 'tau']].round(2).to_string(index=False))
log('OTHER_OUTCOMES_DONE')
