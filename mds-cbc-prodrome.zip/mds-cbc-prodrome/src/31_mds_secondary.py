"""MDS study: comparators and pre-specified sensitivity analyses (protocol MDS_paper/docs/mds_protocol.md, sections 7-8).
Inputs : data/processed/mds_cohort.csv.gz, mds_cohort_ctrl_none.csv.gz, heme_workup_events.csv.gz,
         results/mds/models/oof_predictions.csv.gz (from src/13 run with --cohort/--outdir)
Outputs: results/mds/secondary/"""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import rankdata
from sklearn.metrics import average_precision_score
from sklearn.model_selection import RepeatedStratifiedKFold
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv
R = cfg.RESULTS / 'mds'; OUT = R / 'secondary'; OUT.mkdir(parents=True, exist_ok=True)
SEED = 20260927; NB = 200 if QUICK else 1000; REPS = 1 if QUICK else 2
LOG = open(OUT / 'run.log', 'w'); t0 = time.time()
def log(m):
    line = f'[{time.time()-t0:7.1f}s] {m}'; print(line, flush=True); LOG.write(line + '\n'); LOG.flush()
try:
    from xgboost import XGBClassifier
    def model(): return XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=3, min_child_weight=10, subsample=0.8,
                                      colsample_bytree=0.8, tree_method='hist', random_state=SEED, n_jobs=-1, eval_metric='aucpr')
except Exception:
    from sklearn.ensemble import HistGradientBoostingClassifier
    def model(): return HistGradientBoostingClassifier(learning_rate=0.05, max_iter=200, max_leaf_nodes=15, min_samples_leaf=50, random_state=SEED)
CORE = ['hemoglobin', 'hematocrit', 'rbc', 'wbc', 'platelet', 'mcv', 'mch', 'mchc', 'rdw']
DIFF = ['neutrophils_pct', 'lymphocytes_pct', 'monocytes_pct', 'eosinophils_pct', 'basophils_pct']
DEM = ['age_approx', 'gender_bin']; BASE = CORE + DEM + DIFF

def auc(y, s):
    r = rankdata(s); n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def sidx(rng, y):
    pos = np.where(y == 1)[0]; neg = np.where(y == 0)[0]
    return np.r_[rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]
def summ(name, y, s, **kw):
    rng = np.random.RandomState(1); v = [auc(y[i], s[i]) for i in (sidx(rng, y) for _ in range(NB))]
    return dict(analysis=name, n=len(y), cases=int(y.sum()), auroc=auc(y, s), auroc_lo=np.percentile(v, 2.5),
                auroc_hi=np.percentile(v, 97.5), ap=average_precision_score(y, s), **kw)
def paired(y, a, b, f):
    rng = np.random.RandomState(2); v = []
    for _ in range(NB):
        i = sidx(rng, y); v.append(f(y[i], a[i]) - f(y[i], b[i]))
    return f(y, a) - f(y, b), np.percentile(v, 2.5), np.percentile(v, 97.5)
def cv_oof(X, y):
    o = np.zeros((REPS, len(y)))
    for j, (tr, te) in enumerate(RepeatedStratifiedKFold(n_splits=5, n_repeats=REPS, random_state=SEED).split(X, y)):
        o[j // 5, te] = model().fit(X.iloc[tr], y[tr]).predict_proba(X.iloc[te])[:, 1]
    return o.mean(0)

coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False, parse_dates=['index_time'])
p = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
oof = pd.read_csv(R / 'models' / 'oof_predictions.csv.gz')
best_col = [c for c in oof.columns if c.startswith('oof_')]
cvres = pd.read_csv(R / 'models' / 'nested_cv_discrimination.csv')
best = cvres[~cvres.model.str.contains('comparator')].sort_values('ap', ascending=False).iloc[0].model
p = p.merge(oof, on=['subject_id', 'label'], validate='one_to_one')
y = p.label.values; s = p[f'oof_{best}'].values; lr = p['oof_logistic_l2'].values if 'oof_logistic_l2' in p else None
log(f'primary model {best}; {len(p):,} patients, {y.sum()} cases')

# ---------- comparators
female = p.gender_bin == 0
anc = p.wbc * p.neutrophils_pct / 100
cyto_hb = p.hemoglobin < np.where(female, 12, 13); cyto_plt = p.platelet < 150; cyto_anc = anc < 1.8
n_cyto = cyto_hb.astype(int) + cyto_plt.astype(int) + cyto_anc.fillna(False).astype(int)
rule = ((p.mcv > 100) & (n_cyto >= 1)).astype(int).values
flags = p.n_flag_core.fillna(0).values
rows = [summ(f'{best} (nested CV OOF)', y, s), summ('lab flag count', y, flags), summ('cytopenia count (0-3)', y, n_cyto.values)]
if lr is not None: rows.append(summ('logistic L2 (nested CV OOF)', y, lr))
sens = rule[y == 1].mean(); spec = 1 - rule[y == 0].mean(); ppv = y[rule == 1].mean() if rule.sum() else np.nan
thr = np.quantile(s[y == 0], spec)
rows.append(dict(analysis='rule: MCV>100 + any cytopenia', n=len(y), cases=int(y.sum()), sensitivity=sens, specificity=spec, ppv=ppv,
                 flagged_per_case=1 / ppv if ppv else np.nan,
                 model_sens_at_same_spec=(s[y == 1] >= thr).mean(), model_ppv_at_same_spec=y[s >= thr].mean()))
thr95 = np.quantile(s[y == 0], 0.95)
rows.append(dict(analysis=f'{best} at 95% specificity', n=len(y), cases=int(y.sum()), sensitivity=(s[y == 1] >= thr95).mean(),
                 specificity=0.95, ppv=y[s >= thr95].mean(), flagged_per_case=1 / y[s >= thr95].mean()))
comp = pd.DataFrame(rows); comp.to_csv(OUT / 'comparators.csv', index=False); log('comparators\n' + comp.round(4).to_string(index=False))
pr = []
for nm, other in [('lab flag count', flags), ('cytopenia count', n_cyto.values)] + ([('logistic L2', lr)] if lr is not None else []):
    for met, f in [('AUROC', auc), ('AP', average_precision_score)]:
        d, lo, hi = paired(y, s, other, f); pr.append(dict(comparison=f'{best} minus {nm}', metric=met, difference=d, ci_lo=lo, ci_hi=hi))
pd.DataFrame(pr).to_csv(OUT / 'paired_differences.csv', index=False); log('paired\n' + pd.DataFrame(pr).round(4).to_string(index=False))

# ---------- sensitivity analyses
w = pd.read_csv(cfg.PROC / 'heme_workup_events.csv.gz', parse_dates=['first_time']).merge(p[['subject_id', 'index_time']], on='subject_id')
prior = p.subject_id.isin(set(w.loc[w.first_time < w.index_time, 'subject_id'])).values
log(f'prior work-up: cases {prior[y==1].mean():.1%}, controls {prior[y==0].mean():.1%}')
sens_rows = [summ('primary', y, s, flag_auroc=auc(y, flags))]
for nm, m in [('S1 excluding any prior haematology work-up', ~prior),
              ('S2 excluding cases with leukaemia code at first MDS admission', ~((y == 1) & (p.subtype == 'MDS+leukaemia code').values)),
              ('S3 inpatient index CBC only', (p.setting == 'inpatient').values),
              ('S6 age >= 60', (p.age_approx >= 60).values),
              ('S1+S6 no prior work-up, age >= 60', ~prior & (p.age_approx >= 60).values),
              ('differential measured', p.neutrophils_pct.notna().values), ('differential not measured', p.neutrophils_pct.isna().values)]:
    if y[m].sum() >= 10:
        sens_rows.append(summ(nm, y[m], s[m], flag_auroc=auc(y[m], flags[m]), cyto_auroc=auc(y[m], n_cyto.values[m])))
for nm, cols in [('S4 refit without differential', CORE + DEM), ('S4 refit nine core parameters only', CORE)]:
    o = cv_oof(p[cols].astype(float), y); sens_rows.append(summ(nm, y, o)); log(f'{nm} done')
f5 = cfg.PROC / 'mds_cohort_ctrl_none.csv.gz'
if f5.exists():
    c5 = pd.read_csv(f5, low_memory=False); q = c5[c5.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
    o = cv_oof(q[BASE].astype(float), q.label.values)
    sens_rows.append(summ('S5 controls without follow-up requirement (refit)', q.label.values, o, n_controls=int((q.label == 0).sum())))
S = pd.DataFrame(sens_rows); S.to_csv(OUT / 'sensitivity.csv', index=False); log('sensitivity\n' + S.round(4).to_string(index=False))

# ---------- characteristics
def q(x): x = x.dropna(); return f'{x.median():.1f} [{x.quantile(.25):.1f}-{x.quantile(.75):.1f}]' if len(x) else ''
tab = []
for nm, f in [('Age', 'age_approx'), ('Haemoglobin', 'hemoglobin'), ('WBC', 'wbc'), ('Platelets', 'platelet'), ('MCV', 'mcv'), ('RDW', 'rdw'),
              ('Neutrophils %', 'neutrophils_pct'), ('Lymphocytes %', 'lymphocytes_pct'), ('Monocytes %', 'monocytes_pct')]:
    tab.append([nm, q(p.loc[p.label == 1, f]), q(p.loc[p.label == 0, f])])
for nm, v in [('Male %', p.gender_bin), ('Outpatient index %', (p.setting == 'outpatient')), ('Differential measured %', p.neutrophils_pct.notna()),
              ('MCV > 100 %', p.mcv > 100), ('Any cytopenia %', n_cyto >= 1), ('Prior haematology work-up %', pd.Series(prior))]:
    tab.append([nm, f'{100*v[y==1].mean():.1f}', f'{100*v[y==0].mean():.1f}'])
pd.DataFrame(tab, columns=['variable', 'future MDS', 'controls']).to_csv(OUT / 'table1.csv', index=False)
log('table1\n' + pd.DataFrame(tab, columns=['variable', 'future MDS', 'controls']).to_string(index=False))
log('MDS_SECONDARY_DONE')
