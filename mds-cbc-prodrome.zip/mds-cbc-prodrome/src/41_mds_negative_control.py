"""MDS reviewer analysis R6 (added 4 Oct 2026 after an internal review; post hoc): negative-control outcome.
The Aim 1 prodrome pipeline is repeated for a different outcome, first colorectal cancer (ICD-10 C18-C20, ICD-9 153-154),
with the same eligible CBCs, age/sex reference and 10:1 matched controls. If the long-standing macrocytic red-cell offset
were produced by the design (hospital controls, testing intensity), it would also appear before colorectal cancer.
Outputs: results/mds/v2/negative_control_onset.csv, negative_control_bins.csv"""
import sys, json, time
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv; BP = 60 if QUICK else 300
OUT = cfg.RESULTS / 'mds' / 'v2'; SEED = 20261004; rng = np.random.RandomState(SEED)
t0 = time.time(); log = lambda m: print(f'[{time.time()-t0:7.1f}s] {m}', flush=True)
CORE, DIFF = list(cfg.CORE_CBC), list(cfg.DIFF_CBC); VARS = CORE + ['neutrophils_pct', 'anc', 'n_flag_core']
KEEP = ['subject_id', 'setting', 't'] + CORE + DIFF + ['n_flag_core', 'age_approx', 'gender', 'anchor_age', 'anchor_year']

adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime'], parse_dates=['admittime'])
dx = pd.read_csv(cfg.MIMIC_FILES['diagnoses_icd'], dtype={'icd_code': str}, usecols=['subject_id', 'hadm_id', 'icd_code', 'icd_version'])
c9, c10 = dx.icd_version == 9, dx.icd_version == 10; code = dx.icd_code.str.upper()
is_crc = (c10 & code.str[:3].isin(['C18', 'C19', 'C20'])) | (c9 & code.str[:3].isin(['153', '154']))
is_heme = (c10 & (code.str.startswith('D46') | code.str[:3].isin(['C91', 'C92', 'C93', 'C94', 'C95', 'D45', 'D61']) | code.str.startswith('D47') | code.str.startswith('Z856'))) | \
          (c9 & (code.str[:3].isin(['204', '205', '206', '207', '208', '284']) | code.str.startswith('2387') | code.str.startswith('2384') | code.str.startswith('V106') | code.isin(['28983'])))
heme_subj = set(dx.loc[is_heme, 'subject_id']); crc_hadm = set(dx.loc[is_crc, 'hadm_id']); coded_hadm = set(dx.hadm_id)
t1 = dx[is_crc][['subject_id', 'hadm_id']].drop_duplicates().merge(adm, on=['subject_id', 'hadm_id']).groupby('subject_id').admittime.min().rename('t1')
case_subj = set(t1.index) - heme_subj

inp = pd.read_csv(cfg.PROC / 'admission_cbc_all.csv.gz', parse_dates=['admittime'])
inp = inp[inp.hadm_id.isin(coded_hadm) & ~inp.hadm_id.isin(crc_hadm)].assign(setting='inpatient', t=lambda d: d.admittime)
outp = pd.read_csv(cfg.PROC / 'outpatient_cbc_all.csv.gz', parse_dates=['charttime']).assign(setting='outpatient', t=lambda d: d.charttime)
enc = pd.concat([inp[KEEP], outp[KEEP]], ignore_index=True); del inp, outp
anchor = enc.drop_duplicates('subject_id').set_index('subject_id')[['anchor_age', 'anchor_year', 'gender']]
age_at = lambda sid, t: (anchor.reindex(sid).anchor_age.values + (pd.DatetimeIndex(t).year.values - anchor.reindex(sid).anchor_year.values)).astype(float)
hc = enc[enc.subject_id.isin(case_subj)].merge(t1.reset_index(), on='subject_id'); hc = hc[hc.t < hc.t1].copy()
hc['days_before'] = (hc.t1 - hc.t).dt.total_seconds() / 86400
ci = t1[t1.index.isin(set(hc.subject_id))].reset_index(); ci['age_t1'] = age_at(ci.subject_id.values, ci.t1.values); ci['gender'] = anchor.reindex(ci.subject_id).gender.values
cand = adm[adm.hadm_id.isin(coded_hadm) & ~adm.subject_id.isin(heme_subj | set(t1.index)) & adm.subject_id.isin(anchor.index)]
cand = cand.assign(_r=rng.rand(len(cand))).sort_values(['subject_id', '_r']).drop_duplicates('subject_id')[['subject_id', 'admittime']].rename(columns={'admittime': 'pseudo_t1'})
first_cbc = enc.groupby('subject_id').t.min(); cand = cand[cand.pseudo_t1.values > first_cbc.reindex(cand.subject_id).values]
cand['age_t1'] = age_at(cand.subject_id.values, cand.pseudo_t1.values); cand['gender'] = anchor.reindex(cand.subject_id).gender.values
band = lambda a: (np.floor(np.asarray(a, float) / 5) * 5).astype(int).astype(str)
ci['stratum'] = ci.gender + '_' + band(ci.age_t1); cand['stratum'] = cand.gender + '_' + band(cand.age_t1)
mi = pd.concat([cand[cand.stratum == s].sample(min(k, int((cand.stratum == s).sum())), random_state=SEED) for s, k in (ci.stratum.value_counts() * 10).items()], ignore_index=True)
hm = enc[enc.subject_id.isin(set(mi.subject_id))].merge(mi[['subject_id', 'pseudo_t1']], on='subject_id'); hm = hm[hm.t < hm.pseudo_t1].copy()
hm['days_before'] = (hm.pseudo_t1 - hm.t).dt.total_seconds() / 86400
log(f'colorectal cancer cases with an earlier CBC: {len(ci):,}; matched controls {len(mi):,}')

def ageband(a): return pd.cut(a, [-1, 49.99, 59.99, 69.99, 79.99, 200], labels=['<50', '50-59', '60-69', '70-79', '>=80']).astype(str)
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False); ref = coh[coh.window == 'control'].copy()
ref['anc'] = ref.wbc * ref.neutrophils_pct / 100; ref['k'] = ref.gender + '|' + ageband(ref.age_approx)
med = ref.groupby('k')[VARS].median(); rsd = ((ref.groupby('k')[VARS].quantile(.75) - ref.groupby('k')[VARS].quantile(.25)) / 1.349).where(lambda x: x > 0)
EDGES = np.arange(0, 3653 + 1, 182.625); EDGES[-1] = 3653; NBIN = len(EDGES) - 1; MID = (EDGES[:-1] + EDGES[1:]) / 2 / 365.25
def zscore(h):
    h = h.copy(); h['anc'] = h.wbc * h.neutrophils_pct / 100; k = h.gender + '|' + ageband(h.age_approx)
    for v in VARS: h[v] = (h[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    h['bin'] = np.digitize(h.days_before, EDGES) - 1; return h[(h.bin >= 0) & (h.bin < NBIN)]
def pmat(h):
    g = h.groupby(['subject_id', 'bin'])[VARS].mean(); ids = g.index.get_level_values(0).unique(); pos = pd.Series(np.arange(len(ids)), index=ids)
    X = np.full((len(ids), NBIN, len(VARS)), np.nan); X[pos.reindex(g.index.get_level_values(0)).values, g.index.get_level_values(1).values] = g.values; return X
def wmean(X, w):
    ok = ~np.isnan(X); den = np.einsum('n,nbv->bv', w, ok.astype(float)); return np.einsum('n,nbv->bv', w, np.where(ok, X, 0)) / np.where(den > 0, den, np.nan)
def fit(d, wt, mask):
    best = (np.inf, np.nan, np.nan, np.nan)
    for tau in np.arange(0.5, MID.max() + 1e-9, 0.25):
        x = np.maximum(tau - MID, 0)[mask]; yv = d[mask]; ww = wt[mask]
        if (x > 0).sum() < 2 or (x == 0).sum() < 2: continue
        A = np.c_[np.ones_like(x), x]; W = np.sqrt(ww); coef = np.linalg.lstsq(A * W[:, None], yv * W, rcond=None)[0]; sse = (ww * (yv - A @ coef) ** 2).sum()
        if sse < best[0]: best = (sse, tau, coef[0], coef[1])
    return best[1:]
CX, MX = pmat(zscore(hc)), pmat(zscore(hm)); diff = wmean(CX, np.ones(len(CX))) - wmean(MX, np.ones(len(MX)))
r2 = np.random.RandomState(7); boots = np.stack([wmean(CX, r2.poisson(1, len(CX)).astype(float)) - wmean(MX, r2.poisson(1, len(MX)).astype(float)) for _ in range(BP)])
lo, hi, sd = np.nanpercentile(boots, 2.5, 0), np.nanpercentile(boots, 97.5, 0), np.nanstd(boots, 0); ncase = (~np.isnan(CX)).sum(0)
rows, bins = [], []
for j, v in enumerate(VARS):
    mask = (ncase[:, j] >= 30) & ~np.isnan(diff[:, j]) & (sd[:, j] > 0); wt = np.where(mask, 1 / np.where(sd[:, j] > 0, sd[:, j], 1) ** 2, 0)
    tau, a0, b0 = fit(diff[:, j], wt, mask); bt = np.array([fit(boots[b, :, j], wt, mask & ~np.isnan(boots[b, :, j])) for b in range(BP)], float)
    far = mask & (MID >= 5)
    rows.append(dict(outcome='colorectal cancer (negative control)', var=v, n_cases=len(CX), n_controls=len(MX), diff_0_6m=diff[0, j],
                     mean_diff_5_10y=np.nanmean(diff[far, j]) if far.any() else np.nan, offset=a0, offset_lo=np.nanpercentile(bt[:, 1], 2.5), offset_hi=np.nanpercentile(bt[:, 1], 97.5),
                     tau=tau, tau_lo=np.nanpercentile(bt[:, 0], 2.5), tau_hi=np.nanpercentile(bt[:, 0], 97.5), slope=b0))
    for i in range(NBIN): bins.append(dict(var=v, years_before_mid=MID[i], n_cases=int(ncase[i, j]), diff=diff[i, j], lo=lo[i, j], hi=hi[i, j]))
pd.DataFrame(rows).to_csv(OUT / 'negative_control_onset.csv', index=False); pd.DataFrame(bins).to_csv(OUT / 'negative_control_bins.csv', index=False)
log('negative control\n' + pd.DataFrame(rows).round(2).to_string(index=False)); log('NEGCONTROL_DONE')
