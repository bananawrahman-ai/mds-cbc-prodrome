"""MDS pre-diagnostic cohort (protocol: MDS_paper/docs/mds_protocol.md v1.0).
Output: data/processed/mds_cohort.csv.gz, results/mds/cohort_flow.json
Usage: python src/30_mds_cohort.py [--control-followup admission|any_encounter|none] [--out FILE] [--resultsdir DIR]"""
import argparse, sys, json
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
ap = argparse.ArgumentParser()
ap.add_argument('--out', default=str(cfg.PROC / 'mds_cohort.csv.gz'))
ap.add_argument('--resultsdir', default=str(cfg.RESULTS / 'mds'))
ap.add_argument('--control-followup', default='admission', choices=['admission', 'any_encounter', 'none'])
args = ap.parse_args()
SEED = 20260927; rng = np.random.RandomState(SEED)
OUTDIR = Path(args.resultsdir); OUTDIR.mkdir(parents=True, exist_ok=True)
FLAGS = [t + '_flag' for t in cfg.CORE_CBC]

adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime', 'race'], parse_dates=['admittime'])
dx = pd.read_csv(cfg.MIMIC_FILES['diagnoses_icd'], dtype={'icd_code': str}, usecols=['subject_id', 'hadm_id', 'icd_code', 'icd_version'])
c9, c10 = dx.icd_version == 9, dx.icd_version == 10
code = dx.icd_code.str.upper()
is_mds = (c10 & code.str.startswith('D46')) | (c9 & code.isin(['23872', '23873', '23874', '23875']))
is_leuk = (c9 & code.str[:3].isin(['204', '205', '206', '207', '208'])) | (c10 & code.str[:3].isin(['C91', 'C92', 'C93', 'C94', 'C95']))
is_hist = (c9 & code.str.startswith('V106')) | (c10 & code.str.startswith('Z856'))
is_mpn = (c10 & (code.str.startswith('D45') | code.str.startswith('D471') | code.str.startswith('D473') | code.str.startswith('D474') | code.str.startswith('C946'))) | \
         (c9 & (code.str.startswith('2384') | code.isin(['23871', '23876', '28983'])))
is_aplastic = (c10 & code.str.startswith('D61')) | (c9 & code.str.startswith('284'))
related = is_leuk | is_hist | is_mpn | is_aplastic
mds_hadm = set(dx.loc[is_mds, 'hadm_id']); rel_hadm = set(dx.loc[related, 'hadm_id'])
flag_hadm = mds_hadm | rel_hadm
flag_subj = set(dx.loc[is_mds | related, 'subject_id'])
coded_hadm = set(dx.hadm_id)

mds_adm = dx[is_mds][['subject_id', 'hadm_id']].drop_duplicates().merge(adm[['subject_id', 'hadm_id', 'admittime']], on=['subject_id', 'hadm_id'])
t1 = mds_adm.groupby('subject_id').admittime.min().rename('t1')
first_hadm = mds_adm.merge(t1, on='subject_id'); first_hadm = first_hadm[first_hadm.admittime == first_hadm.t1]
leuk_at_t1 = set(dx[is_leuk & dx.hadm_id.isin(set(first_hadm.hadm_id))].subject_id)
rel = dx[related][['subject_id', 'hadm_id']].drop_duplicates().merge(adm[['subject_id', 'hadm_id', 'admittime']], on=['subject_id', 'hadm_id']).merge(t1, on='subject_id')
bad = set(rel.loc[rel.admittime < rel.t1, 'subject_id'])
case_subj = set(t1.index) - bad
flow = {'patients_with_any_mds_code': int(t1.size), 'excluded_related_code_before_first_mds': int(len(bad)),
        'case_eligible_patients': int(len(case_subj)), 'case_eligible_with_leukaemia_code_at_first_mds_admission': int(len(case_subj & leuk_at_t1))}

inp = pd.read_csv(cfg.PROC / 'admission_cbc_all.csv.gz', parse_dates=['admittime', 'charttime'])
inp['setting'] = 'inpatient'; inp['index_time'] = inp['admittime']
outp = pd.read_csv(cfg.PROC / 'outpatient_cbc_all.csv.gz', parse_dates=['charttime'])
outp['setting'] = 'outpatient'; outp['index_time'] = outp['charttime']; outp['hadm_id'] = np.nan
enc = pd.concat([inp, outp], ignore_index=True)
ok_inp = (enc.setting == 'inpatient') & enc.hadm_id.isin(coded_hadm) & ~enc.hadm_id.isin(flag_hadm)
enc = enc[ok_inp | (enc.setting == 'outpatient')].copy()
flow['eligible_index_encounters_inpatient'] = int((enc.setting == 'inpatient').sum())
flow['eligible_index_encounters_outpatient'] = int((enc.setting == 'outpatient').sum())

cases = enc[enc.subject_id.isin(case_subj)].merge(t1, on='subject_id')
cases['lead_days'] = (cases.t1 - cases.index_time).dt.total_seconds() / 86400
cases = cases[(cases.lead_days > 0) & (cases.lead_days <= 730)]
last_adm = adm.groupby('subject_id').admittime.max().rename('last_adm')
if args.control_followup == 'any_encounter':
    last_adm = pd.concat([last_adm, enc.groupby('subject_id').index_time.max().rename('last_enc')], axis=1).max(axis=1).rename('last_adm')
ctrl_pool = enc[~enc.subject_id.isin(flag_subj)].merge(last_adm, on='subject_id', how='left')
if args.control_followup != 'none':
    ctrl_pool = ctrl_pool[(ctrl_pool.last_adm - ctrl_pool.index_time).dt.total_seconds() >= 30 * 86400]
def pick_one(df):
    df = df.assign(_r=rng.rand(len(df)))
    return df.sort_values(['subject_id', '_r']).drop_duplicates('subject_id').drop(columns='_r')
rows = []
for w, sel in [('lead_30_365', cases[(cases.lead_days >= 30) & (cases.lead_days <= 365)]),
               ('lead_0_29', cases[cases.lead_days < 30]), ('lead_366_730', cases[cases.lead_days > 365])]:
    p = pick_one(sel).assign(window=w, label=1); rows.append(p); flow[f'case_patients_{w}'] = int(len(p))
ctrl = pick_one(ctrl_pool).assign(window='control', label=0, lead_days=np.nan); rows.append(ctrl); flow['control_patients'] = int(len(ctrl))
coh = pd.concat(rows, ignore_index=True)
coh['subtype'] = np.where(coh.label == 1, np.where(coh.subject_id.isin(leuk_at_t1), 'MDS+leukaemia code', 'MDS'), None)
race = adm.dropna(subset=['race']).groupby('subject_id').race.agg(lambda s: s.mode().iloc[0])
def race_group(r):
    r = str(r).upper()
    if r.startswith('WHITE'): return 'White'
    if r.startswith('BLACK'): return 'Black'
    if r.startswith('HISPANIC') or 'LATINO' in r: return 'Hispanic'
    if r.startswith('ASIAN'): return 'Asian'
    if r in ('UNKNOWN', 'UNABLE TO OBTAIN', 'PATIENT DECLINED TO ANSWER', 'NAN'): return 'Unknown'
    return 'Other'
coh['race_group'] = coh.subject_id.map(race).map(race_group).fillna('Unknown')
coh['gender_bin'] = (coh.gender == 'M').astype(float)
subj = coh.groupby('subject_id').label.max().reset_index(); subj['split'] = 'dev'
for lab in (0, 1):
    ids = subj.loc[subj.label == lab, 'subject_id'].values.copy(); rng.shuffle(ids)
    subj.loc[subj.subject_id.isin(ids[: int(round(0.2 * len(ids)))]), 'split'] = 'test'
coh = coh.merge(subj[['subject_id', 'split']], on='subject_id')
keep = ['subject_id', 'hadm_id', 'setting', 'index_time', 'window', 'label', 'lead_days', 'subtype', 'split', 'age_approx',
        'gender', 'gender_bin', 'race_group', 'anchor_year_group'] + cfg.CORE_CBC + cfg.DIFF_CBC + FLAGS + ['n_flag_core', 'n_core_present', 'n_diff_present']
coh[keep].to_csv(args.out, index=False, compression='gzip')
print(json.dumps(flow, indent=2)); print(coh.groupby(['window', 'split']).size().unstack(fill_value=0))
print(coh.groupby(['window', 'setting']).size().unstack(fill_value=0)); print(coh[coh.label == 1].groupby(['window', 'subtype']).size().unstack(fill_value=0))
(OUTDIR / 'cohort_flow.json').write_text(json.dumps(flow, indent=2))
print('ALL_DONE')
