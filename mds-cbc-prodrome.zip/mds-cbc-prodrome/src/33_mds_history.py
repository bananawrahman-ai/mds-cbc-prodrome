"""MDS v2: per-patient CBC histories (protocol MDS_paper/docs/mds_protocol_v2.md).
Outputs (data/processed/):
  mds_hist_cases.csv.gz     every eligible CBC before t1 for all v1-eligible MDS cases
  mds_hist_cohort_ctrl.csv.gz  every eligible CBC of the v1 primary-cohort controls
  mds_hist_matched.csv.gz   matched controls (Aim 1): CBCs before pseudo-t1
  mds_case_info.csv.gz / mds_matched_info.csv.gz  one row per patient (t1 / pseudo-t1, age, sex)"""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
SEED = 20261004; rng = np.random.RandomState(SEED)
OUT = cfg.RESULTS / 'mds' / 'v2'; OUT.mkdir(parents=True, exist_ok=True)
CORE, DIFF = list(cfg.CORE_CBC), list(cfg.DIFF_CBC)
KEEP = ['subject_id', 'setting', 't'] + CORE + DIFF + ['n_flag_core', 'age_approx', 'gender', 'anchor_age', 'anchor_year', 'anchor_year_group']

adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime'], parse_dates=['admittime'])
dx = pd.read_csv(cfg.MIMIC_FILES['diagnoses_icd'], dtype={'icd_code': str}, usecols=['subject_id', 'hadm_id', 'icd_code', 'icd_version'])
c9, c10 = dx.icd_version == 9, dx.icd_version == 10
code = dx.icd_code.str.upper()
is_mds = (c10 & code.str.startswith('D46')) | (c9 & code.isin(['23872', '23873', '23874', '23875']))
is_leuk = (c9 & code.str[:3].isin(['204', '205', '206', '207', '208'])) | (c10 & code.str[:3].isin(['C91', 'C92', 'C93', 'C94', 'C95']))
is_hist = (c9 & code.str.startswith('V106')) | (c10 & code.str.startswith('Z856'))
is_mpn = (c10 & (code.str.startswith('D45') | code.str.startswith('D471') | code.str.startswith('D473') | code.str.startswith('D474') | code.str.startswith('C946'))) | \
         (c9 & (code.str.startswith('2384') | code.isin(['23871', '23876', '28983'])))
is_aplastic = (c10 & code.str.startswith('D61')) | (c9 & code.str.startswith('284'))
related = is_leuk | is_hist | is_mpn | is_aplastic
flag_hadm = set(dx.loc[is_mds | related, 'hadm_id']); flag_subj = set(dx.loc[is_mds | related, 'subject_id']); coded_hadm = set(dx.hadm_id)
mds_adm = dx[is_mds][['subject_id', 'hadm_id']].drop_duplicates().merge(adm, on=['subject_id', 'hadm_id'])
t1 = mds_adm.groupby('subject_id').admittime.min().rename('t1')
rel = dx[related][['subject_id', 'hadm_id']].drop_duplicates().merge(adm, on=['subject_id', 'hadm_id']).merge(t1, on='subject_id')
bad = set(rel.loc[rel.admittime < rel.t1, 'subject_id'])
case_subj = set(t1.index) - bad
del dx, code

inp = pd.read_csv(cfg.PROC / 'admission_cbc_all.csv.gz', parse_dates=['admittime'])
inp = inp[inp.hadm_id.isin(coded_hadm) & ~inp.hadm_id.isin(flag_hadm)].assign(setting='inpatient', t=lambda d: d.admittime)
outp = pd.read_csv(cfg.PROC / 'outpatient_cbc_all.csv.gz', parse_dates=['charttime']).assign(setting='outpatient', t=lambda d: d.charttime)
enc = pd.concat([inp[KEEP], outp[KEEP]], ignore_index=True); del inp, outp
enc['gender_bin'] = (enc.gender == 'M').astype(float)
print(f'eligible CBCs: {len(enc):,}', flush=True)
anchor = enc.drop_duplicates('subject_id').set_index('subject_id')[['anchor_age', 'anchor_year', 'gender']]
def age_at(sid, t):
    a = anchor.reindex(sid)
    return (a.anchor_age.values + (pd.DatetimeIndex(t).year.values - a.anchor_year.values)).astype(float)

# ---- cases
hc = enc[enc.subject_id.isin(case_subj)].merge(t1.reset_index(), on='subject_id')
hc = hc[hc.t < hc.t1].copy(); hc['days_before'] = (hc.t1 - hc.t).dt.total_seconds() / 86400
ci = t1[t1.index.isin(set(hc.subject_id))].reset_index()
ci['age_t1'] = age_at(ci.subject_id.values, ci.t1.values); ci['gender'] = anchor.reindex(ci.subject_id).gender.values
w = pd.read_csv(cfg.PROC / 'heme_workup_events.csv.gz', parse_dates=['first_time']).groupby('subject_id').first_time.min().rename('first_workup')
ci = ci.merge(w, on='subject_id', how='left')
hc.to_csv(cfg.PROC / 'mds_hist_cases.csv.gz', index=False, compression='gzip'); ci.to_csv(cfg.PROC / 'mds_case_info.csv.gz', index=False, compression='gzip')

# ---- v1 primary-cohort controls: full history
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', usecols=['subject_id', 'window', 'index_time'], parse_dates=['index_time'])
cc = coh[coh.window == 'control'][['subject_id', 'index_time']]
hcc = enc[enc.subject_id.isin(set(cc.subject_id))].merge(cc, on='subject_id')
hcc.to_csv(cfg.PROC / 'mds_hist_cohort_ctrl.csv.gz', index=False, compression='gzip')

# ---- matched controls with pseudo-t1 (Aim 1)
cand = adm[adm.hadm_id.isin(coded_hadm) & ~adm.hadm_id.isin(flag_hadm) & ~adm.subject_id.isin(flag_subj) & adm.subject_id.isin(anchor.index)]
cand = cand.assign(_r=rng.rand(len(cand))).sort_values(['subject_id', '_r']).drop_duplicates('subject_id')[['subject_id', 'admittime']].rename(columns={'admittime': 'pseudo_t1'})
first_cbc = enc.groupby('subject_id').t.min()
cand = cand[cand.pseudo_t1.values > first_cbc.reindex(cand.subject_id).values]
cand['age_t1'] = age_at(cand.subject_id.values, cand.pseudo_t1.values); cand['gender'] = anchor.reindex(cand.subject_id).gender.values
band = lambda a: np.floor(np.asarray(a, float) / 5) * 5
ci['stratum'] = ci.gender + '_' + band(ci.age_t1).astype(int).astype(str)
cand['stratum'] = cand.gender + '_' + band(cand.age_t1).astype(int).astype(str)
need = ci.stratum.value_counts() * 10; parts = []; short = 0
for s, k in need.items():
    pool = cand[cand.stratum == s]
    if len(pool) < k: short += k - len(pool)
    parts.append(pool.sample(min(k, len(pool)), random_state=SEED))
mi = pd.concat(parts, ignore_index=True)
mi = mi.merge(w, on='subject_id', how='left')
hm = enc[enc.subject_id.isin(set(mi.subject_id))].merge(mi[['subject_id', 'pseudo_t1']], on='subject_id')
hm = hm[hm.t < hm.pseudo_t1].copy(); hm['days_before'] = (hm.pseudo_t1 - hm.t).dt.total_seconds() / 86400
hm.to_csv(cfg.PROC / 'mds_hist_matched.csv.gz', index=False, compression='gzip'); mi.to_csv(cfg.PROC / 'mds_matched_info.csv.gz', index=False, compression='gzip')

g = hc.groupby('subject_id')
info = {'eligible_cases': len(case_subj), 'cases_with_prediagnostic_cbc': int(ci.shape[0]),
        'case_cbcs': int(len(hc)), 'median_cbcs_per_case': float(g.size().median()),
        'cases_with_cbc_over_2y': int((g.days_before.max() > 730).sum()), 'cases_with_cbc_over_5y': int((g.days_before.max() > 1826).sum()),
        'matched_controls': int(len(mi)), 'matched_shortfall': int(short), 'matched_control_cbcs': int(len(hm)),
        'cohort_controls_with_history': int(hcc.subject_id.nunique()), 'cohort_control_cbcs': int(len(hcc))}
(OUT / 'history_flow.json').write_text(json.dumps(info, indent=2)); print(json.dumps(info, indent=2)); print('HISTORY_DONE')
