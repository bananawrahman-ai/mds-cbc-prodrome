"""MDS v2 Aim 2: does drift from a person's own CBC setpoint detect future MDS better than a single CBC? (protocol v2.0)
Outputs results/mds/v2/setpoint_*.csv"""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import average_precision_score
from sklearn.model_selection import RepeatedStratifiedKFold
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv; OUTPT = '--outpatient-baseline' in sys.argv; SUF = '_posthoc_outpatient_baseline' if OUTPT else ''; NB = 200 if QUICK else 1000; REPS = 1 if QUICK else 5
OUT = cfg.RESULTS / 'mds' / 'v2'; OUT.mkdir(parents=True, exist_ok=True); SEED = 20260927
t0 = time.time(); log = lambda m: print(f'[{time.time()-t0:6.1f}s] {m}', flush=True)
try:
    from xgboost import XGBClassifier
    def model(): return XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=3, min_child_weight=10, subsample=0.8,
                                      colsample_bytree=0.8, tree_method='hist', random_state=SEED, n_jobs=-1, eval_metric='aucpr')
except Exception:
    from sklearn.ensemble import HistGradientBoostingClassifier
    def model(): return HistGradientBoostingClassifier(learning_rate=0.05, max_iter=200, max_leaf_nodes=15, min_samples_leaf=50, random_state=SEED)
CORE, DIFF = list(cfg.CORE_CBC), list(cfg.DIFF_CBC); IDX = CORE + DIFF; DEM = ['age_approx', 'gender_bin']

def auc(y, s):
    r = pd.Series(s).rank().values; n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def sidx(rng, y):
    pos = np.where(y == 1)[0]; neg = np.where(y == 0)[0]
    return np.r_[rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]
def sens_at(y, s, spec):
    thr = np.quantile(s[y == 0], spec); return (s[y == 1] > thr).mean(), y[s > thr].mean() if (s > thr).any() else np.nan
def summ(name, y, s, **kw):
    rng = np.random.RandomState(1); v = [auc(y[i], s[i]) for i in (sidx(rng, y) for _ in range(NB))]
    se95, ppv95 = sens_at(y, s, .95); se99, ppv99 = sens_at(y, s, .99)
    return dict(analysis=name, n=len(y), cases=int(y.sum()), auroc=auc(y, s), auroc_lo=np.percentile(v, 2.5), auroc_hi=np.percentile(v, 97.5),
                ap=average_precision_score(y, s), sens_spec95=se95, ppv_spec95=ppv95, sens_spec99=se99, ppv_spec99=ppv99, **kw)
def paired(y, a, b, f):
    rng = np.random.RandomState(2); v = []
    for _ in range(NB):
        i = sidx(rng, y); v.append(f(y[i], a[i]) - f(y[i], b[i]))
    return f(y, a) - f(y, b), np.percentile(v, 2.5), np.percentile(v, 97.5)

coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False, parse_dates=['index_time'])
p = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
hc = pd.read_csv(cfg.PROC / 'mds_hist_cases.csv.gz', parse_dates=['t'])
hcc = pd.read_csv(cfg.PROC / 'mds_hist_cohort_ctrl.csv.gz', parse_dates=['t'])
H = pd.concat([hc[['subject_id', 't', 'setting'] + IDX], hcc[['subject_id', 't', 'setting'] + IDX]], ignore_index=True)
if OUTPT: H = H[H.setting == 'outpatient']  # POST HOC (4 Oct 2026): setpoints from outpatient CBCs only, less perturbed by acute illness
H = H.merge(p[['subject_id', 'index_time']], on='subject_id')
H['gap'] = (H.index_time - H.t).dt.total_seconds() / 86400 / 365.25
w = pd.read_csv(cfg.PROC / 'heme_workup_events.csv.gz', parse_dates=['first_time']).groupby('subject_id').first_time.min()
log(f'history rows for cohort patients: {len(H):,}')

def build(min_gap):
    base = H[(H.gap >= min_gap) & (H.gap <= 10)]
    nb = base.groupby('subject_id').size(); keep = nb[nb >= 2].index
    d = p[p.subject_id.isin(keep)].copy().set_index('subject_id'); base = base[base.subject_id.isin(keep)]
    sp = base.groupby('subject_id')[IDX].median()
    cnt = base.groupby('subject_id')[IDX].count(); var = base.groupby('subject_id')[IDX].var(ddof=1)
    wsd = np.sqrt(var.where(cnt >= 3).mean())  # pooled within-person SD, label-blind
    feats = {}
    for v in IDX:
        d[f'set_{v}'] = sp[v]; d[f'drift_{v}'] = (d[v] - sp[v]) / wsd[v]
        # OLS slope (per year) over baseline points + index point; x = -gap (years, index at 0)
        b = base[['subject_id', 'gap', v]].dropna(); b = pd.concat([b, d[[v]].dropna().reset_index().assign(gap=0.0)], ignore_index=True)
        b['x'] = -b.gap; g = b.groupby('subject_id')
        n = g.size(); sx = g.x.sum(); sy = g[v].sum(); sxx = (b.x * b.x).groupby(b.subject_id).sum(); sxy = (b.x * b[v]).groupby(b.subject_id).sum()
        den = n * sxx - sx * sx
        d[f'slope_{v}'] = ((n * sxy - sx * sy) / den.where(den > 1e-9)).where(n >= 3)
    d['n_baseline'] = nb.reindex(d.index); d['baseline_span_years'] = base.groupby('subject_id').gap.max().reindex(d.index)
    d['personal_breach'] = sum((d[f'drift_{v}'].abs() > 1.96).astype(int) for v in CORE)
    d['prior_workup'] = (w.reindex(d.index) < d.index_time).values
    return d.reset_index(), wsd

SETS = {'SNAP': IDX + DEM, 'SET': [f'set_{v}' for v in IDX] + DEM, 'DRIFT': [f'drift_{v}' for v in IDX] + [f'slope_{v}' for v in CORE] + DEM}
SETS['FULL'] = IDX + DEM + [f'drift_{v}' for v in IDX] + [f'slope_{v}' for v in CORE]
def cv(d, cols):
    X = d[cols].astype(float); y = d.label.values; o = np.zeros((REPS, len(y)))
    for j, (tr, te) in enumerate(RepeatedStratifiedKFold(n_splits=5, n_repeats=REPS, random_state=SEED).split(X, y)):
        o[j // 5, te] = model().fit(X.iloc[tr], y[tr]).predict_proba(X.iloc[te])[:, 1]
    return o.mean(0)

def run(min_gap, tag, sub=None):
    d, wsd = build(min_gap)
    if sub == 'no_prior_workup': d = d[~d.prior_workup].reset_index(drop=True)
    y = d.label.values; log(f'{tag}: {len(d):,} patients, {y.sum()} cases')
    oof = {k: cv(d, c) for k, c in SETS.items()}
    rows = [summ(f'{tag} | {k}', y, s) for k, s in oof.items()]
    rows += [summ(f'{tag} | population flag count', y, d.n_flag_core.fillna(0).values), summ(f'{tag} | personal breach count', y, d.personal_breach.values)]
    pr = []
    for a, b in [('FULL', 'SNAP'), ('DRIFT', 'SNAP'), ('SET', 'SNAP')]:
        for met, f in [('AUROC', auc), ('AP', average_precision_score)]:
            x, lo, hi = paired(y, oof[a], oof[b], f); pr.append(dict(analysis=tag, comparison=f'{a} minus {b}', metric=met, difference=x, ci_lo=lo, ci_hi=hi))
    for met, f in [('AUROC', auc), ('AP', average_precision_score)]:
        x, lo, hi = paired(y, d.personal_breach.values.astype(float), d.n_flag_core.fillna(0).values, f)
        pr.append(dict(analysis=tag, comparison='personal breach count minus population flag count', metric=met, difference=x, ci_lo=lo, ci_hi=hi))
    return d, oof, rows, pr, wsd

d, oof, rows, pr, wsd = run(1.0, 'primary (baseline >= 1 y before index)')
pd.DataFrame({'index': IDX, 'within_person_sd': wsd[IDX].values}).to_csv(OUT / f'setpoint_within_person_sd{SUF}.csv', index=False)
pd.DataFrame({'subject_id': d.subject_id, 'label': d.label, **{f'oof_{k}': v for k, v in oof.items()}}).to_csv(OUT / f'setpoint_oof{SUF}.csv.gz', index=False, compression='gzip')
# normal-CBC subgroup (no laboratory-flagged core index at the index CBC)
y = d.label.values; nf = (d.n_flag_core.fillna(0) == 0).values; le1 = (d.n_flag_core.fillna(0) <= 1).values
sub = []
for nm, m in [('index CBC with 0 population flags', nf), ('index CBC with <= 1 population flag', le1)]:
    if y[m].sum() >= 5:
        sub.append(dict(subgroup=nm, n=int(m.sum()), cases=int(y[m].sum()), case_share_any_personal_breach=(d.personal_breach.values[m & (y == 1)] >= 1).mean(),
                        control_share_any_personal_breach=(d.personal_breach.values[m & (y == 0)] >= 1).mean(),
                        auroc_DRIFT=auc(y[m], oof['DRIFT'][m]), auroc_SNAP=auc(y[m], oof['SNAP'][m]), auroc_FULL=auc(y[m], oof['FULL'][m])))
pd.DataFrame(sub).to_csv(OUT / f'setpoint_normal_cbc{SUF}.csv', index=False); log('normal-CBC subgroup\n' + pd.DataFrame(sub).round(3).to_string(index=False))
for mg, tag, s in ([] if OUTPT else [(2.0, 'sensitivity: baseline >= 2 y before index', None), (1.0, 'sensitivity: no prior haematology work-up', 'no_prior_workup')]):
    _, _, r2, p2, _ = run(mg, tag, s); rows += r2; pr += p2
R = pd.DataFrame(rows); R.to_csv(OUT / f'setpoint_discrimination{SUF}.csv', index=False); log('discrimination\n' + R.round(4).to_string(index=False))
P = pd.DataFrame(pr); P.to_csv(OUT / f'setpoint_paired{SUF}.csv', index=False); log('paired\n' + P.round(4).to_string(index=False))
# descriptives
desc = d.groupby('label').agg(n=('subject_id', 'size'), median_baseline_cbcs=('n_baseline', 'median'), median_span_years=('baseline_span_years', 'median'),
                              median_age=('age_approx', 'median'), any_personal_breach=('personal_breach', lambda s: (s >= 1).mean()))
desc.to_csv(OUT / f'setpoint_descriptives{SUF}.csv'); log('descriptives\n' + desc.round(3).to_string())
med = d.groupby('label')[[f'drift_{v}' for v in CORE]].median().T; med.to_csv(OUT / f'setpoint_median_drift{SUF}.csv'); log('median drift z\n' + med.round(2).to_string())
log('SETPOINT_DONE')
