"""Outpatient index CBCs for the pre-diagnostic study (protocol section 3).

From cbc_all_long.csv.gz (09_extract_all_cbc.py): rows with no hadm_id,
same cleaning/eligibility as 10_build_admission_cbc.py (>= 6 of 9 core,
age >= 18, duplicate/conflict handling, impossible values -> missing, lab
abnormal flags pivoted). Specimens drawn between 6 h before admission and
discharge of any hospital stay are dropped (they belong to that stay).
Earliest eligible specimen per patient per calendar day is kept.

Output: data/processed/outpatient_cbc_all.csv.gz
Usage: python src/12_build_outpatient_cbc.py [--src FILE] [--out FILE] [--tmp DIR]
"""
import argparse, os, sys, time, pickle
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import config as cfg

ap = argparse.ArgumentParser()
ap.add_argument('--src', default=str(cfg.PROC / 'cbc_all_long.csv.gz'))
ap.add_argument('--out', default=str(cfg.PROC / 'outpatient_cbc_all.csv.gz'))
ap.add_argument('--tmp', default=None)
ap.add_argument('--buckets', type=int, default=16)
args = ap.parse_args()
SRC = Path(args.src); OUT = Path(args.out)
TMP = Path(args.tmp) if args.tmp else Path.home() / 'prediag_tmp' / 'outpatient'
TMP.mkdir(parents=True, exist_ok=True)
NB = args.buckets
t0 = time.time()

adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime', 'dischtime'],
                  parse_dates=['admittime', 'dischtime'])
pat = pd.read_csv(cfg.MIMIC_FILES['patients'], usecols=['subject_id', 'gender', 'anchor_age', 'anchor_year', 'anchor_year_group'])
use = ['subject_id', 'specimen_id', 'charttime', 'valuenum', 'test', 'flag', 'hadm_id']

# ---- pass 1: route outpatient rows into subject buckets (so specimens never split)
if not (TMP / 'PASS1_DONE').exists():
    for b in range(NB):
        (TMP / f'b{b:02d}.csv').unlink(missing_ok=True)
    for i, ch in enumerate(pd.read_csv(SRC, usecols=use, chunksize=2_000_000, dtype={'flag': str})):
        ch = ch[ch.hadm_id.isna()].drop(columns='hadm_id')
        for b, g in ch.groupby(ch.subject_id % NB):
            f = TMP / f'b{b:02d}.csv'
            g.to_csv(f, mode='a', header=not f.exists(), index=False)
        print(f'pass1 chunk {i} ({time.time()-t0:.0f}s)', flush=True)
    (TMP / 'PASS1_DONE').write_text('done')

keys = ['subject_id', 'specimen_id', 'charttime']
out_parts = []
for b in range(NB):
    f = TMP / f'b{b:02d}.csv'
    if not f.exists():
        continue
    cbc = pd.read_csv(f, dtype={'flag': str}, parse_dates=['charttime'])
    cbc = cbc.dropna(subset=['specimen_id', 'charttime']).drop_duplicates(keys + ['test', 'valuenum'])
    cbc = cbc.loc[~cbc.duplicated(keys + ['test'], keep=False)]
    wide = cbc.pivot(index=keys, columns='test', values='valuenum').reset_index(); wide.columns.name = None
    for t in cfg.CORE_CBC + cfg.DIFF_CBC:
        if t not in wide:
            wide[t] = float('nan')
    for t in ['hemoglobin', 'hematocrit', 'rbc', 'mcv', 'mch', 'mchc', 'rdw']:
        wide.loc[wide[t] <= 0, t] = float('nan')
    for t in ['hematocrit'] + cfg.DIFF_CBC:
        wide.loc[wide[t] > 100, t] = float('nan')
    for t in cfg.CORE_CBC + cfg.DIFF_CBC:
        wide.loc[wide[t] < 0, t] = float('nan')
    fl = cbc.assign(ab=cbc.flag.eq('abnormal').astype(float)).pivot(index=keys, columns='test', values='ab')
    fl.columns = [c + '_flag' for c in fl.columns]
    wide = wide.merge(fl.reset_index(), on=keys, how='left')
    for t in cfg.CORE_CBC:
        if t + '_flag' not in wide:
            wide[t + '_flag'] = float('nan')
        wide.loc[wide[t].isna(), t + '_flag'] = float('nan')
    wide['n_flag_core'] = wide[[t + '_flag' for t in cfg.CORE_CBC]].sum(axis=1, min_count=1)
    wide['n_core_present'] = wide[cfg.CORE_CBC].notna().sum(axis=1)
    wide['n_diff_present'] = wide[cfg.DIFF_CBC].notna().sum(axis=1)
    wide = wide[wide.n_core_present >= 6].merge(pat, on='subject_id')
    wide['age_approx'] = wide.anchor_age + wide.charttime.dt.year - wide.anchor_year
    wide = wide[wide.age_approx >= 18]
    # drop specimens that fall inside any hospital stay (6 h before admission to discharge)
    ov = wide[['subject_id', 'specimen_id', 'charttime']].merge(adm, on='subject_id')
    inside = ov[(ov.charttime >= ov.admittime - pd.Timedelta(hours=6)) & (ov.charttime <= ov.dischtime)].specimen_id
    wide = wide[~wide.specimen_id.isin(set(inside))]
    wide['day'] = wide.charttime.dt.floor('D')
    wide = wide.sort_values(['subject_id', 'charttime', 'specimen_id']).drop_duplicates(['subject_id', 'day']).drop(columns='day')
    out_parts.append(wide)
    print(f'bucket {b}: {len(wide):,} outpatient index CBCs ({time.time()-t0:.0f}s)', flush=True)

res = pd.concat(out_parts, ignore_index=True)
res.to_csv(OUT, index=False, compression='gzip')
print(f'outpatient index CBCs: {len(res):,}; patients: {res.subject_id.nunique():,} -> {OUT}')
print('ALL_DONE')
