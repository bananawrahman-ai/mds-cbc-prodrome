"""MDS v2 Aim 3: silent-alert simulation over patients' full CBC histories (protocol v2.0).
Outputs results/mds/v2/silent_*.csv"""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.model_selection import StratifiedKFold
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
OUT = cfg.RESULTS / 'mds' / 'v2'; OUT.mkdir(parents=True, exist_ok=True); SEED = 20260927
t0 = time.time(); log = lambda m: print(f'[{time.time()-t0:6.1f}s] {m}', flush=True)
try:
    from xgboost import XGBClassifier
    def model(): return XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=3, min_child_weight=10, subsample=0.8,
                                      colsample_bytree=0.8, tree_method='hist', random_state=SEED, n_jobs=-1, eval_metric='aucpr')
except Exception:
    from sklearn.ensemble import HistGradientBoostingClassifier
    def model(): return HistGradientBoostingClassifier(learning_rate=0.05, max_iter=200, max_leaf_nodes=15, min_samples_leaf=50, random_state=SEED)
F = list(cfg.CORE_CBC) + list(cfg.DIFF_CBC) + ['age_approx', 'gender_bin']
EDGES = np.arange(0, 1827 + 1, 91.3125); EDGES[-1] = 1827; NBIN = len(EDGES) - 1; MID = (EDGES[:-1] + EDGES[1:]) / 2 / 365.25
def wilson(k, n, z=1.96):
    if n == 0: return np.nan, np.nan
    p = k / n; c = (p + z * z / (2 * n)) / (1 + z * z / n); h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / (1 + z * z / n); return c - h, c + h

coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False, parse_dates=['index_time'])
p = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True); y = p.label.values
fold = np.zeros(len(p), int); models = []; oof = np.zeros(len(p))
for k, (tr, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=SEED).split(p, y)):
    m = model().fit(p.loc[tr, F].astype(float), y[tr]); models.append(m); fold[te] = k
    oof[te] = m.predict_proba(p.loc[te, F].astype(float))[:, 1]
fold_of = pd.Series(fold, index=p.subject_id); log('fold models trained')
ctrl_sorted = np.sort(oof[y == 0])
T = {'spec95': np.quantile(oof[y == 0], .95), 'spec99': np.quantile(oof[y == 0], .99)}

def score(h):
    h = h.copy(); X = h[F].astype(float); f = fold_of.reindex(h.subject_id).values; s = np.full(len(h), np.nan)
    known = ~np.isnan(f)
    for k, m in enumerate(models):
        idx = known & (f == k)
        if idx.any(): s[idx] = m.predict_proba(X[idx])[:, 1]
    if (~known).any(): s[~known] = np.mean([m.predict_proba(X[~known])[:, 1] for m in models], 0)
    h['score'] = s; return h

ci = pd.read_csv(cfg.PROC / 'mds_case_info.csv.gz', parse_dates=['t1', 'first_workup'])
hc = score(pd.read_csv(cfg.PROC / 'mds_hist_cases.csv.gz', parse_dates=['t', 't1']))
hcc = score(pd.read_csv(cfg.PROC / 'mds_hist_cohort_ctrl.csv.gz', parse_dates=['t', 'index_time']))
hm = score(pd.read_csv(cfg.PROC / 'mds_hist_matched.csv.gz', parse_dates=['t']))
wk = pd.read_csv(cfg.PROC / 'heme_workup_events.csv.gz', parse_dates=['first_time'])
log(f'scored {len(hc):,} case CBCs, {len(hcc):,} cohort-control CBCs, {len(hm):,} matched-control CBCs')
primary_cases = set(p.loc[p.label == 1, 'subject_id'])

rows, traj, miss = [], [], []
for tn, thr in T.items():
    for setname, ids in [('primary-cohort cases', primary_cases), ('all cases with a pre-diagnostic CBC', set(ci.subject_id))]:
        h = hc[hc.subject_id.isin(ids)]; a = h[h.score > thr]
        first = a.groupby('subject_id').t.min(); c = ci.set_index('subject_id').reindex(sorted(ids))
        lead = (c.t1 - first.reindex(c.index)).dt.total_seconds() / 86400
        rec = c.first_workup.where(c.first_workup < c.t1, c.t1)
        gain = (rec - first.reindex(c.index)).dt.total_seconds() / 86400
        n = len(c); r = dict(threshold=tn, threshold_value=thr, case_set=setname, n_cases=n)
        for dd in (30, 180, 365, 730):
            k = int((lead >= dd).sum()); lo, hi = wilson(k, n); r[f'alert_ge_{dd}d'] = k / n; r[f'alert_ge_{dd}d_lo'] = lo; r[f'alert_ge_{dd}d_hi'] = hi
        l30 = lead[lead >= 30]; g30 = gain[lead >= 30]
        r.update(median_lead_days=l30.median(), lead_q1=l30.quantile(.25), lead_q3=l30.quantile(.75),
                 median_gain_over_workup_days=g30.median(), gain_q1=g30.quantile(.25), gain_q3=g30.quantile(.75),
                 share_alert_before_workup_by_90d=float((g30 >= 90).sum() / n), share_cases_with_workup_before_t1=float((c.first_workup < c.t1).mean()))
        rows.append(r)
        if setname == 'primary-cohort cases':
            # missed opportunities: first alert >= 90 d before t1; earliest haematology work-up relative to it
            a90 = a[(a.t1 - a.t).dt.days >= 90]
            fa = a90.groupby('subject_id').t.min(); fw = c.first_workup.reindex(fa.index)
            already = fw < fa; within = (fw >= fa) & (fw <= fa + pd.Timedelta(days=90))
            gapd = (fw.where(fw < c.t1.reindex(fa.index), c.t1.reindex(fa.index)) - fa).dt.days
            miss.append(dict(threshold=tn, cases_with_alert_ge_90d=int(len(fa)), already_worked_up_at_first_alert=int(already.sum()),
                             workup_within_90d_of_first_alert=int(within.sum()), missed_no_workup_within_90d=int((~already & ~within).sum()),
                             median_days_first_alert_to_workup_or_t1_in_missed=float(gapd[~already & ~within].median())))
    # alert burden in the cohort controls (all CBCs, including those after the index CBC)
    hcc_a = hcc[hcc.score > thr]; nctl = hcc.subject_id.nunique()
    gt = hcc.groupby('subject_id').t; span = (gt.max() - gt.min()).dt.total_seconds() / 86400 / 365.25
    py = float(span.clip(lower=1 / 365.25).sum()); ever = hcc_a.subject_id.nunique()
    cases_alert = rows[-2]['alert_ge_30d'] * rows[-2]['n_cases']
    rows[-2].update(controls=nctl, controls_ever_alerted=ever, share_controls_ever_alerted=ever / nctl, control_person_years=py,
                    first_alerts_per_1000_py=1000 * ever / py, alerted_controls_per_detected_case=ever / cases_alert if cases_alert else np.nan,
                    control_cbcs=len(hcc), share_control_cbcs_alerted=len(hcc_a) / len(hcc))
    # trajectories: share of patients with an above-threshold CBC per 3-month bin, cases vs matched controls
    for grp, h, col in [('cases', hc[hc.subject_id.isin(set(ci.subject_id))], 'days_before'), ('matched controls', hm, 'days_before')]:
        h = h.assign(bin=np.digitize(h[col], EDGES) - 1); h = h[(h.bin >= 0) & (h.bin < NBIN)]
        pb = h.groupby(['subject_id', 'bin']).score.max().reset_index(); pb['hit'] = pb.score > thr
        for b, g in pb.groupby('bin'):
            k, n = int(g.hit.sum()), len(g); lo, hi = wilson(k, n)
            traj.append(dict(threshold=tn, group=grp, bin=int(b), years_before_mid=MID[int(b)], n=n, share_alert=k / n, lo=lo, hi=hi,
                             median_score_percentile=float(np.median(np.searchsorted(ctrl_sorted, g.score.values) / len(ctrl_sorted)))))
R = pd.DataFrame(rows); R.to_csv(OUT / 'silent_alerts.csv', index=False); log('alerts\n' + R.round(3).T.to_string())
pd.DataFrame(traj).to_csv(OUT / 'silent_trajectory.csv', index=False)
M = pd.DataFrame(miss); M.to_csv(OUT / 'silent_missed_opportunities.csv', index=False); log('missed\n' + M.to_string(index=False))
log('SILENT_DONE')
