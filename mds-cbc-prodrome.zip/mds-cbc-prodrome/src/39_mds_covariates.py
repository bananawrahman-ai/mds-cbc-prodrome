"""MDS reviewer analyses (R1-R6, added 4 Oct 2026 after an internal review): per-patient dates of possible confounders
and of the first bone-marrow laboratory test.
Diagnosis-code groups come from diagnoses_icd (date = admission time); prescriptions are not in this extract,
so drug exposure is proxied by indication codes (chemotherapy encounters, autoimmune disease, transplant).
Output: data/processed/mds_covariates.csv.gz (subject_id, first_<group> for each group, first_marrow)"""
import sys, json
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
OUT = cfg.RESULTS / 'mds' / 'v2'; OUT.mkdir(parents=True, exist_ok=True)

# (ICD-10 prefixes, ICD-9 prefixes); prefixes are matched on codes without dots
GROUPS = {
    'solid_cancer_or_history': ([f'C{i:02d}' for i in range(0, 81)] + ['Z85'], [str(i) for i in range(140, 200)] + ['V10']),
    'chemo_or_radiotherapy': (['Z510', 'Z511', 'Z9221', 'Z923'], ['V580', 'V581', 'V8741', 'V153']),
    'alcohol': (['F10', 'K70', 'Z7141'], ['303', '3050', '5710', '5711', '5712', '5713', 'V113']),
    'liver_disease': (['K71', 'K72', 'K73', 'K74', 'K75', 'K76', 'K77', 'B18'], ['571', '572', '573', '0704', '0705']),
    'b12_folate_deficiency': (['D51', 'D52', 'E538'], ['2810', '2811', '2812', '2662']),
    'hiv': (['B20', 'Z21'], ['042', 'V08']),
    'autoimmune_or_transplant': (['M05', 'M06', 'K50', 'K51', 'L40', 'M32', 'Z94'], ['714', '555', '556', '6961', '7100', 'V42']),
    'ckd': (['N18'], ['585']),
    'hypothyroidism': (['E03', 'E02'], ['244']),
}
# non-MDS haematological codes excluded from controls (for the burden analysis)
HEME = (['C91', 'C92', 'C93', 'C94', 'C95', 'Z856', 'D45', 'D471', 'D473', 'D474', 'D61'],
        ['204', '205', '206', '207', '208', 'V106', '2384', '23871', '23876', '28983', '284'])

adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime'], parse_dates=['admittime'])
dx = pd.read_csv(cfg.MIMIC_FILES['diagnoses_icd'], dtype={'icd_code': str}, usecols=['subject_id', 'hadm_id', 'icd_code', 'icd_version'])
dx['code'] = dx.icd_code.str.upper().str.replace('.', '', regex=False)
dx = dx.merge(adm[['hadm_id', 'admittime']], on='hadm_id', how='left')
def match(prefixes10, prefixes9):
    return ((dx.icd_version == 10) & dx.code.str.startswith(tuple(prefixes10))) | ((dx.icd_version == 9) & dx.code.str.startswith(tuple(prefixes9)))
cols = {}
for g, (p10, p9) in GROUPS.items():
    m = match(p10, p9)
    if g == 'solid_cancer_or_history':  # personal history of leukaemia is not a solid cancer
        m &= ~(dx.code.str.startswith('Z856') | dx.code.str.startswith('V106'))
    cols[f'first_{g}'] = dx[m].groupby('subject_id').admittime.min()
cols['first_heme_other'] = dx[match(*HEME)].groupby('subject_id').admittime.min()
cov = pd.DataFrame(cols)
cov['first_any_confounder'] = cov[[f'first_{g}' for g in GROUPS]].min(axis=1)
w = pd.read_csv(cfg.PROC / 'heme_workup_events.csv.gz', parse_dates=['first_time'])
cov = cov.join(w[w.category == 'bone_marrow'].groupby('subject_id').first_time.min().rename('first_marrow'), how='outer')
cov.index.name = 'subject_id'
cov.reset_index().to_csv(cfg.PROC / 'mds_covariates.csv.gz', index=False, compression='gzip')
summary = {c: int(cov[c].notna().sum()) for c in cov.columns}
(OUT / 'reviewer_covariate_counts.json').write_text(json.dumps(summary, indent=2)); print(json.dumps(summary, indent=2)); print('COVARIATES_DONE')
