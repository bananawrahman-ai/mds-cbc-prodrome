"""MDS v2 post hoc P3 (added 4 Oct 2026 after results were seen): split the case-control mean difference at the index CBC
into the part already present in the setpoint (median of CBCs 1-10 y before the index) and the part added by drift,
both scaled by the SD of control setpoints; plus age-only AUROC in the Aim 2 subset. Output: results/mds/v2/posthoc_p3_decomposition.csv"""
import pandas as pd, numpy as np
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]; P = ROOT / 'data' / 'processed'; OUT = ROOT / 'results' / 'mds' / 'v2'
IDX = ['hemoglobin', 'rbc', 'mcv', 'rdw', 'platelet', 'wbc', 'neutrophils_pct']
o = pd.read_csv(OUT / 'setpoint_oof.csv.gz', usecols=['subject_id', 'label'])
c = pd.read_csv(P / 'mds_cohort.csv.gz', low_memory=False, usecols=['subject_id', 'label', 'window', 'index_time', 'age_approx'] + IDX, parse_dates=['index_time'])
c = c[c.window.isin(['lead_30_365', 'control'])].merge(o, on=['subject_id', 'label'])
cols = ['subject_id', 't'] + IDX
h = pd.concat([pd.read_csv(P / 'mds_hist_cases.csv.gz', usecols=cols, parse_dates=['t']), pd.read_csv(P / 'mds_hist_cohort_ctrl.csv.gz', usecols=cols, parse_dates=['t'])])
h = h[h.subject_id.isin(set(c.subject_id))].merge(c[['subject_id', 'index_time']], on='subject_id')
gap = (h.index_time - h.t).dt.days / 365.25; h = h[(gap >= 1) & (gap <= 10)]
sp = h.groupby('subject_id')[IDX].median(); c = c.set_index('subject_id'); y = c.label
rows = []
for v in IDX:
    s = sp[v].reindex(c.index); d = c[v] - s; sd = s[y == 0].std()
    off = (s[y == 1].mean() - s[y == 0].mean()) / sd; dr = (d[y == 1].mean() - d[y == 0].mean()) / sd
    rows.append(dict(index=v, setpoint_offset_sd=off, drift_sd=dr, total_sd=off + dr, share_in_setpoint=off / (off + dr) if np.sign(off) == np.sign(dr) else np.nan))
r = pd.Series(c.age_approx).rank().values; n1 = y.sum(); n0 = len(y) - n1
rows.append(dict(index='age-only AUROC in Aim 2 subset', setpoint_offset_sd=(r[y.values == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)))
pd.DataFrame(rows).to_csv(OUT / 'posthoc_p3_decomposition.csv', index=False); print(pd.DataFrame(rows).round(3).to_string(index=False))
