"""MDS revision analyses after the second (journal-style) review, 6 Oct 2026. All post hoc; protocol amendment R8-R14.
R8  diagnosis date: earliest-suspicion date t0 = min(t1, first haematology work-up, first MDS-directed drug order);
    Aim 1 re-anchored at t0, and 'strictly incident' cases (no work-up, MDS-directed drug or ESA before t1 - 30 d).
R9  Aim 1 longitudinal model: random-intercept linear mixed model on every CBC (piecewise-linear time, case interaction,
    inpatient indicator) plus the within-person (fixed-effects) change, with patient-level bootstrap CIs; and the subset
    of patients with CBCs both >= 5 y and <= 2 y before the anchor.
R10 Aim 2 at earlier horizons: index CBC 1-3 y and 3-5 y before t1 (cases), same controls; SNAP/SET/FULL/AGE models,
    personal vs population deviation scores, and the subgroup whose index CBC had no population flag.
R11 age: Aim 2 and Aim 3 discrimination within age bands and in a 1:10 sex x 5-year-age matched subsample.
R12 testing intensity: alert sensitivity by number of CBCs, thinned case histories, control alert rate by number of CBCs.
R13 simple-rule comparators for the index CBC and for the silent alert.
R14 outcomes after t1: 1-year mortality and progression to AML within 2 years, by alert status.
Outputs: results/mds/v2/revision_*.csv; prints REVISION_DONE."""
import sys, time, json, traceback
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import average_precision_score
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv; NB = 200 if QUICK else 1000; BOOT = 40 if QUICK else 200; REPS = 1 if QUICK else 3
OUT = cfg.RESULTS / 'mds' / 'v2'; SEED = 20261006; RAW = Path(cfg.MIMIC_FILES['admissions']).parent
t0_ = time.time(); log = lambda m: print(f'[{time.time()-t0_:7.1f}s] {m}', flush=True)
try:
    from xgboost import XGBClassifier
    def model(): return XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=3, min_child_weight=10, subsample=0.8,
                                      colsample_bytree=0.8, tree_method='hist', random_state=SEED, n_jobs=-1, eval_metric='aucpr')
except Exception:
    from sklearn.ensemble import HistGradientBoostingClassifier
    def model(): return HistGradientBoostingClassifier(learning_rate=0.05, max_iter=200, max_leaf_nodes=15, min_samples_leaf=50, random_state=SEED)
CORE, DIFF = list(cfg.CORE_CBC), list(cfg.DIFF_CBC); IDX = CORE + DIFF; DEM = ['age_approx', 'gender_bin']
VARS = CORE + ['neutrophils_pct', 'anc', 'n_flag_core']
FAILED = []
def section(fn):
    try: fn()
    except Exception:
        FAILED.append(fn.__name__); log(f'SECTION FAILED {fn.__name__}\n' + traceback.format_exc())
    return fn

def auc(y, s):
    r = pd.Series(s).rank().values; n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0) if n1 and n0 else np.nan
def sidx(rng, y):
    pos = np.where(y == 1)[0]; neg = np.where(y == 0)[0]; return np.r_[rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]
def boot_ci(y, s, f=auc):
    rng = np.random.RandomState(1); v = [f(y[i], s[i]) for i in (sidx(rng, y) for _ in range(NB))]; return np.nanpercentile(v, 2.5), np.nanpercentile(v, 97.5)
def paired(y, a, b, f=auc):
    rng = np.random.RandomState(2); v = []
    for _ in range(NB):
        i = sidx(rng, y); v.append(f(y[i], a[i]) - f(y[i], b[i]))
    return f(y, a) - f(y, b), np.nanpercentile(v, 2.5), np.nanpercentile(v, 97.5)
def ageband(a): return pd.cut(a, [-1, 49.99, 59.99, 69.99, 79.99, 200], labels=['<50', '50-59', '60-69', '70-79', '>=80']).astype(str)
def wilson(k, n):
    if n == 0: return (np.nan, np.nan)
    p = k / n; z = 1.96; d = 1 + z * z / n; c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d; return c - h, c + h

# ---------------- shared inputs
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False, parse_dates=['index_time'])
p = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
ci = pd.read_csv(cfg.PROC / 'mds_case_info.csv.gz', parse_dates=['t1'])
mi = pd.read_csv(cfg.PROC / 'mds_matched_info.csv.gz', parse_dates=['pseudo_t1'])
hc = pd.read_csv(cfg.PROC / 'mds_hist_cases.csv.gz', parse_dates=['t', 't1'])
hm = pd.read_csv(cfg.PROC / 'mds_hist_matched.csv.gz', parse_dates=['t', 'pseudo_t1'])
hcc = pd.read_csv(cfg.PROC / 'mds_hist_cohort_ctrl.csv.gz', parse_dates=['t', 'index_time'])
wk = pd.read_csv(cfg.PROC / 'heme_workup_events.csv.gz', parse_dates=['first_time'])
first_wk = wk.groupby('subject_id').first_time.min()
ref = p[p.label == 0].copy(); ref['anc'] = ref.wbc * ref.neutrophils_pct / 100; ref['k'] = ref.gender + '|' + ageband(ref.age_approx)
med = ref.groupby('k')[VARS].median(); rsd = ((ref.groupby('k')[VARS].quantile(.75) - ref.groupby('k')[VARS].quantile(.25)) / 1.349).where(lambda x: x > 0)
def zrows(h):
    h = h.copy(); h['anc'] = h.wbc * h.neutrophils_pct / 100; k = h.gender + '|' + ageband(h.age_approx)
    for v in VARS: h[v] = (h[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    return h

# MDS-directed drugs and ESA from hospital orders (cached)
CACHE = cfg.PROC / 'mds_directed_drugs.csv.gz'
if not CACHE.exists():
    pat = {'hma_or_lenalidomide': 'azacitidine|decitabine|lenalidomide|luspatercept|imetelstat|vidaza|dacogen|revlimid|reblozyl',
           'esa': 'epoetin|darbepoetin|aranesp|procrit|epogen|retacrit|mircera'}
    rows = []
    for ch in pd.read_csv(RAW / 'prescriptions.csv.gz', usecols=['subject_id', 'starttime', 'drug'], chunksize=2_000_000, dtype={'drug': str}):
        d = ch.drug.fillna('').str.lower()
        for g, rx in pat.items():
            m = d.str.contains(rx, regex=True)
            if m.any(): rows.append(ch[m].assign(group=g, t=pd.to_datetime(ch.starttime[m], errors='coerce')).dropna(subset=['t']).groupby(['subject_id', 'group']).t.min().reset_index())
        log(f'prescriptions chunk read ({len(ch):,})')
    dd = pd.concat(rows).groupby(['subject_id', 'group']).t.min().reset_index() if rows else pd.DataFrame(columns=['subject_id', 'group', 't'])
    dd.to_csv(CACHE, index=False, compression='gzip')
dd = pd.read_csv(CACHE, parse_dates=['t'])
first_hma = dd[dd.group == 'hma_or_lenalidomide'].groupby('subject_id').t.min(); first_esa = dd[dd.group == 'esa'].groupby('subject_id').t.min()
ci['first_wk'] = first_wk.reindex(ci.subject_id).values; ci['first_hma'] = first_hma.reindex(ci.subject_id).values; ci['first_esa'] = first_esa.reindex(ci.subject_id).values
ci['t0'] = ci[['t1', 'first_wk', 'first_hma']].min(axis=1)
pre = ci.t1 - pd.Timedelta(days=30)
ci['strict_incident'] = ~((ci.first_wk < pre) | (ci.first_hma < pre) | (ci.first_esa < pre))
counts = dict(cases=len(ci), cases_with_cbc_before_t1=int(ci.subject_id.isin(hc.subject_id).sum()),
              workup_before_t1=int((ci.first_wk < ci.t1).sum()), hma_or_lenalidomide_before_t1=int((ci.first_hma < ci.t1).sum()),
              esa_before_t1=int((ci.first_esa < ci.t1).sum()), t0_earlier_than_t1=int((ci.t0 < ci.t1).sum()),
              median_days_t0_before_t1_when_earlier=float(((ci.t1 - ci.t0).dt.days[ci.t0 < ci.t1]).median()) if (ci.t0 < ci.t1).any() else np.nan,
              strict_incident=int(ci.strict_incident.sum()),
              strict_incident_with_cbc=int(ci.subject_id[ci.strict_incident].isin(hc.subject_id).sum()))
log('R8 counts ' + json.dumps(counts))

# ---------------- Aim 1 helpers (binned offset model, as in 40_mds_reviewer.py)
EDGES = np.arange(0, 3653 + 1, 182.625); EDGES[-1] = 3653; NBIN = len(EDGES) - 1; MID = (EDGES[:-1] + EDGES[1:]) / 2 / 365.25; BP = 60 if QUICK else 300
def binned(h): h = h.copy(); h['bin'] = np.digitize(h.days_before, EDGES) - 1; return h[(h.bin >= 0) & (h.bin < NBIN)]
def pmat(h):
    g = h.groupby(['subject_id', 'bin'])[VARS].mean(); ids = g.index.get_level_values(0).unique(); pos = pd.Series(np.arange(len(ids)), index=ids)
    X = np.full((len(ids), NBIN, len(VARS)), np.nan); X[pos.reindex(g.index.get_level_values(0)).values, g.index.get_level_values(1).values] = g.values; return X
def wmean(X, w):
    ok = ~np.isnan(X); den = np.einsum('n,nbv->bv', w, ok.astype(float)); return np.einsum('n,nbv->bv', w, np.where(ok, X, 0)) / np.where(den > 0, den, np.nan)
def fit(d, wt, mask):
    best = (np.inf, np.nan, np.nan, np.nan)
    for tau in np.arange(0.5, MID.max() + 1e-9, 0.25):
        x = np.maximum(tau - MID, 0)[mask]; yv = d[mask]; ww = wt[mask]
        if (x > 0).sum() < 2 or (x == 0).sum() < 2: continue
        A = np.c_[np.ones_like(x), x]; W = np.sqrt(ww); coef = np.linalg.lstsq(A * W[:, None], yv * W, rcond=None)[0]; sse = (ww * (yv - A @ coef) ** 2).sum()
        if sse < best[0]: best = (sse, tau, coef[0], coef[1])
    return best[1:]
def offset_model(label, zc, zm, rows, brow):
    CX, MX = pmat(binned(zc)), pmat(binned(zm)); diff = wmean(CX, np.ones(len(CX))) - wmean(MX, np.ones(len(MX)))
    rng = np.random.RandomState(7); boots = np.stack([wmean(CX, rng.poisson(1, len(CX)).astype(float)) - wmean(MX, rng.poisson(1, len(MX)).astype(float)) for _ in range(BP)])
    lo, hi, sd = np.nanpercentile(boots, 2.5, 0), np.nanpercentile(boots, 97.5, 0), np.nanstd(boots, 0); ncase = (~np.isnan(CX)).sum(0)
    for j, v in enumerate(VARS):
        mask = (ncase[:, j] >= 30) & ~np.isnan(diff[:, j]) & (sd[:, j] > 0); wt = np.where(mask, 1 / np.where(sd[:, j] > 0, sd[:, j], 1) ** 2, 0)
        tau, a0, b0 = fit(diff[:, j], wt, mask); bt = np.array([fit(boots[b, :, j], wt, mask & ~np.isnan(boots[b, :, j])) for b in range(BP)], float)
        far = (MID >= 5) & (ncase[:, j] >= 10)
        rows.append(dict(analysis=label, var=v, n_cases=len(CX), n_controls=len(MX), bins_used=int(mask.sum()), diff_0_6m=diff[0, j], lo_0_6m=lo[0, j], hi_0_6m=hi[0, j],
                         mean_diff_5_10y=np.nanmean(diff[far, j]) if far.any() else np.nan, cases_5_10y=int((~np.isnan(CX[:, MID >= 5, j])).any(1).sum()),
                         offset=a0, offset_lo=np.nanpercentile(bt[:, 1], 2.5), offset_hi=np.nanpercentile(bt[:, 1], 97.5), tau=tau,
                         tau_lo=np.nanpercentile(bt[:, 0], 2.5), tau_hi=np.nanpercentile(bt[:, 0], 97.5)))
        for i in range(NBIN): brow.append(dict(analysis=label, var=v, years_before_mid=MID[i], n_cases=int(ncase[i, j]), n_controls=int((~np.isnan(MX[:, i, j])).sum()), diff=diff[i, j], lo=lo[i, j], hi=hi[i, j]))
    log(f'Aim 1 {label}: {len(CX)} cases, {len(MX)} controls')

ZC, ZM = zrows(hc), zrows(hm)

@section
def r8_diagnosis_date():
    rows, brow = [], []
    offset_model('all cases, anchored at t1 (reference)', ZC, ZM, rows, brow)
    # anchored at earliest suspicion t0
    a = ZC.merge(ci[['subject_id', 't0']], on='subject_id'); a = a[a.t < a.t0].copy(); a['days_before'] = (a.t0 - a.t).dt.total_seconds() / 86400
    offset_model('R8a anchored at earliest suspicion t0', a, ZM, rows, brow)
    s = ZC[ZC.subject_id.isin(set(ci.subject_id[ci.strict_incident]))]
    offset_model('R8b strictly incident cases (no work-up, MDS drug or ESA before t1-30d)', s, ZM, rows, brow)
    pd.DataFrame(rows).to_csv(OUT / 'revision_r8_onset.csv', index=False); pd.DataFrame(brow).to_csv(OUT / 'revision_r8_bins.csv', index=False)
    pd.Series(counts).to_csv(OUT / 'revision_r8_counts.csv')
    log('R8\n' + pd.DataFrame(rows)[['analysis', 'var', 'n_cases', 'mean_diff_5_10y', 'cases_5_10y', 'offset', 'offset_lo', 'offset_hi', 'tau']].round(2).to_string(index=False))

# ---------------- R9 mixed model
KN = [1.0, 2.0, 4.0, 6.0]
def basis(x): return np.column_stack([x] + [np.maximum(x - k, 0) for k in KN])
XS = np.array([0.25, 0.5, 1, 2, 3, 4, 5, 6, 8])
def re_fit(y, X, g, G, tv):
    """random-intercept GLS (Swamy-Arora); X columns: all regressors incl. intercept; tv = mask of time-varying columns.
    Returns RE coefficients and within (fixed-effects) coefficients for the time-varying columns."""
    T = np.bincount(g, minlength=G).astype(float); keep = T > 0
    gm = lambda a: np.bincount(g, weights=a, minlength=G) / np.where(T > 0, T, 1)
    Xm = np.column_stack([gm(X[:, j]) for j in range(X.shape[1])]); ym = gm(y)
    Xw = X[:, tv] - Xm[g][:, tv]; yw = y - ym[g]
    bw = np.linalg.lstsq(Xw, yw, rcond=None)[0]; ew = yw - Xw @ bw; s2e = ew @ ew / max(len(y) - keep.sum() - tv.sum(), 1)
    bb = np.linalg.lstsq(Xm[keep], ym[keep], rcond=None)[0]; eb = ym[keep] - Xm[keep] @ bb; s2b = eb @ eb / max(keep.sum() - X.shape[1], 1)
    s2u = max(s2b - s2e * np.mean(1 / T[keep]), 0.0)
    th = 1 - np.sqrt(s2e / (s2e + T * s2u + 1e-12)); Xs = X - th[g][:, None] * Xm[g]; ys = y - th[g] * ym[g]
    return np.linalg.lstsq(Xs, ys, rcond=None)[0], bw, s2e, s2u

@section
def r9_mixed_model():
    zc = ZC[(ZC.days_before > 0) & (ZC.days_before <= 3653)].assign(case=1.0); zm = ZM[(ZM.days_before > 0) & (ZM.days_before <= 3653)].assign(case=0.0)
    D = pd.concat([zc, zm], ignore_index=True); D['x'] = D.days_before / 365.25; D['inp'] = (D.setting == 'inpatient').astype(float)
    D = D.sort_values('subject_id').reset_index(drop=True); ids = D.subject_id.values; uid, g = np.unique(ids, return_inverse=True); G = len(uid)
    start = np.searchsorted(ids, uid); end = np.r_[start[1:], len(ids)]; is_case = D.groupby('subject_id').case.first().reindex(uid).values == 1
    has_far = D.groupby('subject_id').x.max().reindex(uid).values >= 5; has_near = D.groupby('subject_id').x.min().reindex(uid).values <= 2
    B = basis(D.x.values); C = D.case.values[:, None]
    X = np.c_[np.ones(len(D)), D.case.values, B, B * C, D.inp.values]; tv = np.r_[False, False, [True] * B.shape[1], [True] * B.shape[1], True]
    nb = B.shape[1]; bx = basis(XS); b7 = basis(np.array([7.0]))[0]; b05 = basis(np.array([0.5]))[0]
    def effects(beta, bw):
        gam = beta[2 + nb:2 + 2 * nb]; diff = beta[1] + bx @ gam
        gw = bw[nb:2 * nb]  # within coefficients: order of tv columns = B, B*C, inp
        return diff, (b05 - b7) @ gam, (b05 - b7) @ gw
    rows = []; boot_rng = np.random.RandomState(11); VV = ['rbc', 'mcv', 'rdw', 'hemoglobin', 'platelet', 'anc', 'wbc', 'mch']
    for subset, pmask in [('all patients', np.ones(G, bool)), ('patients with CBCs both >= 5 y and <= 2 y before anchor', has_far & has_near)]:
        if (is_case & pmask).sum() < 20: continue
        est = {}
        for v in VV:
            ok = ~np.isnan(D[v].values) & pmask[g]
            beta, bw, s2e, s2u = re_fit(D[v].values[ok], X[ok], g[ok], G, tv); est[v] = (effects(beta, bw), s2e, s2u, ok)
        pc = np.where(is_case & pmask)[0]; pk = np.where(~is_case & pmask)[0]; bs = {v: [] for v in VV}
        for _ in range(BOOT):
            ch = np.r_[boot_rng.choice(pc, len(pc)), boot_rng.choice(pk, len(pk))]; lens = end[ch] - start[ch]
            idx = np.concatenate([np.arange(start[u], end[u]) for u in ch]); newg = np.repeat(np.arange(len(ch)), lens); Xb = X[idx]
            for v in VV:
                yb = D[v].values[idx]; m = ~np.isnan(yb)
                try:
                    b1, w1, _, _ = re_fit(yb[m], Xb[m], newg[m], len(ch), tv); e = effects(b1, w1); bs[v].append(np.r_[e[0], e[1], e[2]])
                except Exception: pass
        for v in VV:
            (diff, chg_re, chg_fe), s2e, s2u, ok = est[v]; B_ = np.array(bs[v]); lo, hi = np.nanpercentile(B_, 2.5, 0), np.nanpercentile(B_, 97.5, 0)
            gs = g[ok]; cs = D.case.values[ok]
            r = dict(subset=subset, var=v, cases=int(len(np.unique(gs[cs == 1]))), controls=int(len(np.unique(gs[cs == 0]))), cbcs=int(ok.sum()), sd_within=np.sqrt(s2e), sd_between=np.sqrt(s2u))
            for i, xv in enumerate(XS): r[f'diff_{xv:g}y'] = diff[i]; r[f'diff_{xv:g}y_lo'] = lo[i]; r[f'diff_{xv:g}y_hi'] = hi[i]
            k = len(XS); r.update(change_7y_to_0p5y_re=chg_re, change_re_lo=lo[k], change_re_hi=hi[k], change_7y_to_0p5y_within=chg_fe, change_within_lo=lo[k + 1], change_within_hi=hi[k + 1])
            rows.append(r); log(f'R9 {subset} {v}: diff at 8 y {diff[-1]:.2f} ({lo[k-1]:.2f} to {hi[k-1]:.2f}); within-person change 7 y -> 0.5 y {chg_fe:.2f} ({lo[k+1]:.2f} to {hi[k+1]:.2f})')
    pd.DataFrame(rows).to_csv(OUT / 'revision_r9_mixed_model.csv', index=False)

# ---------------- R10/R11 Aim 2
SETS = {'AGE': DEM, 'SNAP': IDX + DEM, 'SET': [f'set_{v}' for v in IDX] + DEM, 'FULL': IDX + DEM + [f'drift_{v}' for v in IDX] + [f'slope_{v}' for v in CORE]}
def build(idx, hist, min_gap=1.0):
    """idx: one row per patient (subject_id, index_time, label, IDX, DEM, gender, n_flag_core); hist: subject_id, t, IDX"""
    Hh = hist.merge(idx[['subject_id', 'index_time']], on='subject_id'); Hh['gap'] = (Hh.index_time - Hh.t).dt.total_seconds() / 86400 / 365.25
    base = Hh[(Hh.gap >= min_gap) & (Hh.gap <= 10)]; nb = base.groupby('subject_id').size(); keep = nb[nb >= 2].index
    d = idx[idx.subject_id.isin(keep)].copy().set_index('subject_id'); base = base[base.subject_id.isin(keep)]
    sp = base.groupby('subject_id')[IDX].median(); cnt = base.groupby('subject_id')[IDX].count(); var = base.groupby('subject_id')[IDX].var(ddof=1)
    wsd = np.sqrt(var.where(cnt >= 3).mean()); k = d.gender + '|' + ageband(d.age_approx)
    for v in IDX:
        d[f'set_{v}'] = sp[v]; d[f'drift_{v}'] = (d[v] - sp[v]) / wsd[v]
        b = base[['subject_id', 'gap', v]].dropna(); b = pd.concat([b, d[[v]].dropna().reset_index().assign(gap=0.0)], ignore_index=True); b['x'] = -b.gap; gg = b.groupby('subject_id')
        n = gg.size(); sx = gg.x.sum(); sy = gg[v].sum(); sxx = (b.x * b.x).groupby(b.subject_id).sum(); sxy = (b.x * b[v]).groupby(b.subject_id).sum(); den = n * sxx - sx * sx
        d[f'slope_{v}'] = ((n * sxy - sx * sy) / den.where(den > 1e-9)).where(n >= 3)
    for v in CORE: d[f'pop_{v}'] = (d[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    d['personal_dev'] = np.nansum(np.abs(d[[f'drift_{v}' for v in CORE]].values), axis=1)
    d['population_dev'] = np.nansum(np.abs(d[[f'pop_{v}' for v in CORE]].values), axis=1)
    return d.reset_index()
def cv(d, cols, reps):
    X = d[cols].astype(float); y = d.label.values; o = np.zeros((reps, len(y)))
    for j, (tr, te) in enumerate(RepeatedStratifiedKFold(n_splits=5, n_repeats=reps, random_state=SEED).split(X, y)):
        o[j // 5, te] = model().fit(X.iloc[tr], y[tr]).predict_proba(X.iloc[te])[:, 1]
    return o.mean(0)
ICOLS = ['subject_id', 'index_time', 'label', 'gender', 'n_flag_core'] + IDX + DEM
ctrl_idx = p[p.label == 0][ICOLS]
HIST = pd.concat([hc[['subject_id', 't'] + IDX], hcc[['subject_id', 't'] + IDX]], ignore_index=True)
def matched_subset(d, k=10, seed=SEED):
    s = d.gender + '_' + (np.floor(d.age_approx / 5) * 5).astype(int).astype(str); d = d.assign(_s=s.values); keep = list(d.index[d.label == 1])
    rng = np.random.RandomState(seed)
    for st, n in d[d.label == 1]._s.value_counts().items():
        pool = d.index[(d.label == 0) & (d._s == st)]; keep += list(rng.choice(pool, min(len(pool), k * n), replace=False)) if len(pool) else []
    return d.loc[keep]
A2, A2p = [], []
def evaluate(tag, d, oof):
    y = d.label.values
    for m, s in oof.items():
        lo, hi = boot_ci(y, s); A2.append(dict(analysis=tag, model=m, n=len(y), cases=int(y.sum()), auroc=auc(y, s), lo=lo, hi=hi, ap=average_precision_score(y, s)))
    for nm, col in [('population deviation score', 'population_dev'), ('personal deviation score', 'personal_dev')]:
        s = d[col].values; lo, hi = boot_ci(y, s); A2.append(dict(analysis=tag, model=nm, n=len(y), cases=int(y.sum()), auroc=auc(y, s), lo=lo, hi=hi, ap=average_precision_score(y, s)))
    for a, b in [('FULL', 'SNAP'), ('SET', 'AGE'), ('SNAP', 'AGE')]:
        if a in oof and b in oof:
            x, lo, hi = paired(y, oof[a], oof[b]); A2p.append(dict(analysis=tag, comparison=f'{a} minus {b}', auroc_diff=x, lo=lo, hi=hi))
    x, lo, hi = paired(y, d.personal_dev.values, d.population_dev.values); A2p.append(dict(analysis=tag, comparison='personal minus population deviation score', auroc_diff=x, lo=lo, hi=hi))

@section
def r10_r11_aim2():
    # primary horizon (index 30-365 d) for the age analyses
    prim = build(p[ICOLS], HIST); oofp = {m: cv(prim, c, REPS) for m, c in SETS.items()}; y = prim.label.values
    log(f'R11 primary Aim 2 set: {len(prim):,} patients, {y.sum()} cases')
    evaluate('primary horizon (30-365 d), all', prim, oofp)
    mm = matched_subset(prim); pos = prim.index.get_indexer(mm.index)
    evaluate('primary horizon, 1:10 sex x 5-y age matched', prim.iloc[pos].reset_index(drop=True), {m: s[pos] for m, s in oofp.items()})
    for lo_a, hi_a, nm in [(0, 70, '<70'), (70, 80, '70-79'), (80, 200, '>=80')]:
        mk = ((prim.age_approx >= lo_a) & (prim.age_approx < hi_a)).values
        if prim.label.values[mk].sum() >= 10:
            for m in ['SNAP', 'SET', 'FULL', 'AGE']:
                s = oofp[m][mk]; yy = y[mk]; l, h = boot_ci(yy, s); A2.append(dict(analysis=f'primary horizon, age {nm}', model=m, n=int(mk.sum()), cases=int(yy.sum()), auroc=auc(yy, s), lo=l, hi=h, ap=average_precision_score(yy, s)))
    # earlier horizons
    for lo_d, hi_d, nm in [(365, 3 * 365, 'index 1-3 y before t1'), (3 * 365, 5 * 365, 'index 3-5 y before t1')]:
        cand = hc[(hc.days_before >= lo_d) & (hc.days_before < hi_d)].sort_values('days_before').drop_duplicates('subject_id')
        ci_idx = cand.assign(index_time=cand.t, label=1)[ICOLS]
        d = build(pd.concat([ci_idx, ctrl_idx], ignore_index=True), HIST); yy = d.label.values
        log(f'R10 {nm}: {len(d):,} patients, {yy.sum()} cases (cases with an index CBC in window: {len(ci_idx)})')
        if yy.sum() < 15: continue
        oof = {m: cv(d, c, REPS) for m, c in SETS.items()}; evaluate(f'{nm}, all', d, oof)
        mm = matched_subset(d); pos = d.index.get_indexer(mm.index); evaluate(f'{nm}, 1:10 sex x 5-y age matched', d.iloc[pos].reset_index(drop=True), {m: s[pos] for m, s in oof.items()})
        nf = (d.n_flag_core.fillna(0) == 0).values
        if yy[nf].sum() >= 10: evaluate(f'{nm}, index CBC with no population flag', d[nf].reset_index(drop=True), {m: s[nf] for m, s in oof.items()})
        else: A2.append(dict(analysis=f'{nm}, index CBC with no population flag', model='too few cases', n=int(nf.sum()), cases=int(yy[nf].sum())))
    pd.DataFrame(A2).to_csv(OUT / 'revision_r10_r11_aim2_models.csv', index=False); pd.DataFrame(A2p).to_csv(OUT / 'revision_r10_r11_aim2_paired.csv', index=False)
    log('R10/R11\n' + pd.DataFrame(A2).round(3).to_string(index=False)); log(pd.DataFrame(A2p).round(3).to_string(index=False))

# ---------------- Aim 3 scoring (same fold models as 40_mds_reviewer.py)
F = IDX + DEM; yv = p.label.values; fold = np.zeros(len(p), int); FM = []; oofs = np.zeros(len(p))
for k, (tr, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=20260927).split(p, yv)):
    m = model().fit(p.loc[tr, F].astype(float), yv[tr]); FM.append(m); fold[te] = k; oofs[te] = m.predict_proba(p.loc[te, F].astype(float))[:, 1]
fold_of = pd.Series(fold, index=p.subject_id); THR = {'spec95': np.quantile(oofs[yv == 0], .95), 'spec99': np.quantile(oofs[yv == 0], .99)}
def score(h):
    X = h[F].astype(float); f = fold_of.reindex(h.subject_id).values; s = np.full(len(h), np.nan); known = ~np.isnan(f)
    for k, mdl in enumerate(FM):
        ix = known & (f == k)
        if ix.any(): s[ix] = mdl.predict_proba(X[ix])[:, 1]
    if (~known).any(): s[~known] = np.mean([mdl.predict_proba(X[~known])[:, 1] for mdl in FM], 0)
    return s
hc['score'] = score(hc); hcc['score'] = score(hcc); log('Aim 3 scores ready')
cases3 = ci[ci.subject_id.isin(set(p.subject_id[p.label == 1]))].set_index('subject_id')
hc3 = hc[hc.subject_id.isin(cases3.index) & (hc.days_before >= 30)].copy()
ctrl_hist = hcc  # all CBCs of cohort controls (as in the main burden analysis)

@section
def r11_aim3_age():
    rows = []; y = yv
    for nm, d in [('all', p), ('1:10 sex x 5-y age matched', None)]:
        if d is None:
            mm = matched_subset(p.assign(age_approx=p.age_approx)); pos = p.index.get_indexer(mm.index)
        else: pos = np.arange(len(p))
        l, h = boot_ci(y[pos], oofs[pos]); rows.append(dict(analysis=f'Aim 3 index-CBC model, {nm}', n=len(pos), cases=int(y[pos].sum()), auroc=auc(y[pos], oofs[pos]), lo=l, hi=h))
    for lo_a, hi_a, nm in [(0, 70, '<70'), (70, 80, '70-79'), (80, 200, '>=80')]:
        mk = ((p.age_approx >= lo_a) & (p.age_approx < hi_a)).values
        l, h = boot_ci(y[mk], oofs[mk]); rows.append(dict(analysis=f'Aim 3 index-CBC model, age {nm}', n=int(mk.sum()), cases=int(y[mk].sum()), auroc=auc(y[mk], oofs[mk]), lo=l, hi=h))
    pd.DataFrame(rows).to_csv(OUT / 'revision_r11_aim3_age.csv', index=False); log('R11 Aim 3\n' + pd.DataFrame(rows).round(3).to_string(index=False))

@section
def r12_testing_intensity():
    rows = []; rng = np.random.RandomState(5)
    for tn, thr in THR.items():
        # cases: sensitivity by number of eligible CBCs (>= 30 d before t1)
        n_c = hc3.groupby('subject_id').size(); hit_c = hc3[hc3.score > thr].groupby('subject_id').size().reindex(n_c.index).fillna(0) > 0
        # controls: all CBCs (as in the main burden); ever alerted by number of CBCs
        n_k = ctrl_hist.groupby('subject_id').size(); hit_k = ctrl_hist[ctrl_hist.score > thr].groupby('subject_id').size().reindex(n_k.index).fillna(0) > 0
        for lo_n, hi_n, nm in [(1, 1, '1'), (2, 3, '2-3'), (4, 9, '4-9'), (10, 10 ** 6, '>=10')]:
            mc = (n_c >= lo_n) & (n_c <= hi_n); mk = (n_k >= lo_n) & (n_k <= hi_n)
            rows.append(dict(threshold=tn, measure='by number of CBCs', cbcs=nm, cases=int(mc.sum()), cases_alerted_pct=100 * hit_c[mc].mean() if mc.any() else np.nan,
                             controls=int(mk.sum()), controls_alerted_pct=100 * hit_k[mk].mean() if mk.any() else np.nan))
        # per-CBC alert rate
        rows.append(dict(threshold=tn, measure='per-CBC alert rate', cases_alerted_pct=100 * (hc3.score > thr).mean(), controls_alerted_pct=100 * (ctrl_hist.score > thr).mean()))
        # thinned case histories: keep at most k randomly chosen eligible CBCs per case
        for kmax in [1, 2]:
            sens = []
            for _ in range(100):
                th = hc3.sample(frac=1, random_state=rng.randint(1e9)).groupby('subject_id').head(kmax)
                first = th[th.score > thr].groupby('subject_id').size(); sens.append(100 * len(first) / len(cases3))
            rows.append(dict(threshold=tn, measure=f'cases thinned to at most {kmax} CBC(s), alerted >= 30 d before t1', cases=len(cases3), cases_alerted_pct=np.mean(sens),
                             cases_alerted_lo=np.percentile(sens, 2.5), cases_alerted_hi=np.percentile(sens, 97.5)))
        # count-standardised: weight case sensitivity by the control distribution of CBC counts
        bucket = lambda n: pd.cut(n, [0, 1, 3, 9, 10 ** 6], labels=['1', '2-3', '4-9', '>=10'])
        wc = bucket(n_k).value_counts(normalize=True); sc = hit_c.groupby(bucket(n_c)).mean()
        rows.append(dict(threshold=tn, measure='case sensitivity standardised to the control CBC-count distribution', cases_alerted_pct=100 * float((sc.reindex(wc.index) * wc).sum())))
    pd.DataFrame(rows).to_csv(OUT / 'revision_r12_testing_intensity.csv', index=False); log('R12\n' + pd.DataFrame(rows).round(1).to_string(index=False))

def rules(h):
    male = h.gender_bin.values == 1; anc = h.wbc * h.neutrophils_pct / 100
    anemia = (h.hemoglobin < np.where(male, 13, 12)); macro = h.mcv > 100; rdwh = h.rdw > 15; thromb = h.platelet < 150; neut = anc < 1.8
    cyto = anemia.astype(int) + thromb.astype(int) + neut.fillna(False).astype(int)
    return {'Rule A: macrocytic anaemia (MCV > 100 fL and anaemia)': (macro & anemia).values,
            'Rule B: MCV > 100 fL and RDW > 15%': (macro & rdwh).values,
            'Rule C: MCV > 100 fL or RDW > 15%, with at least one cytopenia': ((macro | rdwh) & (cyto >= 1)).values,
            'Rule D: at least two cytopenias': (cyto >= 2).values}
@section
def r13_simple_rules():
    rows = []; ri = rules(p); y = yv
    for nm, hit in ri.items():
        sens = hit[y == 1].mean(); spec = 1 - hit[y == 0].mean(); thr = np.quantile(oofs[y == 0], min(spec, 0.9999)); msens = (oofs[y == 1] > thr).mean()
        rc = rules(hc3); rk = rules(ctrl_hist)
        c_hit = pd.Series(rc[nm], index=hc3.index).groupby(hc3.subject_id).any(); c_far = pd.Series(rc[nm] & (hc3.days_before >= 365).values, index=hc3.index).groupby(hc3.subject_id).any()
        k_hit = pd.Series(rk[nm], index=ctrl_hist.index).groupby(ctrl_hist.subject_id).any()
        rows.append(dict(rule=nm, index_sensitivity=100 * sens, index_specificity=100 * spec, model_sensitivity_at_same_specificity=100 * msens,
                         alert_cases_ge30d_pct=100 * c_hit.reindex(cases3.index).fillna(False).mean(), alert_cases_ge1y_pct=100 * c_far.reindex(cases3.index).fillna(False).mean(),
                         controls_ever_alerted_pct=100 * k_hit.mean(), alerted_controls_per_case=k_hit.sum() / max(c_hit.reindex(cases3.index).fillna(False).sum(), 1)))
    for tn, thr in THR.items():
        c_hit = hc3[hc3.score > thr].groupby('subject_id').size().reindex(cases3.index).fillna(0) > 0
        c_far = hc3[(hc3.score > thr) & (hc3.days_before >= 365)].groupby('subject_id').size().reindex(cases3.index).fillna(0) > 0
        k_hit = ctrl_hist[ctrl_hist.score > thr].groupby('subject_id').size().reindex(ctrl_hist.subject_id.unique()).fillna(0) > 0
        rows.append(dict(rule=f'SNAP model, {tn}', index_sensitivity=100 * (oofs[y == 1] > thr).mean(), index_specificity=100 * (oofs[y == 0] <= thr).mean(),
                         alert_cases_ge30d_pct=100 * c_hit.mean(), alert_cases_ge1y_pct=100 * c_far.mean(), controls_ever_alerted_pct=100 * k_hit.mean(), alerted_controls_per_case=k_hit.sum() / max(c_hit.sum(), 1)))
    pd.DataFrame(rows).to_csv(OUT / 'revision_r13_simple_rules.csv', index=False); log('R13\n' + pd.DataFrame(rows).round(1).to_string(index=False))

@section
def r14_outcomes():
    pt = pd.read_csv(RAW / 'patients.csv.gz', usecols=['subject_id', 'dod'], parse_dates=['dod']).set_index('subject_id')
    adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime', 'dischtime'], parse_dates=['admittime', 'dischtime'])
    dx = pd.read_csv(cfg.MIMIC_FILES['diagnoses_icd'], dtype={'icd_code': str}, usecols=['subject_id', 'hadm_id', 'icd_code', 'icd_version'])
    code = dx.icd_code.str.upper().str.replace('.', '', regex=False)
    aml = ((dx.icd_version == 10) & code.str[:4].isin(['C920', 'C92A', 'C924', 'C925', 'C926', 'C930', 'C940', 'C942'])) | ((dx.icd_version == 9) & code.str[:4].isin(['2050', '2060', '2070', '2072']))
    first_aml = dx[aml].merge(adm, on=['subject_id', 'hadm_id']).groupby('subject_id').admittime.min()
    last_seen = adm.groupby('subject_id').dischtime.max()
    d = cases3.copy(); d['dod'] = pt.dod.reindex(d.index); d['aml'] = first_aml.reindex(d.index); d['last'] = last_seen.reindex(d.index)
    thr = THR['spec99']; fa = hc3[hc3.score > thr].groupby('subject_id').t.min(); d['lead'] = (d.t1 - fa.reindex(d.index)).dt.days
    d['grp'] = np.where(d.lead >= 365, 'alert >= 1 y before t1', np.where(d.lead >= 30, 'alert 30-364 d before t1', 'no alert >= 30 d before t1'))
    d['wk_before'] = first_wk.reindex(d.index) < d.t1
    d['death_1y'] = (d.dod.notna() & ((d.dod - d.t1).dt.days <= 365)); d['aml_2y'] = d.aml.notna() & ((d.aml - d.t1).dt.days.between(0, 730))
    d['followed_1y'] = ((d['last'] - d.t1).dt.days >= 365) | d.death_1y
    rows = []
    for gname, sub in [('all cohort cases', d)] + [(k, v) for k, v in d.groupby('grp')] + [('work-up before t1', d[d.wk_before]), ('no work-up before t1', d[~d.wk_before])]:
        k1 = int(sub.death_1y.sum()); k2 = int(sub.aml_2y.sum()); n = len(sub)
        rows.append(dict(group=gname, cases=n, death_1y=k1, death_1y_pct=100 * k1 / n if n else np.nan, death_1y_lo=100 * wilson(k1, n)[0], death_1y_hi=100 * wilson(k1, n)[1],
                         aml_2y=k2, aml_2y_pct=100 * k2 / n if n else np.nan, aml_2y_lo=100 * wilson(k2, n)[0], aml_2y_hi=100 * wilson(k2, n)[1],
                         median_age=sub.age_t1.median()))
    R = pd.DataFrame(rows); R.to_csv(OUT / 'revision_r14_outcomes.csv', index=False); log('R14\n' + R.round(1).to_string(index=False))
    # lead time relative to earliest suspicion t0
    t0 = ci.set_index('subject_id').t0.reindex(d.index); lead0 = (t0 - fa.reindex(d.index)).dt.days
    extra = dict(cases=len(d), alert_ge30d_before_t0_pct=100 * (lead0 >= 30).mean(), alert_ge1y_before_t0_pct=100 * (lead0 >= 365).mean(), median_lead_before_t0_days=float(lead0[lead0 >= 30].median()))
    pd.Series(extra).to_csv(OUT / 'revision_r8_alert_vs_t0.csv'); log('alert relative to t0 ' + json.dumps(extra))

log('FAILED SECTIONS: ' + (', '.join(FAILED) if FAILED else 'none'))
log('REVISION_DONE' if not FAILED else 'REVISION_DONE_WITH_FAILURES')
