"""MDS reviewer analysis R7 (added 4 Oct 2026; post hoc): drug exposure as a confounder of the red-cell offset.
Reads MIMIC-IV hosp/prescriptions.csv.gz (hospital medication orders; out-of-hospital prescriptions are not captured)
and records, per patient, the first order of
  - macrocytic drugs: methotrexate, azathioprine, mercaptopurine, hydroxyurea, zidovudine, leflunomide, mycophenolate,
    valproate, phenytoin, phenobarbital, primidone;
  - cytotoxic chemotherapy (alkylators, platinum, anthracyclines, topoisomerase inhibitors, antimetabolites, taxanes,
    vinca alkaloids and others; hypomethylating agents are excluded because they treat MDS itself).
Topical products are ignored.
Output: data/processed/mds_covariates_drugs.csv.gz = mds_covariates + first_drug_macrocytic + first_drug_cytotoxic,
with first_any_confounder recomputed to include both (codes-only version kept as first_any_confounder_codes).
Then run: python src/40_mds_reviewer.py --drugs   (writes results/mds/v2/reviewer_*_R7.csv)"""
import sys, json, time
from pathlib import Path
import pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
OUT = cfg.RESULTS / 'mds' / 'v2'; OUT.mkdir(parents=True, exist_ok=True)
t0 = time.time(); log = lambda m: print(f'[{time.time()-t0:7.1f}s] {m}', flush=True)
RX = Path(cfg.MIMIC_FILES['admissions']).parent / 'prescriptions.csv.gz'
if not RX.exists():
    sys.exit(f'prescriptions file not found: {RX}\nDownload hosp/prescriptions.csv.gz (MIMIC-IV v3.1) from PhysioNet and put it there.')

GROUPS = {
    'drug_macrocytic': ['methotrexate', 'azathioprine', 'mercaptopurine', 'hydroxyurea', 'zidovudine', 'leflunomide',
                        'mycophenol', 'valpro', 'divalproex', 'phenytoin', 'phenobarbital', 'primidone'],
    'drug_cytotoxic': ['cyclophosphamide', 'chlorambucil', 'melphalan', 'busulfan', 'bendamustine', 'carmustine', 'lomustine',
                       'temozolomide', 'dacarbazine', 'procarbazine', 'ifosfamide', 'thiotepa', 'cisplatin', 'carboplatin',
                       'oxaliplatin', 'doxorubicin', 'daunorubicin', 'epirubicin', 'idarubicin', 'mitoxantrone', 'etoposide',
                       'irinotecan', 'topotecan', 'fluorouracil', 'capecitabine', 'gemcitabine', 'cytarabine', 'fludarabine',
                       'cladribine', 'pemetrexed', 'paclitaxel', 'docetaxel', 'vincristine', 'vinblastine', 'vinorelbine',
                       'bleomycin', 'mitomycin'],
}
TOPICAL = r'cream|ointment|topical|gel|lotion|ophth|eye drop'
first = {g: pd.Series(dtype='datetime64[ns]') for g in GROUPS}; n_rows = 0; hits = {g: 0 for g in GROUPS}; names = {g: {} for g in GROUPS}
for ch in pd.read_csv(RX, usecols=['subject_id', 'starttime', 'drug', 'route'], chunksize=2_000_000, dtype={'drug': str, 'route': str}):
    n_rows += len(ch); d = ch.drug.fillna('').str.lower()
    keep = ~d.str.contains(TOPICAL, regex=True) & ~ch.route.fillna('').str.upper().isin(['TP', 'TOPICAL', 'OU', 'OD', 'OS'])
    for g, words in GROUPS.items():
        m = keep & d.str.contains('|'.join(words), regex=True)
        if m.any():
            sub = ch[m].assign(t=pd.to_datetime(ch.starttime[m], errors='coerce')).dropna(subset=['t'])
            hits[g] += len(sub)
            for k, v in sub.drug.str.lower().value_counts().head(40).items(): names[g][k] = names[g].get(k, 0) + int(v)
            first[g] = pd.concat([first[g], sub.groupby('subject_id').t.min()]).groupby(level=0).min()
    log(f'{n_rows:,} prescription rows read')

cov = pd.read_csv(cfg.PROC / 'mds_covariates.csv.gz').set_index('subject_id')
for c in cov.columns:
    if c.startswith('first_'): cov[c] = pd.to_datetime(cov[c])
cov = cov.join(pd.DataFrame({f'first_{g}': s for g, s in first.items()}), how='outer')
cov['first_any_confounder_codes'] = cov['first_any_confounder']
cov['first_any_confounder'] = cov[['first_any_confounder_codes'] + [f'first_{g}' for g in GROUPS]].min(axis=1)
cov.index.name = 'subject_id'
cov.reset_index().to_csv(cfg.PROC / 'mds_covariates_drugs.csv.gz', index=False, compression='gzip')
summary = dict(prescription_rows=n_rows, **{f'{g}_orders': hits[g] for g in GROUPS},
               **{f'{g}_patients': int(first[g].size) for g in GROUPS},
               any_confounder_codes_patients=int(cov.first_any_confounder_codes.notna().sum()),
               any_confounder_codes_or_drugs_patients=int(cov.first_any_confounder.notna().sum()),
               top_drug_names={g: dict(sorted(names[g].items(), key=lambda kv: -kv[1])[:25]) for g in GROUPS})
(OUT / 'reviewer_drug_counts_R7.json').write_text(json.dumps(summary, indent=2)); log(json.dumps(summary, indent=2)); log('DRUGS_DONE')
