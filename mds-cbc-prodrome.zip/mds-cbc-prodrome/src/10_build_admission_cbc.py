"""Build one index-CBC row per ADULT HOSPITAL ADMISSION for the pre-diagnostic study.

Specimen rules identical to the first study (src/audit_cbc.py): CBC drawn 6 h
before to 24 h after admission, age >= 18, exact duplicates collapsed,
conflicting repeats in a specimen dropped, >= 6 of the 9 core parameters,
earliest eligible specimen per admission, whole specimen rows only.
Physiologically impossible values set to missing as in clean_leukemia.py.

Source: data/processed/cbc_all_long.csv.gz if present (made by
09_extract_all_cbc.py; also carries the laboratory abnormal flag, which is
pivoted into <test>_flag columns and n_flag_core), else the original
admission-linked cbc_long.csv.gz (no flags).

Usage: python src/10_build_admission_cbc.py [--src FILE] [--out FILE] [--tmp DIR]
Set TIME_BUDGET_S to make stage 1 stop and resume across runs (sandbox use).
"""
import argparse, os, sys, time, pickle
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import config as cfg

ap = argparse.ArgumentParser()
default_src = cfg.PROC / 'cbc_all_long.csv.gz'
if not default_src.exists():
    default_src = cfg.PROC / 'cbc_long.csv.gz'
ap.add_argument('--src', default=str(default_src))
ap.add_argument('--out', default=str(cfg.PROC / 'admission_cbc_all.csv.gz'))
ap.add_argument('--tmp', default=None)
args = ap.parse_args()
SRC = Path(args.src); OUT = Path(args.out)
TMP = Path(args.tmp) if args.tmp else Path.home() / 'prediag_tmp' / ('adm_' + SRC.name.split('.')[0])
TMP.mkdir(parents=True, exist_ok=True)
BUDGET = float(os.environ.get('TIME_BUDGET_S', 'inf'))
t0 = time.time()
print(f'source: {SRC}', flush=True)

adm = pd.read_csv(cfg.MIMIC_FILES['admissions'], usecols=['subject_id', 'hadm_id', 'admittime', 'dischtime'],
                  parse_dates=['admittime', 'dischtime'])
pat = pd.read_csv(cfg.MIMIC_FILES['patients'], usecols=['subject_id', 'gender', 'anchor_age', 'anchor_year', 'anchor_year_group'])
adm = adm.merge(pat, on='subject_id', validate='many_to_one')
adm['age_approx'] = adm.anchor_age + adm.admittime.dt.year - adm.anchor_year

header = pd.read_csv(SRC, nrows=0).columns
has_flag = 'flag' in header
use = ['subject_id', 'hadm_id', 'specimen_id', 'charttime', 'valuenum', 'test'] + (['flag'] if has_flag else [])

if not (TMP / 'STAGE1_DONE').exists():
    for i, chunk in enumerate(pd.read_csv(SRC, chunksize=1_000_000, usecols=use, dtype={'flag': str} if has_flag else None)):
        f = TMP / f'chunk_{i:04d}.pkl'
        if f.exists():
            continue
        if time.time() - t0 > BUDGET:
            print('NOT_DONE (time budget); rerun to continue'); sys.exit(0)
        chunk = chunk[chunk.hadm_id.notna()].copy()
        chunk['charttime'] = pd.to_datetime(chunk.charttime, errors='coerce')
        linked = chunk.merge(adm[['hadm_id', 'admittime', 'age_approx']], on='hadm_id', how='inner')
        hours = (linked.charttime - linked.admittime).dt.total_seconds() / 3600
        keep = linked.loc[(linked.age_approx >= 18) & hours.between(-6, 24), use]
        pickle.dump(keep, open(f, 'wb'))
        print(f'chunk {i}: kept {len(keep):,} ({time.time()-t0:.0f}s)', flush=True)
    (TMP / 'STAGE1_DONE').write_text('done')
    if BUDGET != float('inf'):
        print('STAGE1_DONE; rerun for stage 2'); sys.exit(0)

cbc = pd.concat([pickle.load(open(p, 'rb')) for p in sorted(TMP.glob('chunk_*.pkl'))], ignore_index=True)
keys = ['subject_id', 'hadm_id', 'specimen_id', 'charttime']
cbc = cbc.dropna(subset=['specimen_id']).drop_duplicates(keys + ['test', 'valuenum'])
conflicts = cbc.duplicated(keys + ['test'], keep=False)
print(f'conflicting repeat rows dropped: {int(conflicts.sum()):,}', flush=True)
cbc = cbc.loc[~conflicts]


def to_wide(cbc):
    wide = cbc.pivot(index=keys, columns='test', values='valuenum').reset_index()
    wide.columns.name = None
    for t in cfg.CORE_CBC + cfg.DIFF_CBC:
        if t not in wide:
            wide[t] = float('nan')
    for t in ['hemoglobin', 'hematocrit', 'rbc', 'mcv', 'mch', 'mchc', 'rdw']:
        wide.loc[wide[t] <= 0, t] = float('nan')
    for t in ['hematocrit'] + cfg.DIFF_CBC:
        wide.loc[wide[t] > 100, t] = float('nan')
    for t in cfg.CORE_CBC + cfg.DIFF_CBC:
        wide.loc[wide[t] < 0, t] = float('nan')
    if 'flag' in cbc.columns:
        fl = cbc.assign(ab=cbc.flag.eq('abnormal').astype(float)).pivot(index=keys, columns='test', values='ab')
        fl.columns = [c + '_flag' for c in fl.columns]
        wide = wide.merge(fl.reset_index(), on=keys, how='left')
        for t in cfg.CORE_CBC:
            if t + '_flag' not in wide:
                wide[t + '_flag'] = float('nan')
        # a flag only counts where the value itself survived cleaning
        for t in cfg.CORE_CBC:
            wide.loc[wide[t].isna(), t + '_flag'] = float('nan')
        wide['n_flag_core'] = wide[[t + '_flag' for t in cfg.CORE_CBC]].sum(axis=1, min_count=1)
    wide['n_core_present'] = wide[cfg.CORE_CBC].notna().sum(axis=1)
    wide['n_diff_present'] = wide[cfg.DIFF_CBC].notna().sum(axis=1)
    return wide


wide = to_wide(cbc)
elig = wide.loc[wide.n_core_present >= 6]
chosen = elig.sort_values(['hadm_id', 'charttime', 'specimen_id']).drop_duplicates('hadm_id')
chosen = chosen.merge(adm, on=['subject_id', 'hadm_id'], validate='one_to_one')
chosen.to_csv(OUT, index=False, compression='gzip')
print(f'admissions with an eligible index CBC: {len(chosen):,}; patients: {chosen.subject_id.nunique():,}; flags: {has_flag}')
print(f'wrote {OUT} ({time.time()-t0:.0f}s)')
print('ALL_DONE')
