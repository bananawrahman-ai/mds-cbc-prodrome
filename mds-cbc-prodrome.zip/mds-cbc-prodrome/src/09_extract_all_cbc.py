"""Re-extract ALL CBC results from labevents: inpatient AND outpatient rows,
with the laboratory's reference range and abnormal flag.

Output: data/processed/cbc_all_long.csv.gz
Runtime: roughly 20-60 minutes on a laptop (labevents.csv.gz is ~2.6 GB).
Usage:  python src/09_extract_all_cbc.py            (full run)
        python src/09_extract_all_cbc.py --max-chunks 3   (quick test)
"""
import argparse, sys, time
from pathlib import Path
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
import config as cfg

ap = argparse.ArgumentParser()
ap.add_argument('--max-chunks', type=int, default=None)
ap.add_argument('--out', default=str(cfg.PROC / 'cbc_all_long.csv.gz'))
args = ap.parse_args()

ITEMS = cfg.CBC_ITEMS
cols = ['subject_id', 'hadm_id', 'specimen_id', 'itemid', 'charttime', 'valuenum', 'valueuom',
        'ref_range_lower', 'ref_range_upper', 'flag']
out = Path(args.out)
tmp = out.with_suffix('.partial.gz')
t0 = time.time(); n_in = n_out = 0
first = True
reader = pd.read_csv(cfg.MIMIC_FILES['labevents'], usecols=cols, chunksize=2_000_000,
                     dtype={'flag': str, 'valueuom': str})
for i, ch in enumerate(reader):
    if args.max_chunks is not None and i >= args.max_chunks:
        break
    n_in += len(ch)
    ch = ch[ch.itemid.isin(ITEMS.keys()) & ch.valuenum.notna()]
    ch = ch.assign(test=ch.itemid.map(ITEMS))
    n_out += len(ch)
    ch.to_csv(tmp, mode='w' if first else 'a', header=first, index=False, compression='gzip')
    first = False
    print(f'chunk {i}: read {n_in:,} rows, kept {n_out:,} CBC rows ({time.time()-t0:.0f}s)', flush=True)
tmp.replace(out)
print(f'DONE: {n_out:,} CBC rows (inpatient + outpatient) -> {out}')
