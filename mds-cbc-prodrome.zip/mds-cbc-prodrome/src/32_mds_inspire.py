"""MDS protocol section 9: external validation of a reduced CBC model for MDS in INSPIRE (Seoul National University Hospital).
Train on MIMIC-IV primary cohort with the 8 features INSPIRE reports; apply unchanged to INSPIRE.
Inputs : data/processed/prediag_cohort.csv.gz (MIMIC), data/external/inspire/{operations,diagnosis,labs}.csv.gz
Outputs: results/prediag/external_inspire/"""
import json, sys, time
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import rankdata
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv
IN = ROOT / 'data' / 'external' / 'inspire'; OUT = cfg.RESULTS / 'mds' / 'external_inspire'; OUT.mkdir(parents=True, exist_ok=True)
SEED = 20260927; NB = 200 if QUICK else 1000; DAY = 1440.0  # INSPIRE times are in minutes
LOG = open(OUT / 'run.log', 'w'); t0 = time.time()
def log(m):
    line = f'[{time.time()-t0:7.1f}s] {m}'; print(line, flush=True); LOG.write(line + '\n'); LOG.flush()
try:
    from xgboost import XGBClassifier
    def xgb(): return XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=3, min_child_weight=10, subsample=0.8,
                                    colsample_bytree=0.8, tree_method='hist', random_state=SEED, n_jobs=-1, eval_metric='aucpr')
except Exception:
    from sklearn.ensemble import HistGradientBoostingClassifier
    def xgb(): return HistGradientBoostingClassifier(learning_rate=0.05, max_iter=200, max_leaf_nodes=15, min_samples_leaf=50, random_state=SEED)
def lr(): return make_pipeline(SimpleImputer(strategy='median', add_indicator=True), StandardScaler(), LogisticRegression(C=0.1, max_iter=5000))
F = ['hemoglobin', 'hematocrit', 'wbc', 'platelet', 'lymphocytes_pct', 'neutrophils_pct', 'age_approx', 'gender_bin']
MAP = {'hb': 'hemoglobin', 'hct': 'hematocrit', 'wbc': 'wbc', 'platelet': 'platelet', 'lymphocyte': 'lymphocytes_pct', 'seg': 'neutrophils_pct'}

def auc(y, s):
    r = rankdata(s); n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def boot(y, s, f, n=NB, seed=1):
    rng = np.random.RandomState(seed); pos = np.where(y == 1)[0]; neg = np.where(y == 0)[0]; v = []
    for _ in range(n):
        i = np.r_[rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]; v.append(f(y[i], s[i]))
    return np.percentile(v, [2.5, 97.5])
def calib(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6); lp = np.log(p / (1 - p)).reshape(-1, 1)
    slope = LogisticRegression(C=1e6, max_iter=5000).fit(lp, y).coef_[0][0]
    citl = np.log(y.mean() / (1 - y.mean())) - np.log(p.mean() / (1 - p.mean()))
    return slope, citl
def abn_count(d):
    female = d.gender_bin == 0
    return ((d.hemoglobin < np.where(female, 12, 13)).astype(int) + ((d.wbc < 4) | (d.wbc > 10)).astype(int)
            + ((d.platelet < 150) | (d.platelet > 450)).astype(int) + (d.lymphocytes_pct > 45).astype(int)
            + (d.neutrophils_pct < 40).astype(int)).values

# ---------------- 1. reduced model on MIMIC
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False)
m = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
Xm = m[F].astype(float); ym = m.label.values
oof = {'xgb': np.zeros(len(ym)), 'lr': np.zeros(len(ym))}
for tr, te in StratifiedKFold(5, shuffle=True, random_state=SEED).split(Xm, ym):
    oof['xgb'][te] = xgb().fit(Xm.iloc[tr], ym[tr]).predict_proba(Xm.iloc[te])[:, 1]
    oof['lr'][te] = lr().fit(Xm.iloc[tr], ym[tr]).predict_proba(Xm.iloc[te])[:, 1]
thr95 = np.quantile(oof['xgb'][ym == 0], 0.95)
mimic_rows = [dict(dataset='MIMIC-IV (5-fold CV)', model=k, cases=int(ym.sum()), n=len(ym), auroc=auc(ym, s),
                   auroc_lo=boot(ym, s, auc)[0], auroc_hi=boot(ym, s, auc)[1], ap=average_precision_score(ym, s)) for k, s in oof.items()]
log('MIMIC reduced model:\n' + pd.DataFrame(mimic_rows).round(4).to_string(index=False))
final = {'xgb': xgb().fit(Xm, ym), 'lr': lr().fit(Xm, ym)}

# ---------------- 2. INSPIRE cohort
ops = pd.read_csv(IN / 'operations.csv.gz', usecols=['subject_id', 'age', 'sex', 'opdate'])
demo = ops.sort_values('opdate').drop_duplicates('subject_id')[['subject_id', 'age', 'sex', 'opdate']]
dx = pd.read_csv(IN / 'diagnosis.csv.gz')
labs = pd.read_csv(IN / 'labs.csv.gz')
labs = labs[labs.item_name.isin(MAP)]
cbc = labs.pivot_table(index=['subject_id', 'chart_time'], columns='item_name', values='value', aggfunc='median').rename(columns=MAP).reset_index()
for c in MAP.values():
    if c not in cbc: cbc[c] = np.nan
cbc = cbc.dropna(subset=['hemoglobin', 'wbc', 'platelet'])
cbc = cbc[(cbc.hemoglobin.between(2, 25)) & (cbc.wbc.between(0, 500)) & (cbc.platelet.between(0, 3000))]
cbc = cbc.merge(demo, on='subject_id', how='inner')
# age at CBC: INSPIRE gives age (5-y band) at the first operation; times are minutes from that patient's time zero
cbc['age_approx'] = cbc.age + (cbc.chart_time - cbc.opdate) / DAY / 365.25
cbc['gender_bin'] = (cbc.sex == 'M').astype(float)
cbc = cbc[cbc.age_approx >= 18]
log(f'INSPIRE eligible CBCs: {len(cbc):,} in {cbc.subject_id.nunique():,} patients')

leu = dx[dx.icd10_cm.astype(str).str[:3].isin(['D46'])]
rel_subj = set(dx[dx.icd10_cm.astype(str).str[:3].isin(['C91', 'C92', 'C93', 'C94', 'C95', 'D45', 'D47', 'D61'])].subject_id)
first_rel = dx[dx.icd10_cm.astype(str).str[:3].isin(['C91', 'C92', 'C93', 'C94', 'C95', 'D45', 'D47', 'D61'])].groupby('subject_id').chart_time.min()
t1 = leu.groupby('subject_id').chart_time.min().rename('t1')
sub = leu.sort_values('chart_time').groupby('subject_id').icd10_cm.first().str[:3].rename('code')
first_any = pd.concat([dx[['subject_id', 'chart_time']], labs[['subject_id', 'chart_time']]]).groupby('subject_id').chart_time.min().rename('first_any')
last_any = pd.concat([dx[['subject_id', 'chart_time']], labs[['subject_id', 'chart_time']]]).groupby('subject_id').chart_time.max().rename('last_any')
c = cbc.merge(t1, left_on='subject_id', right_index=True, how='left').merge(first_any, left_on='subject_id', right_index=True)
c = c.merge(last_any, left_on='subject_id', right_index=True).merge(sub, left_on='subject_id', right_index=True, how='left')
c['lead'] = (c.t1 - c.chart_time) / DAY
rng = np.random.RandomState(SEED)
def pick(d):
    return d.assign(r=rng.random(len(d))).sort_values('r').drop_duplicates('subject_id').drop(columns='r')
ctrl = pick(c[c.t1.isna() & ~c.subject_id.isin(rel_subj) & ((c.last_any - c.chart_time) / DAY >= 30)])
c['rel_before'] = c.subject_id.map(first_rel) < c.t1
c = c[~(c.t1.notna() & c.rel_before.fillna(False))]
cases = {w: pick(c[c.t1.notna() & c.lead.between(lo, hi)]) for w, (lo, hi) in {'30-365': (30, 365), '0-29': (0, 29.999)}.items()}
log(f'INSPIRE controls {len(ctrl):,}; cases 30-365 d {len(cases["30-365"])}, 0-29 d {len(cases["0-29"])}')

rows = []
def evaluate(name, ca, ct):
    d = pd.concat([ca.assign(label=1), ct.assign(label=0)])
    y = d.label.values
    if y.sum() < 5:
        log(f'{name}: only {y.sum()} cases, skipped'); return
    X = d[F].astype(float)
    for k, mdl in final.items():
        p = mdl.predict_proba(X)[:, 1]; lo, hi = boot(y, p, auc); slope, citl = calib(y, p)
        sens = (p[y == 1] >= thr95).mean() if k == 'xgb' else np.nan; spec = (p[y == 0] < thr95).mean() if k == 'xgb' else np.nan
        rows.append(dict(analysis=name, model=k, cases=int(y.sum()), controls=int((y == 0).sum()), auroc=auc(y, p), auroc_lo=lo, auroc_hi=hi,
                         ap=average_precision_score(y, p), calib_slope=slope, calib_in_large=citl, sens_at_mimic_thr=sens, spec_at_mimic_thr=spec))
    a = abn_count(d); lo, hi = boot(y, a, auc)
    rows.append(dict(analysis=name, model='abnormal count (reference ranges)', cases=int(y.sum()), controls=int((y == 0).sum()),
                     auroc=auc(y, a), auroc_lo=lo, auroc_hi=hi, ap=average_precision_score(y, a)))
for w, ca in cases.items():
    evaluate(f'INSPIRE cases {w} d', ca, ctrl)
    evaluate(f'INSPIRE cases {w} d, first MDS code >= 90 d after first record', ca[(ca.t1 - ca.first_any) / DAY >= 90], ctrl)
R = pd.DataFrame(mimic_rows + rows); R.to_csv(OUT / 'inspire_validation.csv', index=False)
log('results\n' + R.round(4).to_string(index=False))
desc = pd.DataFrame({k: v[F].median() for k, v in {'INSPIRE cases 30-365': cases['30-365'], 'INSPIRE controls': ctrl,
                     'MIMIC cases': m[m.label == 1], 'MIMIC controls': m[m.label == 0]}.items()})
desc.loc['n'] = [len(cases['30-365']), len(ctrl), int(ym.sum()), int((ym == 0).sum())]
desc.loc['missing lymphocytes_pct %'] = [100 * v.lymphocytes_pct.isna().mean() for v in [cases['30-365'], ctrl, m[m.label == 1], m[m.label == 0]]]
desc.to_csv(OUT / 'inspire_vs_mimic_characteristics.csv'); log('characteristics (medians)\n' + desc.round(2).to_string())
json.dump({'features': F, 'mimic_threshold_spec95': float(thr95)}, open(OUT / 'meta.json', 'w'))
log('INSPIRE_DONE')
