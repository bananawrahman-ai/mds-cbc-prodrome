"""R25 note validation of the MDS case definition (post hoc, second review).
Input : data/raw/note/mds_case_discharge_notes*.csv (one or more BigQuery exports) (MIMIC-IV-Note discharge summaries of the 496 Aim 1 cases, via BigQuery)
        data/processed/mds_case_info.csv.gz (subject_id, t1, first_workup)
Output: data/processed/mds_note_validation.csv.gz (one row per case: note status, first mention times)
        results/mds/v2/rev3_r25_note_summary.json
        results/mds/v2/rev3_r25_manual_review_sample.csv (60 random cases, snippets, empty reviewer column)
Rules (regular expressions, written before the notes were read):
  MDS mention: myelodysplas*, 'MDS' (upper case), MDS subtypes (MDS-EB/LB/SLD/MLD/RS/U, RAEB, RCMD, RARS, refractory anaemia/cytopenia).
  Excluded mention: negated (no, not, without, negative for, ruled out, r/o, unlikely ... within 45 characters before) or family history.
  Uncertain mention: concern/suspect/possible/probable/presumed/question of/evaluate/work-up/vs/differential/consider within
                     45 characters before, or '?', 'vs', 'versus', 'cannot be excluded', 'considered' within 25 characters after.
  Definite: an affirmative mention with marrow, biopsy, aspirate, IPSS, blasts, cytogenetics/karyotype, a subtype term or an
            MDS-directed drug (azacitidine, decitabine, lenalidomide, luspatercept and brand names) within 200 characters.
  Case status: definite > probable (affirmative mention only) > possible (uncertain mentions only) > not supported (notes, no
               affirmative or uncertain mention) > no notes.
"""
import re, json, sys
from pathlib import Path
import numpy as np, pandas as pd

ROOT = Path(__file__).resolve().parents[1]
NOTE = ROOT / 'data' / 'raw' / 'note' / 'mds_case_discharge_notes.csv'
PROC = ROOT / 'data' / 'processed'; OUT = ROOT / 'results' / 'mds' / 'v2'; OUT.mkdir(parents=True, exist_ok=True)

TERM = re.compile(r"(?:[Mm]yelodysplas\w*|MYELODYSPLAS\w*|\bMDS(?:[-/ ]?(?:EB-?[12]?|LB|SLD|MLD|RS|U|5q|del5q))?\b|\bRAEB(?:-?[12T])?\b|\bRCMD\b|\bRARS\b|"
                  r"[Rr]efractory\s+an(?:a)?emia|[Rr]efractory\s+cytopenia)")
SUBTYPE = re.compile(r"MDS[-/ ]?(?:EB|LB|SLD|MLD|RS|U|5q)|RAEB|RCMD|RARS|[Rr]efractory\s+(?:an(?:a)?emia|cytopenia)", re.I)
NEG = re.compile(r"\b(?:no|not|without|negative for|ruled? out|r/o|rule out|unlikely|less likely|doubt(?:ful)?|excluded?|no evidence of|nor)\b[^.;\n]{0,45}$", re.I)
FAM = re.compile(r"\b(?:mother|father|sister|brother|son|daughter|aunt|uncle|cousin|grandmother|grandfather|family history|fhx|fh)\b[^.;\n]{0,45}$", re.I)
UNC_B = re.compile(r"(?:concern|concerning|suspect|suspicion|suspicious|possible|possibly|probable|presumed|presumptive|question of|\?|evaluat|work[- ]?up|w/u|"
                   r"\bvs\.?|versus|differential|ddx|consider|could be|may be|might be|likely|potential)[^.;\n]{0,45}$", re.I)
UNC_A = re.compile(r"^[^.;\n]{0,25}(?:\?|\bvs\.?\b|versus|cannot be (?:excluded|ruled out)|not (?:excluded|ruled out)|(?:was|is|were) considered|suspected|possible)", re.I)
DEF = re.compile(r"marrow|biops|aspirat|\bBMBx\b|\bBM\s?bx\b|\bIPSS|R-IPSS|blasts?\b|cytogenet|karyotyp|FISH|azacitidin|vidaza|decitabin|dacogen|lenalidomid|revlimid|"
                 r"luspatercept|reblozyl|hypomethylat", re.I)

def classify(text):
    """returns (best label for this note, list of (label, snippet))"""
    out = []
    for m in TERM.finditer(text):
        b = text[max(0, m.start() - 60):m.start()]; a = text[m.end():m.end() + 40]; w = text[max(0, m.start() - 200):m.end() + 200]
        if FAM.search(b): lab = 'family'
        elif NEG.search(b): lab = 'negated'
        elif UNC_B.search(b) or UNC_A.search(a): lab = 'uncertain'
        elif SUBTYPE.search(m.group(0)) or DEF.search(w): lab = 'definite'
        else: lab = 'affirmative'
        out.append((lab, re.sub(r'\s+', ' ', text[max(0, m.start() - 150):m.end() + 150])))
    rank = {'definite': 4, 'affirmative': 3, 'uncertain': 2, 'negated': 1, 'family': 1}
    best = max(out, key=lambda x: rank[x[0]])[0] if out else 'none'
    return best, out

def main():
    ci = pd.read_csv(PROC / 'mds_case_info.csv.gz', parse_dates=['t1', 'first_workup'])
    files = sorted(NOTE.parent.glob('mds_case_discharge_notes*.csv'))
    n = pd.concat([pd.read_csv(f, parse_dates=['charttime', 'storetime'], low_memory=False) for f in files], ignore_index=True)
    n['text'] = n['text'].fillna('').astype(str)
    # a BigQuery local export stops at 10 MB, so the last note of a file can be cut; keep the longest copy of each note
    n = n.assign(_len=n.text.str.len()).sort_values('_len').drop_duplicates('note_id', keep='last').drop(columns='_len')
    print(f'{len(files)} note files, {len(n)} unique notes, {n.subject_id.nunique()} patients')
    n = n[n.subject_id.isin(ci.subject_id)].copy(); n['text'] = n['text'].fillna('').astype(str)
    res = [classify(t) for t in n.text]; n['label'] = [r[0] for r in res]
    rows = []
    for sid, g in n.groupby('subject_id'):
        t1 = ci.set_index('subject_id').t1.get(sid)
        labs = set(g.label)
        status = ('definite' if 'definite' in labs else 'probable' if 'affirmative' in labs else 'possible' if 'uncertain' in labs else 'not supported')
        aff = g[g.label.isin(['definite', 'affirmative'])]; anym = g[g.label.isin(['definite', 'affirmative', 'uncertain'])]
        rows.append(dict(subject_id=sid, n_notes=len(g), n_notes_before_t1=int((g.charttime < t1).sum()), status=status,
                         first_affirmative=aff.charttime.min(), first_any_mention=anym.charttime.min(),
                         affirmative_before_t1=bool((aff.charttime < t1).any()), any_mention_before_t1=bool((anym.charttime < t1).any())))
    V = pd.DataFrame(rows)
    V = ci[['subject_id', 't1']].merge(V, on='subject_id', how='left')
    V['status'] = V.status.fillna('no notes'); V['n_notes'] = V.n_notes.fillna(0).astype(int)
    V['note_confirmed'] = V.status.isin(['definite', 'probable'])
    V.to_csv(PROC / 'mds_note_validation.csv.gz', index=False)
    withn = V[V.status != 'no notes']; vc = V.status.value_counts().to_dict()
    lead = (V.t1 - pd.to_datetime(V.first_any_mention)).dt.days
    S = dict(cases=len(V), cases_with_notes=int(len(withn)), notes=int(len(n)), status_counts={k: int(v) for k, v in vc.items()},
             ppv_definite_or_probable=float(withn.note_confirmed.mean()), ppv_definite_or_probable_lo_hi=None,
             ppv_including_possible=float(withn.status.isin(['definite', 'probable', 'possible']).mean()),
             mention_before_t1=int(V.any_mention_before_t1.fillna(False).sum()), affirmative_before_t1=int(V.affirmative_before_t1.fillna(False).sum()),
             days_first_mention_before_t1_median=float(lead[lead > 0].median()) if (lead > 0).any() else None)
    k = int(withn.note_confirmed.sum()); m = len(withn); z = 1.96
    if m:
        ph = k / m; d = 1 + z * z / m; c = (ph + z * z / (2 * m)) / d; h = z * np.sqrt(ph * (1 - ph) / m + z * z / (4 * m * m)) / d; S['ppv_definite_or_probable_lo_hi'] = [c - h, c + h]
    # agreement with the code-based confirmed definition (R16), if available
    try:
        conf = json.load(open(OUT / 'rev2_r16_confirmed_counts.json'))
        S['r16_confirmed_count'] = conf.get('confirmed_any')
    except Exception: pass
    json.dump(S, open(OUT / 'rev3_r25_note_summary.json', 'w'), indent=1, default=str); print(json.dumps(S, indent=1, default=str))
    # manual-review sample: 60 random cases with notes, up to 3 snippets each (best-ranked first)
    rng = np.random.RandomState(20261015); samp = rng.choice(withn.subject_id.values, min(60, len(withn)), replace=False); rr = []
    order = {'definite': 0, 'affirmative': 1, 'uncertain': 2, 'negated': 3, 'family': 4}
    for sid in samp:
        allsn = [x for r, s in zip(res, n.subject_id.values) if s == sid for x in r[1]]
        seen = set(); allsn = [x for x in sorted(allsn, key=lambda x: order[x[0]]) if not (x[1] in seen or seen.add(x[1]))][:3]
        rr.append(dict(subject_id=sid, classifier_status=V.set_index('subject_id').status[sid],
                       snippet_1=allsn[0][1] if len(allsn) > 0 else '', snippet_2=allsn[1][1] if len(allsn) > 1 else '', snippet_3=allsn[2][1] if len(allsn) > 2 else '',
                       reviewer_status_definite_probable_possible_none=''))
    pd.DataFrame(rr).to_csv(OUT / 'rev3_r25_manual_review_sample.csv', index=False, encoding='utf-8-sig')
    print('NOTES_DONE')

if __name__ == '__main__':
    main()
