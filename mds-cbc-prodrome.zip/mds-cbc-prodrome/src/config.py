"""Shared configuration: paths, CBC lab definitions, target-condition ICD maps.

Everything that encodes a study-design decision lives here so that the analysis
scripts stay mechanical and the decisions are auditable in one place.
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RAW = ROOT / "data" / "raw" / "hosp"
PROC = ROOT / "data" / "processed"
RESULTS = ROOT / "results"
FIGURES = RESULTS / "figures"
TABLES = RESULTS / "tables"

for _d in (PROC, RESULTS, FIGURES, TABLES):
    _d.mkdir(parents=True, exist_ok=True)

MIMIC_FILES = {
    "labevents": RAW / "labevents.csv.gz",
    "d_labitems": RAW / "d_labitems.csv.gz",
    "diagnoses_icd": RAW / "diagnoses_icd.csv.gz",
    "d_icd_diagnoses": RAW / "d_icd_diagnoses.csv.gz",
    "admissions": RAW / "admissions.csv.gz",
    "patients": RAW / "patients.csv.gz",
}

# ---------------------------------------------------------------------------
# CBC panel
# ---------------------------------------------------------------------------
# itemids are the well-known MIMIC hospital-lab ids for the Blood/Hematology
# panel. They are stable across MIMIC-III/IV but MUST be re-verified against
# d_labitems.csv.gz for the release actually downloaded -- 00_verify_data.py
# does that and will report any mismatch. LABEL_PATTERNS is the fallback used
# to resolve ids by name if an itemid is absent in the downloaded release.
CBC_ITEMS = {
    51221: "hematocrit",
    51222: "hemoglobin",
    51248: "mch",
    51249: "mchc",
    51250: "mcv",
    51265: "platelet",
    51279: "rbc",
    51277: "rdw",
    51301: "wbc",
    # White-cell differential (percentages)
    51244: "lymphocytes_pct",
    51254: "monocytes_pct",
    51256: "neutrophils_pct",
    51200: "eosinophils_pct",
    51146: "basophils_pct",
}

LABEL_PATTERNS = {
    "hematocrit": r"^hematocrit$",
    "hemoglobin": r"^hemoglobin$",
    "mch": r"^mch$",
    "mchc": r"^mchc$",
    "mcv": r"^mcv$",
    "platelet": r"^platelet count$",
    "rbc": r"^red blood cells$",
    "rdw": r"^rdw$",
    "wbc": r"^white blood cells$",
    "lymphocytes_pct": r"^lymphocytes$",
    "monocytes_pct": r"^monocytes$",
    "neutrophils_pct": r"^neutrophils$",
    "eosinophils_pct": r"^eosinophils$",
    "basophils_pct": r"^basophils$",
}

# Core panel that must be present for a CBC to count as evaluable.
# The differential is frequently not ordered, so it is not required.
CORE_CBC = ["hemoglobin", "hematocrit", "rbc", "wbc", "platelet",
            "mcv", "mch", "mchc", "rdw"]
DIFF_CBC = ["neutrophils_pct", "lymphocytes_pct", "monocytes_pct",
            "eosinophils_pct", "basophils_pct"]

# Physiologically implausible values -> set to missing before imputation.
# Wide on purpose: the job here is to remove transcription/unit errors, not
# to remove genuinely extreme disease values, which are the signal.
PLAUSIBLE_RANGE = {
    "hemoglobin":       (2.0, 25.0),    # g/dL
    "hematocrit":       (6.0, 75.0),    # %
    "rbc":              (0.5, 9.0),     # 10^6/uL
    "wbc":              (0.0, 500.0),   # 10^3/uL
    "platelet":         (0.0, 3000.0),  # 10^3/uL
    "mcv":              (50.0, 150.0),  # fL
    "mch":              (10.0, 60.0),   # pg
    "mchc":             (20.0, 45.0),   # g/dL
    "rdw":              (8.0, 40.0),    # %
    "neutrophils_pct":  (0.0, 100.0),
    "lymphocytes_pct":  (0.0, 100.0),
    "monocytes_pct":    (0.0, 100.0),
    "eosinophils_pct":  (0.0, 100.0),
    "basophils_pct":    (0.0, 100.0),
}

# ---------------------------------------------------------------------------
# Reference standard: target conditions -> ICD-9 / ICD-10 prefixes
# ---------------------------------------------------------------------------
# Matching is by string prefix on the icd_code column, which MIMIC stores
# without the decimal point (e.g. ICD-10 "D509", ICD-9 "2800").
TARGET_CONDITIONS = {
    "iron_deficiency_anemia": {
        "icd10": ["D50"],
        "icd9":  ["280"],
        "label": "Iron deficiency anaemia",
    },
    "other_nutritional_anemia": {
        "icd10": ["D51", "D52", "D53"],
        "icd9":  ["281"],
        "label": "Vitamin B12/folate and other nutritional anaemia",
    },
    "hemolytic_anemia": {
        "icd10": ["D55", "D56", "D57", "D58", "D59"],
        "icd9":  ["282", "283"],
        "label": "Haemolytic anaemia",
    },
    "aplastic_other_anemia": {
        "icd10": ["D60", "D61", "D62", "D63", "D64"],
        "icd9":  ["284", "285"],
        "label": "Aplastic and other anaemia",
    },
    "coagulation_defect": {
        "icd10": ["D65", "D66", "D67", "D68"],
        "icd9":  ["286"],
        "label": "Coagulation defects",
    },
    "thrombocytopenia": {
        "icd10": ["D69"],
        "icd9":  ["2873", "2874", "2875"],
        "label": "Purpura and thrombocytopenia",
    },
    "neutropenia": {
        "icd10": ["D70"],
        "icd9":  ["2880"],
        "label": "Neutropenia / agranulocytosis",
    },
    "leukemia": {
        "icd10": ["C91", "C92", "C93", "C94", "C95"],
        "icd9":  ["204", "205", "206", "207", "208"],
        "label": "Leukaemia",
    },
    "lymphoma": {
        "icd10": ["C81", "C82", "C83", "C84", "C85", "C86", "C88"],
        "icd9":  ["200", "201", "202"],
        "label": "Lymphoma",
    },
    "multiple_myeloma": {
        "icd10": ["C90"],
        "icd9":  ["203"],
        "label": "Multiple myeloma",
    },
    "polycythemia_myeloprolif": {
        "icd10": ["D45", "D46", "D47", "D75"],
        "icd9":  ["238", "2891"],
        "label": "Polycythaemia and myeloproliferative/MDS",
    },
}

# "Any haematological disorder" composite = union of the above.
ANY_HEME = list(TARGET_CONDITIONS.keys())

# ---------------------------------------------------------------------------
# Cohort definition
# ---------------------------------------------------------------------------
MIN_AGE = 18
# CBC must be drawn within this window around admission to be the index test.
CBC_WINDOW_HOURS_BEFORE = 6     # allow ED draws shortly before admission
CBC_WINDOW_HOURS_AFTER = 24
FIRST_ADMISSION_ONLY = True     # one row per patient -> independent observations

RANDOM_SEED = 42
TEST_SIZE = 0.20
N_BOOTSTRAP = 2000              # for 95% CI on AUC and derived metrics
