"""MDS reviewer analyses R1-R5 (added 4 Oct 2026 after an internal review; all post hoc).
R1 diagnosis date: cases without a bone-marrow laboratory test before t1 - 30 d ("clean t1").
R2 confounding: cases and controls without any confounder code before t1 / pseudo-t1 / index (see 39_mds_covariates.py).
R3 Aim 2: age+sex model, models without the differential, setpoints >= 4 y before the index CBC, calibration,
   continuous personal vs population deviation scores and a cross-tabulation of cases caught.
R4 Aim 3: alert burden including non-MDS haematological patients, diagnoses among alerted controls, subsets R1/R2.
R5 Aim 1: outpatient CBCs only, R1 and R2 subsets.
Outputs: results/mds/v2/reviewer_*.csv
R7 (post hoc): with --drugs, the confounder set also includes hospital-ordered macrocytic drugs and cytotoxic
chemotherapy (see 42_mds_drugs.py); outputs then carry the suffix _R7 and "R2" rows mean "no confounder code or drug"."""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
from sklearn.metrics import average_precision_score
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import RepeatedStratifiedKFold, StratifiedKFold
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv; DRUGS = '--drugs' in sys.argv; SUF = '_R7' if DRUGS else ''; NB = 200 if QUICK else 1000; BP = 60 if QUICK else 300
OUT = cfg.RESULTS / 'mds' / 'v2'; SEED = 20260927
t0 = time.time(); log = lambda m: print(f'[{time.time()-t0:7.1f}s] {m}', flush=True)
try:
    from xgboost import XGBClassifier
    def model(): return XGBClassifier(n_estimators=300, learning_rate=0.05, max_depth=3, min_child_weight=10, subsample=0.8,
                                      colsample_bytree=0.8, tree_method='hist', random_state=SEED, n_jobs=-1, eval_metric='aucpr')
except Exception:
    from sklearn.ensemble import HistGradientBoostingClassifier
    def model(): return HistGradientBoostingClassifier(learning_rate=0.05, max_iter=200, max_leaf_nodes=15, min_samples_leaf=50, random_state=SEED)
CORE, DIFF = list(cfg.CORE_CBC), list(cfg.DIFF_CBC); IDX = CORE + DIFF; DEM = ['age_approx', 'gender_bin']
VARS = CORE + ['neutrophils_pct', 'anc', 'n_flag_core']

def auc(y, s):
    r = pd.Series(s).rank().values; n1 = y.sum(); n0 = len(y) - n1
    return (r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0)
def sidx(rng, y):
    pos = np.where(y == 1)[0]; neg = np.where(y == 0)[0]
    return np.r_[rng.choice(pos, len(pos)), rng.choice(neg, len(neg))]
def boot_ci(y, s, f=auc):
    rng = np.random.RandomState(1); v = [f(y[i], s[i]) for i in (sidx(rng, y) for _ in range(NB))]
    return np.percentile(v, 2.5), np.percentile(v, 97.5)
def paired(y, a, b, f=auc):
    rng = np.random.RandomState(2); v = []
    for _ in range(NB):
        i = sidx(rng, y); v.append(f(y[i], a[i]) - f(y[i], b[i]))
    return f(y, a) - f(y, b), np.percentile(v, 2.5), np.percentile(v, 97.5)
def calib(y, p):
    p = np.clip(p, 1e-6, 1 - 1e-6); lg = np.log(p / (1 - p)).reshape(-1, 1)
    slope = LogisticRegression(C=1e6, max_iter=1000).fit(lg, y).coef_[0, 0]
    return slope, y.sum() / p.sum()
def ageband(a): return pd.cut(a, [-1, 49.99, 59.99, 69.99, 79.99, 200], labels=['<50', '50-59', '60-69', '70-79', '>=80']).astype(str)

# ---------------- shared inputs
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False, parse_dates=['index_time'])
p = coh[coh.window.isin(['lead_30_365', 'control'])].reset_index(drop=True)
ci = pd.read_csv(cfg.PROC / 'mds_case_info.csv.gz', parse_dates=['t1', 'first_workup'])
mi = pd.read_csv(cfg.PROC / 'mds_matched_info.csv.gz', parse_dates=['pseudo_t1'])
cov = pd.read_csv(cfg.PROC / ('mds_covariates_drugs.csv.gz' if DRUGS else 'mds_covariates.csv.gz'))
for c in cov.columns:
    if c.startswith('first_'): cov[c] = pd.to_datetime(cov[c])
cov = cov.set_index('subject_id')
hc = pd.read_csv(cfg.PROC / 'mds_hist_cases.csv.gz', parse_dates=['t', 't1'])
hm = pd.read_csv(cfg.PROC / 'mds_hist_matched.csv.gz', parse_dates=['t', 'pseudo_t1'])
hcc = pd.read_csv(cfg.PROC / 'mds_hist_cohort_ctrl.csv.gz', parse_dates=['t', 'index_time'])
def before(ids, anchor, col):
    a = pd.Series(anchor.values, index=ids.values); d = cov[col].reindex(ids.values)
    return (d.values < a.values)
ci['marrow_before'] = before(ci.subject_id, ci.t1 - pd.Timedelta(days=30), 'first_marrow')
ci['conf_before'] = before(ci.subject_id, ci.t1, 'first_any_confounder')
mi['conf_before'] = before(mi.subject_id, mi.pseudo_t1, 'first_any_confounder')
p['conf_before'] = before(p.subject_id, p.index_time, 'first_any_confounder')
clean_t1 = set(ci.subject_id[~ci.marrow_before]); unconf_cases = set(ci.subject_id[~ci.conf_before]); unconf_ctrl = set(mi.subject_id[~mi.conf_before])
desc = dict(cases=len(ci), cases_marrow_before_t1_minus30=int(ci.marrow_before.sum()), cases_confounder_before_t1=int(ci.conf_before.sum()),
            matched_controls=len(mi), matched_controls_confounder_before=int(mi.conf_before.sum()),
            cohort_cases_confounder_before_index=int(p.conf_before[p.label == 1].sum()), cohort_controls_confounder_before_index=int(p.conf_before[p.label == 0].sum()))
for g in [c for c in cov.columns if c.startswith('first_') and c not in ('first_any_confounder', 'first_any_confounder_codes', 'first_marrow', 'first_heme_other')]:
    desc[f'cases_{g}_before_t1'] = int(before(ci.subject_id, ci.t1, g).sum()); desc[f'matched_{g}_before'] = int(before(mi.subject_id, mi.pseudo_t1, g).sum())
pd.Series(desc).to_csv(OUT / f'reviewer_subset_counts{SUF}.csv'); log('subset counts\n' + pd.Series(desc).to_string())

# ---------------- R5/R1/R2 Aim 1: offset + acceleration model, 0-10 y, 6-month bins
ref = p[p.label == 0].copy(); ref['anc'] = ref.wbc * ref.neutrophils_pct / 100; ref['k'] = ref.gender + '|' + ageband(ref.age_approx)
med = ref.groupby('k')[VARS].median(); rsd = ((ref.groupby('k')[VARS].quantile(.75) - ref.groupby('k')[VARS].quantile(.25)) / 1.349).where(lambda x: x > 0)
EDGES = np.arange(0, 3653 + 1, 182.625); EDGES[-1] = 3653; NBIN = len(EDGES) - 1; MID = (EDGES[:-1] + EDGES[1:]) / 2 / 365.25
def zscore(h):
    h = h.copy(); h['anc'] = h.wbc * h.neutrophils_pct / 100; k = h.gender + '|' + ageband(h.age_approx)
    for v in VARS: h[v] = (h[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    h['bin'] = np.digitize(h.days_before, EDGES) - 1; return h[(h.bin >= 0) & (h.bin < NBIN)]
zc, zm = zscore(hc), zscore(hm)
def pmat(h):
    g = h.groupby(['subject_id', 'bin'])[VARS].mean(); ids = g.index.get_level_values(0).unique(); pos = pd.Series(np.arange(len(ids)), index=ids)
    X = np.full((len(ids), NBIN, len(VARS)), np.nan); X[pos.reindex(g.index.get_level_values(0)).values, g.index.get_level_values(1).values] = g.values; return X
def wmean(X, w):
    ok = ~np.isnan(X); return np.einsum('n,nbv->bv', w, np.where(ok, X, 0)) / np.where(np.einsum('n,nbv->bv', w, ok.astype(float)) > 0, np.einsum('n,nbv->bv', w, ok.astype(float)), np.nan)
def fit(d, wt, mask):
    best = (np.inf, np.nan, np.nan, np.nan)
    for tau in np.arange(0.5, MID.max() + 1e-9, 0.25):
        x = np.maximum(tau - MID, 0)[mask]; yv = d[mask]; ww = wt[mask]
        if (x > 0).sum() < 2 or (x == 0).sum() < 2: continue
        A = np.c_[np.ones_like(x), x]; W = np.sqrt(ww); coef = np.linalg.lstsq(A * W[:, None], yv * W, rcond=None)[0]; sse = (ww * (yv - A @ coef) ** 2).sum()
        if sse < best[0]: best = (sse, tau, coef[0], coef[1])
    return best[1:]
P1, P1b = [], []
for label, csub, msub in [('all', zc, zm), ('R1 clean t1 (no marrow test before t1-30d)', zc[zc.subject_id.isin(clean_t1)], zm),
                          ('R2 no confounder before t1 (cases and controls)', zc[zc.subject_id.isin(unconf_cases)], zm[zm.subject_id.isin(unconf_ctrl)]),
                          ('R5 outpatient CBCs only', zc[zc.setting == 'outpatient'], zm[zm.setting == 'outpatient'])]:
    CX, MX = pmat(csub), pmat(msub); diff = wmean(CX, np.ones(len(CX))) - wmean(MX, np.ones(len(MX)))
    rng = np.random.RandomState(7); boots = np.stack([wmean(CX, rng.poisson(1, len(CX)).astype(float)) - wmean(MX, rng.poisson(1, len(MX)).astype(float)) for _ in range(BP)])
    lo, hi, sd = np.nanpercentile(boots, 2.5, 0), np.nanpercentile(boots, 97.5, 0), np.nanstd(boots, 0); ncase = (~np.isnan(CX)).sum(0)
    for j, v in enumerate(VARS):
        mask = (ncase[:, j] >= 30) & ~np.isnan(diff[:, j]) & (sd[:, j] > 0); wt = np.where(mask, 1 / np.where(sd[:, j] > 0, sd[:, j], 1) ** 2, 0)
        tau, a0, b0 = fit(diff[:, j], wt, mask); bt = np.array([fit(boots[b, :, j], wt, mask & ~np.isnan(boots[b, :, j])) for b in range(BP)], float)
        P1.append(dict(analysis=label, var=v, n_cases=len(CX), n_controls=len(MX), bins_used=int(mask.sum()), diff_0_6m=diff[0, j], lo_0_6m=lo[0, j], hi_0_6m=hi[0, j],
                       offset=a0, offset_lo=np.nanpercentile(bt[:, 1], 2.5), offset_hi=np.nanpercentile(bt[:, 1], 97.5), tau=tau,
                       tau_lo=np.nanpercentile(bt[:, 0], 2.5), tau_hi=np.nanpercentile(bt[:, 0], 97.5), slope=b0, slope_lo=np.nanpercentile(bt[:, 2], 2.5), slope_hi=np.nanpercentile(bt[:, 2], 97.5)))
        for i in range(NBIN): P1b.append(dict(analysis=label, var=v, years_before_mid=MID[i], n_cases=int(ncase[i, j]), diff=diff[i, j], lo=lo[i, j], hi=hi[i, j]))
    log(f'Aim 1 {label}: {len(CX)} cases, {len(MX)} controls')
pd.DataFrame(P1).to_csv(OUT / f'reviewer_prodrome_onset{SUF}.csv', index=False); pd.DataFrame(P1b).to_csv(OUT / f'reviewer_prodrome_bins{SUF}.csv', index=False)
log('Aim 1\n' + pd.DataFrame(P1)[['analysis', 'var', 'n_cases', 'offset', 'offset_lo', 'offset_hi', 'tau', 'tau_lo', 'tau_hi']].round(2).to_string(index=False))

# ---------------- R3 Aim 2
H = pd.concat([hc[['subject_id', 't'] + IDX], hcc[['subject_id', 't'] + IDX]], ignore_index=True).merge(p[['subject_id', 'index_time']], on='subject_id')
H['gap'] = (H.index_time - H.t).dt.total_seconds() / 86400 / 365.25
def build(min_gap, keep_ids=None):
    base = H[(H.gap >= min_gap) & (H.gap <= 10)]; nb = base.groupby('subject_id').size(); keep = nb[nb >= 2].index
    if keep_ids is not None: keep = keep.intersection(pd.Index(list(keep_ids)))
    d = p[p.subject_id.isin(keep)].copy().set_index('subject_id'); base = base[base.subject_id.isin(keep)]
    sp = base.groupby('subject_id')[IDX].median(); cnt = base.groupby('subject_id')[IDX].count(); var = base.groupby('subject_id')[IDX].var(ddof=1)
    wsd = np.sqrt(var.where(cnt >= 3).mean()); k = d.gender + '|' + ageband(d.age_approx)
    for v in IDX:
        d[f'set_{v}'] = sp[v]; d[f'drift_{v}'] = (d[v] - sp[v]) / wsd[v]
        b = base[['subject_id', 'gap', v]].dropna(); b = pd.concat([b, d[[v]].dropna().reset_index().assign(gap=0.0)], ignore_index=True); b['x'] = -b.gap; g = b.groupby('subject_id')
        n = g.size(); sx = g.x.sum(); sy = g[v].sum(); sxx = (b.x * b.x).groupby(b.subject_id).sum(); sxy = (b.x * b[v]).groupby(b.subject_id).sum(); den = n * sxx - sx * sx
        d[f'slope_{v}'] = ((n * sxy - sx * sy) / den.where(den > 1e-9)).where(n >= 3)
    for v in CORE: d[f'pop_{v}'] = (d[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    d['personal_dev'] = np.nansum(np.abs(d[[f'drift_{v}' for v in CORE]].values), axis=1)
    d['population_dev'] = np.nansum(np.abs(d[[f'pop_{v}' for v in CORE]].values), axis=1)
    d['personal_breach'] = (d[[f'drift_{v}' for v in CORE]].abs() > 1.96).sum(axis=1)
    return d.reset_index()
SETS = {'AGE': DEM, 'SNAP': IDX + DEM, 'SET': [f'set_{v}' for v in IDX] + DEM, 'FULL': IDX + DEM + [f'drift_{v}' for v in IDX] + [f'slope_{v}' for v in CORE],
        'SNAP_core': CORE + DEM, 'FULL_core': CORE + DEM + [f'drift_{v}' for v in CORE] + [f'slope_{v}' for v in CORE]}
def cv(d, cols, reps):
    X = d[cols].astype(float); y = d.label.values; o = np.zeros((reps, len(y)))
    for j, (tr, te) in enumerate(RepeatedStratifiedKFold(n_splits=5, n_repeats=reps, random_state=SEED).split(X, y)):
        o[j // 5, te] = model().fit(X.iloc[tr], y[tr]).predict_proba(X.iloc[te])[:, 1]
    return o.mean(0)
R3, R3p = [], []
runs = [('primary (baseline 1-10 y before index)', 1.0, None, list(SETS), 1 if QUICK else 5),
        ('baseline >= 4 y before index', 4.0, None, ['AGE', 'SNAP', 'SET', 'FULL'], 1 if QUICK else 3),
        ('R2 no confounder before index', 1.0, set(p.subject_id[~p.conf_before]), ['AGE', 'SNAP', 'SET', 'FULL'], 1 if QUICK else 3),
        ('R1 clean t1 cases (controls all)', 1.0, set(p.subject_id[p.label == 0]) | clean_t1, ['AGE', 'SNAP', 'SET', 'FULL'], 1 if QUICK else 3)]
for tag, gap, ids, models, reps in runs:
    d = build(gap, ids); y = d.label.values; log(f'Aim 2 {tag}: {len(d):,} patients, {y.sum()} cases')
    oof = {m: cv(d, SETS[m], reps) for m in models}
    for m, s in oof.items():
        lo, hi = boot_ci(y, s); sl, oe = calib(y, s)
        R3.append(dict(analysis=tag, model=m, n=len(y), cases=int(y.sum()), auroc=auc(y, s), lo=lo, hi=hi, ap=average_precision_score(y, s), calib_slope=sl, observed_expected=oe))
    for nm, s in [('population deviation score (sum |z|)', d.population_dev.values), ('personal deviation score (sum |drift|)', d.personal_dev.values),
                  ('personal flag count', d.personal_breach.values.astype(float)), ('population lab flag count', d.n_flag_core.fillna(0).values)]:
        lo, hi = boot_ci(y, s); R3.append(dict(analysis=tag, model=nm, n=len(y), cases=int(y.sum()), auroc=auc(y, s), lo=lo, hi=hi, ap=average_precision_score(y, s)))
    comps = [('SET', 'AGE'), ('SNAP', 'AGE'), ('FULL', 'SNAP')] + ([('FULL_core', 'SNAP_core')] if 'FULL_core' in oof else [])
    for a, b in comps:
        x, lo, hi = paired(y, oof[a], oof[b]); R3p.append(dict(analysis=tag, comparison=f'{a} minus {b}', auroc_diff=x, lo=lo, hi=hi))
    x, lo, hi = paired(y, d.personal_dev.values, d.population_dev.values); R3p.append(dict(analysis=tag, comparison='personal minus population deviation score', auroc_diff=x, lo=lo, hi=hi))
    if tag.startswith('primary'):
        thr = lambda s: np.quantile(s[y == 0], 0.95)
        pop_hit = d.population_dev.values > thr(d.population_dev.values); per_hit = d.personal_dev.values > thr(d.personal_dev.values)
        ct = pd.crosstab(pd.Series(pop_hit[y == 1], name='population score above 95%-spec threshold'), pd.Series(per_hit[y == 1], name='personal score above 95%-spec threshold'))
        ct.to_csv(OUT / f'reviewer_aim2_crosstab_cases{SUF}.csv'); log('cases caught (95% specificity each)\n' + ct.to_string())
pd.DataFrame(R3).to_csv(OUT / f'reviewer_aim2_models{SUF}.csv', index=False); pd.DataFrame(R3p).to_csv(OUT / f'reviewer_aim2_paired{SUF}.csv', index=False)
log('Aim 2\n' + pd.DataFrame(R3).round(3).to_string(index=False)); log('Aim 2 paired\n' + pd.DataFrame(R3p).round(4).to_string(index=False))

# ---------------- R4 Aim 3
F = IDX + DEM; yv = p.label.values; fold = np.zeros(len(p), int); models = []; oofs = np.zeros(len(p))
for k, (tr, te) in enumerate(StratifiedKFold(5, shuffle=True, random_state=SEED).split(p, yv)):
    m = model().fit(p.loc[tr, F].astype(float), yv[tr]); models.append(m); fold[te] = k; oofs[te] = m.predict_proba(p.loc[te, F].astype(float))[:, 1]
fold_of = pd.Series(fold, index=p.subject_id); T = {'spec95': np.quantile(oofs[yv == 0], .95), 'spec99': np.quantile(oofs[yv == 0], .99)}
def score(h):
    X = h[F].astype(float); f = fold_of.reindex(h.subject_id).values; s = np.full(len(h), np.nan); known = ~np.isnan(f)
    for k, m in enumerate(models):
        idx = known & (f == k)
        if idx.any(): s[idx] = m.predict_proba(X[idx])[:, 1]
    if (~known).any(): s[~known] = np.mean([m.predict_proba(X[~known])[:, 1] for m in models], 0)
    return s
hc['score'] = score(hc); hcc['score'] = score(hcc)
# non-MDS haematological patients (excluded from controls): all their CBCs
heme_ids = set(cov.index[cov.first_heme_other.notna()]) - set(ci.subject_id) - set(coh.subject_id[coh.label == 1])
KEEP = ['subject_id', 't'] + IDX + ['age_approx', 'gender']
inp = pd.read_csv(cfg.PROC / 'admission_cbc_all.csv.gz', parse_dates=['admittime']); inp = inp[inp.subject_id.isin(heme_ids)].assign(t=lambda d: d.admittime)
outp = pd.read_csv(cfg.PROC / 'outpatient_cbc_all.csv.gz', parse_dates=['charttime']); outp = outp[outp.subject_id.isin(heme_ids)].assign(t=lambda d: d.charttime)
hh = pd.concat([inp[KEEP], outp[KEEP]], ignore_index=True); hh['gender_bin'] = (hh.gender == 'M').astype(float); hh['score'] = score(hh); del inp, outp
log(f'non-MDS haematological patients with CBCs: {hh.subject_id.nunique():,} ({len(hh):,} CBCs)')
primary_cases = set(p.subject_id[p.label == 1]); R4 = []
for tn, thr in T.items():
    for tag, ids in [('all cohort cases', primary_cases), ('R1 clean t1', primary_cases & clean_t1), ('R2 no confounder before t1', primary_cases & unconf_cases)]:
        h = hc[hc.subject_id.isin(ids)]; first = h[h.score > thr].groupby('subject_id').t.min(); t1s = ci.set_index('subject_id').t1.reindex(sorted(ids))
        lead = (t1s - first.reindex(t1s.index)).dt.total_seconds() / 86400; n = len(t1s)
        R4.append(dict(threshold=tn, analysis=tag, cases=n, alert_ge_30d=(lead >= 30).mean(), alert_ge_365d=(lead >= 365).mean(), median_lead_days=lead[lead >= 30].median()))
    found = R4[-3]['alert_ge_30d'] * R4[-3]['cases']
    ca = hcc[hcc.score > thr].subject_id.unique(); nh = hh[hh.score > thr].subject_id.nunique()
    R4.append(dict(threshold=tn, analysis='burden: cohort controls only', non_cases=hcc.subject_id.nunique(), ever_alerted=len(ca), per_case_found=len(ca) / found, person_level_ppv=found / (found + len(ca))))
    R4.append(dict(threshold=tn, analysis='burden: controls + non-MDS haematological patients', non_cases=hcc.subject_id.nunique() + hh.subject_id.nunique(), ever_alerted=len(ca) + nh,
                   per_case_found=(len(ca) + nh) / found, person_level_ppv=found / (found + len(ca) + nh)))
    uc = set(p.subject_id[(p.label == 0) & ~p.conf_before]); cau = hcc[(hcc.score > thr) & hcc.subject_id.isin(uc)].subject_id.nunique()
    R4.append(dict(threshold=tn, analysis='burden: controls without confounder before index', non_cases=len(uc), ever_alerted=cau, share_alerted=cau / len(uc)))
    if tn == 'spec99':
        ctrl = pd.DataFrame({'subject_id': hcc.subject_id.unique()}); ctrl['alerted'] = ctrl.subject_id.isin(set(ca))
        prof = []
        for g in [c for c in cov.columns if c.startswith('first_') and c not in ('first_marrow', 'first_heme_other')]:
            has = cov[g].reindex(ctrl.subject_id).notna().values
            prof.append(dict(group=g.replace('first_', ''), alerted_controls_pct=100 * has[ctrl.alerted.values].mean(), non_alerted_controls_pct=100 * has[~ctrl.alerted.values].mean()))
        pd.DataFrame(prof).to_csv(OUT / f'reviewer_alerted_control_profile{SUF}.csv', index=False); log('alerted-control diagnoses (any time)\n' + pd.DataFrame(prof).round(1).to_string(index=False))
pd.DataFrame(R4).to_csv(OUT / f'reviewer_aim3{SUF}.csv', index=False); log('Aim 3\n' + pd.DataFrame(R4).round(3).to_string(index=False))
log('REVIEWER' + SUF + '_DONE')
