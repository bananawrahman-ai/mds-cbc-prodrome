"""MDS v2 Aim 1, POST HOC (added 4 Oct 2026 after seeing Aim 1 results): the pre-specified hinge model assumed no case-control
difference far from diagnosis, but red-cell indices already differed 5 years before. This fits d(t) = a + beta*max(tau - t, 0)
(a long-standing offset plus an acceleration starting tau years before diagnosis), over 0-5 y (3-month bins) and 0-10 y (6-month bins).
Outputs results/mds/v2/prodrome_posthoc_onset.csv, prodrome_posthoc_bins_10y.csv"""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
ROOT = Path(__file__).resolve().parents[1]; sys.path.insert(0, str(ROOT / 'src'))
import config as cfg
QUICK = '--quick' in sys.argv; B = 100 if QUICK else 500
OUT = cfg.RESULTS / 'mds' / 'v2'; OUT.mkdir(parents=True, exist_ok=True)
CORE = list(cfg.CORE_CBC); VARS = CORE + ['neutrophils_pct', 'anc', 'n_flag_core']
WIN = '10y' if '--10y' in sys.argv else '5y'
if WIN == '5y': EDGES = np.arange(0, 1827 + 1, 91.3125); EDGES[-1] = 1827
else: EDGES = np.arange(0, 3653 + 1, 182.625); EDGES[-1] = 3653
NB = len(EDGES) - 1; MID = (EDGES[:-1] + EDGES[1:]) / 2 / 365.25
t0 = time.time(); log = lambda m: print(f'[{time.time()-t0:6.1f}s] {m}', flush=True)

def ageband(a): return pd.cut(a, [-1, 49.99, 59.99, 69.99, 79.99, 200], labels=['<50', '50-59', '60-69', '70-79', '>=80']).astype(str)
coh = pd.read_csv(cfg.PROC / 'mds_cohort.csv.gz', low_memory=False)
ref = coh[coh.window == 'control'].copy(); ref['anc'] = ref.wbc * ref.neutrophils_pct / 100
ref['k'] = ref.gender + '|' + ageband(ref.age_approx)
med = ref.groupby('k')[VARS].median(); rsd = (ref.groupby('k')[VARS].quantile(.75) - ref.groupby('k')[VARS].quantile(.25)) / 1.349
rsd = rsd.where(rsd > 0)

def zscore(h):
    h = h.copy(); h['anc'] = h.wbc * h.neutrophils_pct / 100; k = h.gender + '|' + ageband(h.age_approx)
    for v in VARS:
        h[v] = (h[v] - med[v].reindex(k).values) / rsd[v].reindex(k).values
    h['bin'] = np.digitize(h.days_before, EDGES) - 1
    return h[(h.bin >= 0) & (h.bin < NB)]

ci = pd.read_csv(cfg.PROC / 'mds_case_info.csv.gz', parse_dates=['t1', 'first_workup'])
hc = zscore(pd.read_csv(cfg.PROC / 'mds_hist_cases.csv.gz', parse_dates=['t']))
hm = zscore(pd.read_csv(cfg.PROC / 'mds_hist_matched.csv.gz', parse_dates=['t']))
log(f'cases {hc.subject_id.nunique()} ({len(hc):,} CBCs in 0-5 y), matched controls {hm.subject_id.nunique()} ({len(hm):,} CBCs)')

def patient_matrix(h):
    p = h.groupby(['subject_id', 'bin'])[VARS].mean()
    ids = p.index.get_level_values(0).unique()
    X = np.full((len(ids), NB, len(VARS)), np.nan)
    pos = pd.Series(np.arange(len(ids)), index=ids)
    X[pos.reindex(p.index.get_level_values(0)).values, p.index.get_level_values(1).values] = p.values
    return ids, X

def wmean(X, w):  # X: n x NB x V, w: n -> NB x V
    ok = ~np.isnan(X); num = np.einsum('n,nbv->bv', w, np.where(ok, X, 0)); den = np.einsum('n,nbv->bv', w, ok.astype(float))
    return num / np.where(den > 0, den, np.nan), den

def hinge_tau(d, wt, mask):
    best = (np.inf, np.nan, np.nan, np.nan)
    for tau in np.arange(0.25, MID.max() + 1e-9, 0.25):
        x = np.maximum(tau - MID, 0)[mask]; y = d[mask]; ww = wt[mask]
        if (x > 0).sum() < 2 or (x == 0).sum() < 2: continue
        A = np.c_[np.ones_like(x), x]; W = np.sqrt(ww)
        coef = np.linalg.lstsq(A * W[:, None], y * W, rcond=None)[0]; sse = (ww * (y - A @ coef) ** 2).sum()
        if sse < best[0]: best = (sse, tau, coef[0], coef[1])
    return best[1:]

def analyse(case_ids_keep, label):
    cid, CX = patient_matrix(hc[hc.subject_id.isin(case_ids_keep)]); mid, MX = patient_matrix(hm)
    cm, cden = wmean(CX, np.ones(len(cid))); mm, mden = wmean(MX, np.ones(len(mid))); diff = cm - mm
    rng = np.random.RandomState(7); boots = np.empty((B, NB, len(VARS)))
    for b in range(B):
        boots[b] = wmean(CX, rng.poisson(1, len(cid)).astype(float))[0] - wmean(MX, rng.poisson(1, len(mid)).astype(float))[0]
    lo, hi = np.nanpercentile(boots, 2.5, 0), np.nanpercentile(boots, 97.5, 0); sd = np.nanstd(boots, 0)
    ncase = (~np.isnan(CX[:, :, 0])).sum(0) if True else None
    ncase_v = (~np.isnan(CX)).sum(0); nctrl_v = (~np.isnan(MX)).sum(0)
    rows, onset = [], []
    for j, v in enumerate(VARS):
        for i in range(NB):
            rows.append(dict(analysis=label, var=v, bin=i, years_before_mid=MID[i], n_cases=int(ncase_v[i, j]), n_controls=int(nctrl_v[i, j]),
                             case_mean=cm[i, j], control_mean=mm[i, j], diff=diff[i, j], lo=lo[i, j], hi=hi[i, j]))
        mask = (ncase_v[:, j] >= 30) & ~np.isnan(diff[:, j]) & (sd[:, j] > 0)
        wt = np.where(mask, 1 / np.where(sd[:, j] > 0, sd[:, j], 1) ** 2, 0)
        tau, a0, b0 = hinge_tau(diff[:, j], wt, mask)
        bt = np.array([hinge_tau(boots[b, :, j], wt, mask & ~np.isnan(boots[b, :, j])) for b in range(B)], float)
        taus = bt[:, 0]
        sig = (lo[:, j] > 0) | (hi[:, j] < 0); sus = 0.0
        for i in range(NB):
            if not mask[i]: continue
            if sig[i]: sus = EDGES[i + 1] / 365.25
            else: break
        onset.append(dict(analysis=label, var=v, direction='up' if np.nanmean(diff[:4, j]) > 0 else 'down', diff_0_3m=diff[0, j],
                          window=WIN, acceleration_onset_years=tau, tau_lo=np.nanpercentile(taus, 2.5), tau_hi=np.nanpercentile(taus, 97.5),
                          offset=a0, offset_lo=np.nanpercentile(bt[:, 1], 2.5), offset_hi=np.nanpercentile(bt[:, 1], 97.5),
                          slope_per_year=b0, slope_lo=np.nanpercentile(bt[:, 2], 2.5), slope_hi=np.nanpercentile(bt[:, 2], 97.5),
                          diff_at_window_end=diff[NB - 1, j],
                          sustained_significant_from_years=sus, bins_used=int(mask.sum()), n_cases=len(cid)))
    return rows, onset

R, O = analyse(set(ci.subject_id), 'all cases')
unrec = ci[ci.first_workup.isna() | (ci.first_workup >= ci.t1 - pd.Timedelta(days=30))].subject_id
r2, o2 = analyse(set(unrec), 'cases without prior haematology work-up'); R += r2; O += o2
pd.DataFrame(R).to_csv(OUT / f'prodrome_posthoc_bins_{WIN}.csv', index=False)
O = pd.DataFrame(O); O.to_csv(OUT / f'prodrome_posthoc_onset_{WIN}.csv', index=False)
log('onset\n' + O.round(3).to_string(index=False)); log('PRODROME_POSTHOC_DONE')
