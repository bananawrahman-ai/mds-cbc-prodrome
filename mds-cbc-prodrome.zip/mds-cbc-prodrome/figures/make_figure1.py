import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from pathlib import Path
HERE = Path(__file__).resolve().parent
INK = '#1f2328'; MUTED = '#59636e'; EDGE = '#b9bdb4'; BLUE = '#2a6fdb'; FILL = '#e8f0fc'; EXC = '#fbf3ee'; EXE = '#d9a37f'; LN = '#9aa1a9'
plt.rcParams.update({'font.family': 'DejaVu Sans'})
fig, ax = plt.subplots(figsize=(13, 8)); fig.subplots_adjust(0.01, 0.04, 0.99, 0.99); ax.set_xlim(0, 130); ax.set_ylim(12, 90); ax.axis('off')
def box(x, y, w, h, title, body, kind='n'):
    fc, ec, lw = {'n': ('white', EDGE, 1.3), 'a': (FILL, BLUE, 2), 'x': (EXC, EXE, 1.1)}[kind]
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.3,rounding_size=1.2', fc=fc, ec=ec, lw=lw))
    if title:
        ax.text(x + w / 2, y + h - 1.6, title, ha='center', va='top', fontsize=11.5, fontweight='bold', color=INK)
        ax.text(x + w / 2, y + h - 5.4, body, ha='center', va='top', fontsize=9.6, color=INK, linespacing=1.4)
    else:
        ax.text(x + w / 2, y + h / 2, body, ha='center', va='center', fontsize=9, color='#5a3a22', linespacing=1.35)
def arrow(x, y1, y2): ax.annotate('', xy=(x, y2), xytext=(x, y1), arrowprops=dict(arrowstyle='-|>', color=LN, lw=1.2, shrinkA=0, shrinkB=0))
def line(x1, y1, x2, y2): ax.plot([x1, x2], [y1, y2], color=LN, lw=1.2)
ax.text(1, 89.5, 'Three analysis sets drawn from 1,777,860 eligible CBCs', fontsize=14, fontweight='bold', color=INK, va='top')
box(36, 75, 58, 9.5, 'MIMIC-IV v3.1, Boston, 2008-2022', 'all outpatient CBCs and the first CBC of each\ncoded admission: 1,777,860 eligible CBCs')
line(65, 75, 65, 72.5); line(34, 72.5, 96, 72.5); arrow(34, 72.5, 70.3); arrow(96, 72.5, 70.3)
box(8, 55, 52, 15, 'Future MDS cases', '936 patients with an MDS code (D46; 238.72-238.75)\n152 excluded for leukaemia, MPN or aplastic\nanaemia coded before t1\n784 eligible cases')
box(70, 55, 52, 15, 'Control pool', 'no MDS, leukaemia, MPN or aplastic anaemia\ncode at any time; index CBC at least 30 days\nbefore the last admission\n102,539 patients')
line(34, 55, 34, 51); line(96, 55, 96, 51); line(20, 51, 110, 51)
cols = [(20, '288 cases without any\nCBC before t1', 'Aim 1: prodrome', '496 cases with a CBC before t1\n(7,229 CBCs)\n4,955 controls, 1:10 on sex and\n5-year age band, anchored at a\nrandom eligible admission\n37,630 CBCs within 10 years'),
        (65, '422 cases without a CBC\n30-365 days before t1', 'Aim 3: silent alert', '362 cases, 102,539 controls\n(102,901 patients)\none index CBC per patient\nfor training; every CBC\nscored out of fold\n(1,175,913 control CBCs)'),
        (110, '214 cases and 80,261 controls of\nthe Aim 3 cohort with fewer than\n2 CBCs 1-10 years before the index', 'Aim 2: personal setpoints', '148 cases, 22,278 controls\nat least 2 baseline CBCs\n1-10 years before the index\nCBC\n(a subset of the Aim 3\ncohort)')]
for cx, exc, t, body in cols:
    arrow(cx, 51, 47.3); box(cx - 17, 38, 34, 9, None, 'Excluded: ' + exc if False else exc, 'x'); arrow(cx, 38, 34.3)
    box(cx - 18.5, 13, 37, 21, t, body, 'a')
fig.text(0.01, 0.015, 't1, first admission with an MDS code; MPN, myeloproliferative neoplasm. Controls for each aim come from the control pool.', fontsize=8.8, color=MUTED)
plt.savefig(HERE / 'Figure1_study_flow.png', dpi=200, facecolor='white', bbox_inches='tight'); print('ok')
