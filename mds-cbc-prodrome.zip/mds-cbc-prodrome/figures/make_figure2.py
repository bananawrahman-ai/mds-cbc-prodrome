import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path; D=str(Path(__file__).resolve().parents[2] / 'results' / 'mds' / 'v2') + '/'
b=pd.read_csv(D+'reviewer_prodrome_bins.csv'); b=b[b.analysis=='all']
m=pd.read_csv(D+'revision_r9_mixed_model.csv'); m=m[m.subset=='all patients'].set_index('var')
XS=[0.25,0.5,1,2,3,4,5,6,8]
P=[('rbc','Red-cell count'),('mcv','MCV'),('hemoglobin','Haemoglobin'),('rdw','RDW'),('platelet','Platelets'),('anc','Absolute neutrophil count')]
INK='#1f2328'; MUTED='#59636e'; GRID='#e6e8eb'; BLUE='#2a6fdb'; BAND='#cfe0fb'; MOD='#c2410c'; MODBAND='#fbd9c4'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.edgecolor':GRID,'axes.labelcolor':MUTED,'xtick.color':MUTED,'ytick.color':MUTED})
fig,axs=plt.subplots(2,3,figsize=(12,8.2),sharex=True,sharey=True)
for ax,(v,t) in zip(axs.flat,P):
    d=b[(b['var']==v)&(b.n_cases>=30)].sort_values('years_before_mid')
    r=m.loc[v]; y=np.array([r[f'diff_{x:g}y'] for x in XS]); lo=np.array([r[f'diff_{x:g}y_lo'] for x in XS]); hi=np.array([r[f'diff_{x:g}y_hi'] for x in XS])
    ax.axhline(0,color='#9aa1a9',lw=1)
    for yy in [-2,-1,1,2]: ax.axhline(yy,color=GRID,lw=0.8,zorder=0)
    ax.fill_between(XS,lo,hi,color=MODBAND,alpha=.7,lw=0,zorder=1)
    ax.plot(XS,y,color=MOD,lw=2,ls=(0,(4,2)),zorder=3,label='Mixed model (all CBCs, random intercept)')
    ax.fill_between(d.years_before_mid,d.lo,d.hi,color=BAND,alpha=.8,lw=0,zorder=2)
    ax.plot(d.years_before_mid,d['diff'],color=BLUE,lw=2,marker='o',ms=4.5,mec='white',mew=1,zorder=4,label='6-month bins (patient means)')
    ax.set_title(t,loc='left',fontsize=11.5,color=INK,fontweight='bold')
    for s in ['top','right','left']: ax.spines[s].set_visible(False)
    ax.set_xlim(9.9,-0.1); ax.set_ylim(-2.6,2.6); ax.set_yticks([-2,-1,0,1,2]); ax.set_yticklabels(['−2','−1','0','+1','+2'])
    for x0,n in zip(d.years_before_mid,d.n_cases):
        if round(x0*4)%4==1: ax.text(x0,-2.45,str(int(n)),ha='center',va='bottom',fontsize=7.5,color=MUTED)
for ax in axs[1]: ax.set_xticks([8,6,4,2,0])

fig.supxlabel('Years before MDS diagnosis (t1, at right)',color=MUTED,fontsize=10.5,y=0.035)
fig.supylabel('Case minus control, age- and sex-standardised SD units',color=MUTED,fontsize=10.5,x=0.012)
h,l=axs[0,0].get_legend_handles_labels()
fig.legend(h[::-1],l[::-1],loc='upper left',bbox_to_anchor=(0.045,0.905),ncol=2,frameon=False,fontsize=9.5,labelcolor=INK)
fig.text(0.045,0.965,'Blood-count differences between future MDS patients and matched controls',fontsize=14,color=INK,fontweight='bold')
fig.text(0.045,0.94,'494 cases, 4,941 controls; bands = 95% CI (bins: 300 Poisson bootstraps; model: 200 patient-level bootstraps)',fontsize=9,color=MUTED)
fig.text(0.045,0.92,'Bins with at least 30 cases shown; small numbers above each axis = cases contributing to the bin',fontsize=9,color=MUTED)
plt.tight_layout(rect=(0.02,0.045,1,0.875))
plt.savefig('Figure2_prodrome.png',dpi=200,facecolor='white')
