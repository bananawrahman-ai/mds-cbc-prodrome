import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
from pathlib import Path
HERE = Path(__file__).resolve().parent; D = str(HERE.parents[1] / 'results' / 'mds' / 'v2') + '/'
r17 = pd.read_csv(D + 'rev2_r17_rematched_onset.csv'); r8 = pd.read_csv(D + 'revision_r8_onset.csv'); r18 = pd.read_csv(D + 'rev2_r18_comparators_onset.csv')
pick = lambda df, s: df[df.analysis.str.startswith(s)]
mds = [('Matched on sex and age (reference)', pick(r17, 'R17a')), ('+ race', pick(r17, 'R17b')),
       ('+ race, prior CBCs, comorbidity', pick(r17, 'R17c')), ('Harmonised control exclusions', pick(r17, 'R17d')),
       ('No haemoglobinopathy or iron deficiency', pick(r17, 'R17e')), ('Confirmed cases', pick(r17, 'R16')),
       ('Anchored at earliest suspicion', pick(r8, 'R8a')), ('Strictly incident cases', pick(r8, 'R8b'))]
nonmal = [('B12 or folate deficiency', 'B12'), ('Iron-deficiency anaemia', 'Iron'), ('Chronic kidney disease 3-5', 'Chronic kidney'),
          ('Alcoholic liver disease', 'Alcoholic'), ('Unexplained cytopenia', 'Unexplained')]
mal = [('Colorectal cancer', 'Colorectal'), ('Multiple myeloma', 'Multiple'), ('Chronic lymphocytic leukaemia', 'Chronic lymph'),
       ('Myeloproliferative neoplasm', 'Myeloprolif'), ('Acute myeloid leukaemia*', 'Acute myeloid')]
rows = [(n, d, 'mds') for n, d in mds] + [(n, pick(r18, s), 'non') for n, s in nonmal] + [(n, pick(r18, s), 'mal') for n, s in mal]
V = [('rbc', 'Red-cell count'), ('mcv', 'MCV'), ('rdw', 'RDW'), ('platelet', 'Platelets')]
INK = '#1f2328'; MUTED = '#59636e'; GRID = '#e6e8eb'; COL = {'mds': '#2a6fdb', 'non': '#c2410c', 'mal': '#7b8794'}
plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 10, 'xtick.color': MUTED})
fig, axs = plt.subplots(1, 4, figsize=(13.5, 8.2), sharey=True)
gap = {8: 0.8, 13: 0.8}; ys = []; y = 0.0
for i in range(len(rows)):
    y -= gap.get(i, 0); ys.append(y); y -= 1
ys = np.array(ys)
for ax, (v, t) in zip(axs, V):
    for yy, (nm, df, g) in zip(ys, rows):
        r = df[df['var'] == v]
        if r.empty: continue
        r = r.iloc[0]; c = COL[g]
        ax.plot([r.offset_lo, r.offset_hi], [yy, yy], color=c, lw=2.2, solid_capstyle='round'); ax.plot(r.offset, yy, 'o', color=c, ms=6.5, mec='white', mew=1.1)
    ax.axvline(0, color='#9aa1a9', lw=1); ax.set_xlim(-1.5, 1.8)
    for x in [-1, 1]: ax.axvline(x, color=GRID, lw=.8, zorder=0)
    for b in [ys[7] - 0.9, ys[12] - 0.9]: ax.axhline(b, color=GRID, lw=1)
    ax.set_title(t, loc='left', fontweight='bold', color=INK, fontsize=11.5)
    for s in ['top', 'right', 'left']: ax.spines[s].set_visible(False)
    ax.spines['bottom'].set_color(GRID); ax.tick_params(axis='y', length=0)
axs[0].set_yticks(ys); axs[0].set_yticklabels([n for n, _, _ in rows], color=INK)
for lab, g in zip(axs[0].get_yticklabels(), [g for _, _, g in rows]): lab.set_color(COL[g] if g != 'mal' else INK)
fig.text(0.01, 0.962, 'Long-standing red-cell count and MCV offsets are larger before MDS than before ten comparison conditions', fontsize=13.5, fontweight='bold', color=INK)
fig.text(0.01, 0.932, 'Offset a (case minus matched control, SD units, 95% CI) in d(t) = a + β·max(τ − t, 0) over the 10 years before diagnosis.  Blue: MDS analyses;  orange: non-malignant blood-count disorders;  grey: other cancers', fontsize=9, color=MUTED)
fig.text(0.01, 0.015, '*Only bins up to about 3 years before diagnosis held 30 cases. Formal MDS-minus-comparator differences are in Table S17.', fontsize=8.5, color=MUTED)
plt.tight_layout(rect=(0, 0.03, 1, 0.92)); plt.savefig(HERE / 'Figure4_specificity.png', dpi=200, facecolor='white')
print('ok')
